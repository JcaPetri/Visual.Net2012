﻿Imports TPVTAWEB.BDCnxADO   'Importa el Módulo para trabajar con las Bases de Datos
Imports TPVTAWEB.Tbla       'Importa el Módulo para trabajar con las Tablas

Public Class RepBusq
    Inherits System.Web.UI.Page

    Friend TblaTxtMultValenArray(,) As String
    Friend TblaArrFilTot As Integer = 0
    Friend TblaArrColTot As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        NomDataTble = "DTSQL"
        'Dim Fil As Integer
        'Dim Col As Integer
        Dim MyStringBuilder As New StringBuilder

        'Toma los datos del Querystring y los carga en las variables
        Dim QKeys, QVal As Integer
        Dim KeysVal(), DatVal() As String
        Dim TblCod As String = ""
        Dim ProAlm As String = ""
        Dim VarPar As String = ""
        Dim VarParAcum As String = ""
        Dim DatQStrin As NameValueCollection
        'Dim DtRFilAct() As DataRow
        'Dim TblRelac As String
        Dim TblTitulo As String = ""
        Dim TblOrden As String = Nothing
        Dim TextPasado As String = ""


        If Not Page.IsPostBack Then
            Dim myCookie As HttpCookie = New HttpCookie("UserSettings")
            myCookie("Font") = "Arial"
            myCookie("Color") = "Blue"
            myCookie("Nombre") = "Juan"
            myCookie.Expires = Now.AddDays(1)
            Response.Cookies.Add(myCookie)

            If (Request.Cookies("UserSettings") IsNot Nothing) Then
                Dim userSettings As String
                If (Request.Cookies("UserSettings")("Font") IsNot Nothing) Then
                    userSettings = Request.Cookies("UserSettings")("Font")
                    Label1.Text = Request.Cookies("UserSettings")("Nombre").ToString
                End If
            End If

            Txt01.Attributes.Add("P2:", "Atributo")

            ''Carga la info del querystring en la variable NameValueCollection DatQStrin.
            'If IsNothing(Request.QueryString) = False Then
            '    Try     'Trata de realizar la toma de datos, si se produce un error lo intercepta.
            '        If IsError(Request.Form("ctl00$MainContent$Txt01").ToString) = False Then

            '            'Primero define la tabla que tiene la consulta
            '            TblCod = "AT_RPTBP010"

            '            'Segundo define los parámetros y el título para la consulta

            '            Dim TxtAnaliz As String()
            '            Dim TxtParInd As String
            '            Dim Marca As String = "" : Dim Modelo As String = "" : Dim SubModelo As String = "" : Dim Motor As String = "" : Dim Busqueda As String = ""

            '            'Toma el valor de la variable pasada en un string
            '            'VarParAcum = "" : TblTitulo = ""
            '            TextPasado = Request.Form("ctl00$MainContent$Txt01").ToString

            '            If TextPasado <> "" Then
            '                TxtAnaliz = TextPasado.Split(" ")
            '                For Each TxtParInd In TxtAnaliz
            '                    If (LCase(TxtParInd.ToString) = "ren" Or LCase(TxtParInd.ToString) = "renault" Or LCase(TxtParInd.ToString) = "ault" Or LCase(TxtParInd.ToString) = "renaul" Or LCase(TxtParInd.ToString) = "renal") Then
            '                        Marca = "RENAULT"
            '                    ElseIf (LCase(TxtParInd.ToString) = "niss" Or LCase(TxtParInd.ToString) = "nisan" Or LCase(TxtParInd.ToString) = "nis" Or LCase(TxtParInd.ToString) = "issan" Or LCase(TxtParInd.ToString) = "isan") Then
            '                        Marca = "NISSAN"
            '                    ElseIf (LCase(TxtParInd.ToString) = "frontier" Or LCase(TxtParInd.ToString) = "fronti") Then
            '                        Marca = "NISSAN" : Modelo = "FRONTIER"
            '                    ElseIf (LCase(TxtParInd.ToString) = "march" Or LCase(TxtParInd.ToString) = "marc") Then
            '                        Marca = "NISSAN" : Modelo = "MARCH"
            '                    ElseIf (LCase(TxtParInd.ToString) = "murano" Or LCase(TxtParInd.ToString) = "muran") Then
            '                        Marca = "NISSAN" : Modelo = "MURANO"
            '                    ElseIf (LCase(TxtParInd.ToString) = "new" Or LCase(TxtParInd.ToString) = "x-trail2008" Or LCase(TxtParInd.ToString) = "xtrail2008" Or LCase(TxtParInd.ToString) = "newxtrail") Then
            '                        Marca = "NISSAN" : Modelo = "NEW X-TRAIL 2008"
            '                    ElseIf (LCase(TxtParInd.ToString) = "sentra" Or LCase(TxtParInd.ToString) = "centra" Or LCase(TxtParInd.ToString) = "sentr") Then
            '                        Marca = "NISSAN" : Modelo = "SENTRA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "teana" Or LCase(TxtParInd.ToString) = "tean") Then
            '                        Marca = "NISSAN" : Modelo = "TEANA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "terrano" Or LCase(TxtParInd.ToString) = "terano") Then
            '                        Marca = "NISSAN" : Modelo = "TERRANO"
            '                    ElseIf (LCase(TxtParInd.ToString) = "tiida" Or LCase(TxtParInd.ToString) = "tida") Then
            '                        Marca = "NISSAN" : Modelo = "TIIDA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "acenta" Or LCase(TxtParInd.ToString) = "asenta") Then
            '                        Marca = "NISSAN" : Modelo = "TIIDA ACENTA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "teckna" Or LCase(TxtParInd.ToString) = "tecna") Then
            '                        Marca = "NISSAN" : Modelo = "TIIDA TEKNA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "visia" Or LCase(TxtParInd.ToString) = "vicia") Then
            '                        Marca = "NISSAN" : Modelo = "TIIDA VISIA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "xterra" Or LCase(TxtParInd.ToString) = "xtera") Then
            '                        Marca = "NISSAN" : Modelo = "XTERRA"
            '                    ElseIf (LCase(TxtParInd.ToString) = "xtrail" Or LCase(TxtParInd.ToString) = "x-trail") Then
            '                        Marca = "NISSAN" : Modelo = "XTRAIL"
            '                    ElseIf (LCase(TxtParInd.ToString) = "clio" Or LCase(TxtParInd.ToString) = "cli") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO"
            '                    ElseIf (LCase(TxtParInd.ToString) = "clioii" Or LCase(TxtParInd.ToString) = "clioii") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO II"
            '                    ElseIf (LCase(TxtParInd.ToString) = "cliomio" Or LCase(TxtParInd.ToString) = "mio") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO MIO"
            '                    ElseIf (LCase(TxtParInd.ToString) = "clio3pta" Or LCase(TxtParInd.ToString) = "clio3ptas" Or LCase(TxtParInd.ToString) = "clio3ptas2011") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO 3 PTAS NAC ( G2011 )"
            '                    ElseIf (LCase(TxtParInd.ToString) = "clio3pta08" Or LCase(TxtParInd.ToString) = "clio3ptas2008" Or LCase(TxtParInd.ToString) = "clio3ptas08") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO 3 PTAS NAC (G08)"
            '                    ElseIf (LCase(TxtParInd.ToString) = "clio5pta" Or LCase(TxtParInd.ToString) = "clio5ptas") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO 5 PTAS NAC ( G 2011 )"
            '                    ElseIf (LCase(TxtParInd.ToString) = "cliobic" Or LCase(TxtParInd.ToString) = "cliobicnac") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO BIC NAC ( G08 )"
            '                    ElseIf (LCase(TxtParInd.ToString) = "cliotric" Or LCase(TxtParInd.ToString) = "cliotric07") Then
            '                        Marca = "RENAULT" : Modelo = "CLIO TRI NAC (G07)"
            '                    ElseIf (LCase(TxtParInd.ToString) = "duster" Or LCase(TxtParInd.ToString) = "dus") Then
            '                        Marca = "RENAULT" : Modelo = "DUSTER"
            '                    ElseIf (LCase(TxtParInd.ToString) = "fluence" Or LCase(TxtParInd.ToString) = "flue" Or LCase(TxtParInd.ToString) = "flu") Then
            '                        Marca = "RENAULT" : Modelo = "FLUENCE"
            '                    ElseIf (LCase(TxtParInd.ToString) = "kangoo" Or LCase(TxtParInd.ToString) = "kango" Or LCase(TxtParInd.ToString) = "kangu" Or LCase(TxtParInd.ToString) = "kang" Or LCase(TxtParInd.ToString) = "kan") Then
            '                        Marca = "RENAULT" : Modelo = "KANGOO"
            '                    ElseIf (LCase(TxtParInd.ToString) = "kangoo2" Or LCase(TxtParInd.ToString) = "kango2" Or LCase(TxtParInd.ToString) = "kangu2" Or LCase(TxtParInd.ToString) = "kangoo08") Then
            '                        Marca = "RENAULT" : Modelo = "KANGOO 2 (G08)"
            '                    ElseIf (LCase(TxtParInd.ToString) = "kangoofur" Or LCase(TxtParInd.ToString) = "kangofurgon" Or LCase(TxtParInd.ToString) = "kanfur" Or LCase(TxtParInd.ToString) = "kangoofurgon") Then
            '                        Marca = "RENAULT" : Modelo = "KANGOO FUR (G06/07)"
            '                    ElseIf (LCase(TxtParInd.ToString) = "koleos" Or LCase(TxtParInd.ToString) = "kol" Or LCase(TxtParInd.ToString) = "koleo" Or LCase(TxtParInd.ToString) = "kole") Then
            '                        Marca = "RENAULT" : Modelo = "KOLEOS"
            '                    ElseIf (LCase(TxtParInd.ToString) = "logan" Or LCase(TxtParInd.ToString) = "log" Or LCase(TxtParInd.ToString) = "loga") Then
            '                        Marca = "RENAULT" : Modelo = "LOGAN (G08)"
            '                    ElseIf (LCase(TxtParInd.ToString) = "master" Or LCase(TxtParInd.ToString) = "mast" Or LCase(TxtParInd.ToString) = "maste") Then
            '                        Marca = "RENAULT" : Modelo = "MASTER"
            '                    ElseIf (LCase(TxtParInd.ToString) = "master06" Or LCase(TxtParInd.ToString) = "mast06" Or LCase(TxtParInd.ToString) = "maste06" Or LCase(TxtParInd.ToString) = "master07" Or LCase(TxtParInd.ToString) = "mast07" Or LCase(TxtParInd.ToString) = "maste07" Or LCase(TxtParInd.ToString) = "mast" Or LCase(TxtParInd.ToString) = "master") Then
            '                        Marca = "RENAULT" : Modelo = "MASTER (G06/07)"
            '                    ElseIf (LCase(TxtParInd.ToString) = "master3" Or LCase(TxtParInd.ToString) = "masteriii" Or LCase(TxtParInd.ToString) = "mast3" Or LCase(TxtParInd.ToString) = "masternuevo" Or LCase(TxtParInd.ToString) = "nuevomaster" Or LCase(TxtParInd.ToString) = "nuevomast") Then
            '                        Marca = "RENAULT" : Modelo = "NUEVO MASTER"
            '                    ElseIf (LCase(TxtParInd.ToString) = "megane3" Or LCase(TxtParInd.ToString) = "megan3" Or LCase(TxtParInd.ToString) = "meganeiii" Or LCase(TxtParInd.ToString) = "meganiii") Then
            '                        Marca = "RENAULT" : Modelo = "MEGANE III"
            '                    ElseIf (LCase(TxtParInd.ToString) = "sandero" Or LCase(TxtParInd.ToString) = "sand" Or LCase(TxtParInd.ToString) = "sande" Or LCase(TxtParInd.ToString) = "sander") Then
            '                        Marca = "RENAULT" : Modelo = "SANDERO"
            '                    ElseIf (LCase(TxtParInd.ToString) = "stepway" Or LCase(TxtParInd.ToString) = "stepguay" Or LCase(TxtParInd.ToString) = "pway") Then
            '                        Marca = "RENAULT" : Modelo = "SANDERO STEPWAY"
            '                    ElseIf (LCase(TxtParInd.ToString) = "symbol" Or LCase(TxtParInd.ToString) = "sym" Or LCase(TxtParInd.ToString) = "symb") Then
            '                        Marca = "RENAULT" : Modelo = "SYMBOL"
            '                    ElseIf (LCase(TxtParInd.ToString) = "latitud" Or LCase(TxtParInd.ToString) = "latit" Or LCase(TxtParInd.ToString) = "lati") Then
            '                        Marca = "RENAULT" : Modelo = "LATITUD"
            '                    ElseIf (LCase(TxtParInd.ToString) = "k13m" Or LCase(TxtParInd.ToString) = "k13") Then
            '                        Marca = "NISSAN" : Motor = "K13M"
            '                    ElseIf (LCase(TxtParInd.ToString) = "mr18" Or LCase(TxtParInd.ToString) = "mr1") Then
            '                        Marca = "NISSAN" : Motor = "MR18"
            '                    ElseIf (LCase(TxtParInd.ToString) = "mr20" Or LCase(TxtParInd.ToString) = "mr2") Then
            '                        Marca = "NISSAN" : Motor = "MR20"
            '                    ElseIf (LCase(TxtParInd.ToString) = "qr25" Or LCase(TxtParInd.ToString) = "qr2") Then
            '                        Marca = "NISSAN" : Motor = "QR25"
            '                    ElseIf (LCase(TxtParInd.ToString) = "td27" Or LCase(TxtParInd.ToString) = "td2") Then
            '                        Marca = "NISSAN" : Motor = "TD27"
            '                    ElseIf (LCase(TxtParInd.ToString) = "vq25" Or LCase(TxtParInd.ToString) = "vq2") Then
            '                        Marca = "NISSAN" : Motor = "VQ25"
            '                    ElseIf (LCase(TxtParInd.ToString) = "vq35" Or LCase(TxtParInd.ToString) = "vq3") Then
            '                        Marca = "NISSAN" : Motor = "VQ35"
            '                    ElseIf (LCase(TxtParInd.ToString) = "yd22" Or LCase(TxtParInd.ToString) = "yd25") Then
            '                        Marca = "NISSAN" : Motor = "YD22"
            '                    ElseIf (LCase(TxtParInd.ToString) = "yd25" Or LCase(TxtParInd.ToString) = "yd25") Then
            '                        Marca = "NISSAN" : Motor = "YD25DDTI"
            '                    ElseIf (LCase(TxtParInd.ToString) = "MWN" Or LCase(TxtParInd.ToString) = "MWN") Then
            '                        Marca = "NISSAN" : Motor = "MWM COMMOND RAIL"
            '                    ElseIf (LCase(TxtParInd.ToString) = "2tr") Then
            '                        Marca = "RENAULT" : Motor = "2TR"
            '                    ElseIf (LCase(TxtParInd.ToString) = "5zv") Then
            '                        Marca = "RENAULT" : Motor = "5ZV"
            '                    ElseIf (LCase(TxtParInd.ToString) = "d4f") Then
            '                        Marca = "RENAULT" : Motor = "D4F"
            '                    ElseIf (LCase(TxtParInd.ToString) = "diesel") Then
            '                        Marca = "RENAULT" : Motor = "DIESEL"
            '                    ElseIf (LCase(TxtParInd.ToString) = "f4r") Then
            '                        Marca = "RENAULT" : Motor = "F4R"
            '                    ElseIf (LCase(TxtParInd.ToString) = "f8q") Then
            '                        Marca = "RENAULT" : Motor = "F8Q"
            '                    ElseIf (LCase(TxtParInd.ToString) = "f9q") Then
            '                        Marca = "RENAULT" : Motor = "F9Q"
            '                    ElseIf (LCase(TxtParInd.ToString) = "g9u") Then
            '                        Marca = "RENAULT" : Motor = "G9U"
            '                    ElseIf (LCase(TxtParInd.ToString) = "k4m") Then
            '                        Marca = "RENAULT" : Motor = "K4M"
            '                    ElseIf (LCase(TxtParInd.ToString) = "k7m") Then
            '                        Marca = "RENAULT" : Motor = "K7M"
            '                    ElseIf (LCase(TxtParInd.ToString) = "k9k") Then
            '                        Marca = "RENAULT" : Motor = "K9K"
            '                    ElseIf (LCase(TxtParInd.ToString) = "m4r") Then
            '                        Marca = "RENAULT" : Motor = "M4R"
            '                    ElseIf (LCase(TxtParInd.ToString) = "nafta") Then
            '                        Marca = "RENAULT" : Motor = "NAFTA"
            '                    Else
            '                        If Busqueda = "" Then
            '                            Busqueda = UCase(TxtParInd.ToString)
            '                        Else
            '                            Busqueda = Busqueda & "%" & UCase(TxtParInd.ToString)
            '                        End If
            '                    End If
            '                Next
            '            Else
            '                'Si no tiene parámetros no hace nada
            '            End If

            '            '##################################################################################################################################
            '            'Arma la variable de busqueda y el titulo
            '            VarParAcum = "" : TblTitulo = ""

            '            If Marca = "" Then
            '                VarParAcum = "%"
            '            Else
            '                VarParAcum = Marca
            '                TblTitulo = Marca
            '            End If

            '            If Modelo = "" Then
            '                VarParAcum = VarParAcum & "|%"
            '            Else
            '                VarParAcum = VarParAcum & "|" & Modelo
            '                TblTitulo = TblTitulo & " - " & Modelo
            '            End If

            '            If SubModelo = "" Then
            '                VarParAcum = VarParAcum & "|%"
            '            Else
            '                VarParAcum = VarParAcum & "|" & SubModelo
            '                TblTitulo = TblTitulo & " - " & SubModelo
            '            End If

            '            If Motor = "" Then
            '                VarParAcum = VarParAcum & "|%"
            '            Else
            '                VarParAcum = VarParAcum & "|" & Motor
            '                TblTitulo = TblTitulo & " - " & Motor
            '            End If

            '            If Busqueda = "" Then
            '                VarParAcum = VarParAcum & "|%"
            '            Else
            '                VarParAcum = VarParAcum & "|" & Busqueda
            '                TblTitulo = TblTitulo & " - " & Busqueda
            '            End If
            '        End If
            '        '##########################################################
            '        ' Aquí se entregan 2 variables
            '        ' 1.- VarParAcum
            '        ' 2.- TblTitulo
            '        ' Con esto se ejecuta la consulta sql para traer los datos.

            '    Catch ex As Exception
            '        'No hace nada, ya que no hay busqueda, por eso se produce el error, ya que todavia no se genero el objeto
            '        'Response.Write(ex.Message.ToString)
            '        Exit Sub
            '    End Try
            'Else
            '    DatQStrin = Request.QueryString
            '    ' Pone todas las Claves en un array String.
            '    KeysVal = DatQStrin.AllKeys

            '    For QKeys = 0 To KeysVal.GetUpperBound(0)
            '        'Response.Write("Key: " & Server.HtmlEncode(KeysVal(QKeys)))
            '        ' Get all values under this key.
            '        DatVal = DatQStrin.GetValues(QKeys)
            '        For QVal = 0 To DatVal.GetUpperBound(0)
            '            Response.Write(CStr(QVal) & " = " & Server.HtmlEncode(DatVal(QVal)) & "<br>")
            '            If Server.HtmlEncode(KeysVal(QKeys)) = "TblCod" Then
            '                TblCod = Server.HtmlEncode(DatVal(QVal))
            '            ElseIf Server.HtmlEncode(KeysVal(QKeys)) = "TblPars" Then
            '                If VarPar = "" Then
            '                    If Server.HtmlEncode(DatVal(QVal)) = "USUNAME" Then
            '                        VarPar = Page.User.Identity.Name.ToString()
            '                    Else
            '                        VarPar = Server.HtmlEncode(DatVal(QVal))
            '                        If VarParAcum = "" Then
            '                            VarParAcum = VarPar
            '                        Else
            '                            VarParAcum = VarParAcum & "|" & VarPar
            '                        End If

            '                    End If
            '                Else
            '                    VarPar = VarPar & "|"
            '                End If
            '            ElseIf Server.HtmlEncode(KeysVal(QKeys)) = "TblTit" Then
            '                TblTitulo = Server.HtmlEncode(DatVal(QVal))
            '            End If
            '        Next QVal
            '    Next QKeys

            'End If

            ''************************************************** INICIO **********************************************************
            ' No hace nada, solo muestra el formulario de busqueda
            ''<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FIN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ViewState.Add("Pe1", "Val1")
        Else
            DatQStrin = Request.QueryString
            ' Pone todas las Claves en un array String.
            KeysVal = DatQStrin.AllKeys

            For QKeys = 0 To KeysVal.GetUpperBound(0)
                'Response.Write("Key: " & Server.HtmlEncode(KeysVal(QKeys)))
                ' Get all values under this key.
                DatVal = DatQStrin.GetValues(QKeys)
                For QVal = 0 To DatVal.GetUpperBound(0)
                    Response.Write(CStr(QVal) & " = " & Server.HtmlEncode(DatVal(QVal)) & "<br>")
                    If Server.HtmlEncode(KeysVal(QKeys)) = "TblCod" Then
                        TblCod = Server.HtmlEncode(DatVal(QVal))
                    ElseIf Server.HtmlEncode(KeysVal(QKeys)) = "TblPars" Then
                        If VarPar = "" Then
                            If Server.HtmlEncode(DatVal(QVal)) = "USUNAME" Then
                                VarPar = Page.User.Identity.Name.ToString()
                            Else
                                VarPar = Server.HtmlEncode(DatVal(QVal))
                                If VarParAcum = "" Then
                                    VarParAcum = VarPar
                                Else
                                    VarParAcum = VarParAcum & "|" & VarPar
                                End If

                            End If
                        Else
                            VarPar = VarPar & "|"
                        End If
                    ElseIf Server.HtmlEncode(KeysVal(QKeys)) = "TblTit" Then
                        TblTitulo = Server.HtmlEncode(DatVal(QVal))
                    End If
                Next QVal
            Next QKeys
            ''************************************************** INICIO **********************************************************
            ''Response.Write(VarPar1)
            ''<<<<<<<< Procedimiento para conectarse y Ejecutar consultas >>>>>>>>>>>>>
            'Rtado = ADOCnxBD("PVTWEB")             'Llama a la funcion para conectar a la BD, de la hoja BDCnxADO
            ''MyStringBuilder.Append(Rtado & "<br>")      'Escribe si se conecto OK o NO


            ''1.- Toma la información de la base de datos para armar la tabla
            'Rtado = SqlBD("[PVTWEB].[dbo].[GRL_TBLARM]", TblCod, NomDataTble, "PVTWEB", "DataReader")
            ''ProAlm = ""
            ''VarPar = ""
            ''TblRelac = ""

            'DtRFilAct = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)
            'TblRelac = ""
            '' Ahora recorremos el recordset creando una fila nueva por cada registro 
            'For Fil = 0 To DtRFilAct.Length - 1
            '    If DtRFilAct(Fil)(0).ToString = "TBLDATOS" Then
            '        'Se carga en la variable el Proc Alm que dará origen a la tabla inicial
            '        ProAlm = DtRFilAct(Fil)(1).ToString
            '    ElseIf DtRFilAct(Fil)(0).ToString = "TBLVINCULA" Then
            '        'Se carga en la variable TblRelac, los datos que servirán para el vinculo con otra tabla
            '        'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
            '        'Se carga en la variable TblRelac, los datos que servirán para el vinculo con otra tabla
            '        If TblRelac = "" Then
            '            'TblRelac = DtRFilAct(Fil)("CPA_CRITAPLIC").ToString & "‡PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)("COD_PROCALM").ToString & "&TblPars="
            '            TblRelac = DtRFilAct(Fil)("COD_PROCALM").ToString
            '        Else
            '            TblRelac = TblRelac & "/" & DtRFilAct(Fil)("CPA_CRITAPLIC").ToString & "‡RepBusq.aspx?TblCod=" & DtRFilAct(Fil)("COD_PROCALM").ToString & "&TblPars="
            '        End If
            '    ElseIf DtRFilAct(Fil)(0).ToString = "TBLFORMCSS" Then
            '        'Se carga la información para definir el formato de la tabla
            '    ElseIf DtRFilAct(Fil)(0).ToString = "TBLORDEN" Then
            '        'Se carga la información para ordenar la tabla
            '        TblOrden = DtRFilAct(Fil)(1).ToString
            '    End If
            'Next Fil


            ' ''1.- La conexión, lectura de los datos y su traslado a la Tabla se hace en la función.
            ''Rtado = SqlBD(ProAlm, VarParAcum, NomDataTble, "PVTWEB", "DataReader")

            ''2.- Llama a la variable para hacer la tabla
            'Dim loop1, loop2 As Integer
            'Dim MyCookieColl As HttpCookieCollection
            'Dim arr1(), arr2() As String
            'Dim MyCookie As HttpCookie
            'MyCookieColl = Request.Cookies
            '' Capture all cookie names into a string array.
            'arr1 = MyCookieColl.AllKeys
            '' Grab individual cookie objects by cookie name     
            'For loop1 = 0 To arr1.GetUpperBound(0)
            '    MyCookie = MyCookieColl(arr1(loop1))
            '    Response.Write("Cookie: " & MyCookie.Name & "<br>")
            '    Response.Write("Secure:" & MyCookie.Secure & "<br>")

            '    ' Grab all values for single cookie into an object array.
            '    arr2 = MyCookie.Values.AllKeys
            '    ' Loop through cookie value collection and print all values.
            '    For loop2 = 0 To arr2.GetUpperBound(0)
            '        Response.Write("Value " & CStr(loop2) + ": " & Server.HtmlEncode(arr2(loop2)) & "<br>")
            '    Next loop2
            '    Txt02.Text = arr2.ToString
            'Next loop1


            ''Rtado = HaceTbla(dbDTable.Select(Nothing, TblOrden, DataViewRowState.CurrentRows), TblRelac, TblTitulo, VarPar)    ' 
            ''Response.Write(Rtado)
            'If Left(Rtado, 6) = "SqlErr" Then
            '    Response.Write(Rtado)
            '    Exit Sub
            'End If

            'Tomo las filas en la variable = FilasActuales como DataRow => Dim DtRFilasActuales() As DataRow = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)
            'Los datos Ya estan en el DataRow, ahora hay que navegar por ellos para agregar los atributos
            'Para hacer esto llamo a la función. En el punto 2.- se consolido todo en que llama a la función y pasa como parámetros el contenido de la tabla
            '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FIN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

            '' Get the HttpContext object for the current request.
            'Dim i As Integer
            'Dim myHttpContext As HttpContext = HttpContext.Current
            '' Get the application object for the current request.
            'Dim myHttpApplication As HttpApplication = myHttpContext.ApplicationInstance
            '' Get the collection of all HTTPModule objects for the current application.
            'Dim myHttpModuleCollection As HttpModuleCollection = myHttpApplication.Modules

            '' Get the name of the HttpModule object at index 1.
            'Dim httpModuleName As String = myHttpModuleCollection.GetKey(1)
            'Response.Write("The name of the HttpModule object at index 1" + " is " + "'" + httpModuleName + "'." + "<br><br>")

            'Dim allModules() As String = myHttpModuleCollection.AllKeys

            '' Display the names of all HttpModule objects.
            'Response.Write("<b>The HttpModule objects of HttpModuleCollection are:</b><br>")

            'For i = 0 To allModules.Length - 1
            '    Response.Write("Module" + i.ToString() + "  : " + allModules(i).ToString() + "<br>")
            'Next i


            '' Copy the HttpModule objects in the collection into an array.    
            'Dim httpModuleArray As System.Array = Array.CreateInstance(GetType(Object), myHttpModuleCollection.AllKeys.Length)
            'myHttpModuleCollection.CopyTo(httpModuleArray, 0)
            'Response.Write("<br><br><b>Successfully copied the HttpModule objects in the HttpModuleCollection to an array." + "<br>Displaying the HttpModule objects in the array:</b><br>")

            'For i = 0 To httpModuleArray.Length - 1
            '    Response.Write("Module" + i.ToString() + ": " + httpModuleArray.GetValue(i).ToString() + "<br>")
            'Next i


            'Campo Buscado donde esta el valor cargado por el usuario
            Dim CtrlBusq As String = ""
            CtrlBusq = "Opb01"  '"Txt01"
            CtrlBusq = "ctl00$MainContent$" & CtrlBusq

            Dim FormVar As NameValueCollection  'Variables del formulario
            Dim VarArr() As String      'Array para tomar los valores de las variables del formulario
            Dim LpArr As Integer        'Valore para recorrer las variable
            Dim NumCar As Integer       'Valores para interactuar por los valores de la variable, ya que cada variable es por caracter
            Dim ValorElegUsuario As String = ""

            ' Toma las variables del formulario en NameValueCollection variable.
            FormVar = Request.Form
            ' Toma los valores de  las variables del formulario en un array.
            VarArr = FormVar.AllKeys

            For LpArr = 0 To VarArr.GetUpperBound(0)    'Interactua por las variables del formulario.
                If VarArr(LpArr) = CtrlBusq Then    'Encuentra el control que toma la variable
                    For NumCar = 0 To Request.Form(CtrlBusq).Count - 1
                        ValorElegUsuario = ValorElegUsuario & Request.Form(CtrlBusq)(NumCar).ToString
                    Next
                    Response.Write(ValorElegUsuario)
                End If
                'For NumCar = 0 To Request.Form(VarArr(LpArr)).Count - 1
                '    ValorElegUsuario = ValorElegUsuario & Request.Form(VarArr(LpArr))(NumCar).ToString
                'Next
                'Response.Write(ValorElegUsuario)

                'Response.Write("Form: " & VarArr(LpArr) & "Cant= " & VarArr(LpArr).Count & "<br>")
                ''For i = 0 To arr12(loop12).Count - 1
                ''    Response.Write("Form: " & arr12(loop12) & " - Valor= " & arr12(loop12)(i))
                ''Next i
                'Response.Write("<BR>")
            Next LpArr


            'Dim arr22() As String
            'Response.Write("<BR>")
            'Response.Write("<BR>")

            'For i = 0 To Request.Form("ctl00$MainContent$Txt01").Count - 1
            '    Response.Write(Request.Form("ctl00$MainContent$Txt01")(i).ToString)
            'Next

            'Response.Write("<BR>")
            'Response.Write("Prueba:")
            'For i = 0 To Request.Form(arr12(3)).Count - 1
            '    Response.Write(Request.Form(arr12(3))(i).ToString)
            'Next
            'Response.Write("<BR>")
            ''Items
            'Response.Write("Bucle con los items <BR>")
            'Dim Items As String
            'For Each Items In Request.Form
            '    Response.Write("Este es items =" & Items & " - ")
            '    Response.Write("Este es items =" & Items.ToString & " - ")
            '    Response.Write("Este es items =" & Items.Count & " - ")
            '    Response.Write("<BR>")
            'Next
            'Response.Write("<BR>")
            'Response.Write("<BR>")
            'Dim Arr02 As Array
            'Arr02 = Request.Form("ctl00$MainContent$Txt01").ToArray
            'Dim Var12 As String

            'Var12 = Request.Form("ctl00$MainContent$Txt01").Last.ToString



            'Response.Write("<BR>")
            'Response.Write("<BR>")
            'Response.Write("ViewState")
            'Response.Write("<BR>")
            'If IsNothing(ViewState("Pe1")) = False Then
            '    Response.Write("P1=" & ViewState("Pe1"))
            'Else
            '    Response.Write("No se encuentra")
            'End If
            'Response.Write("<BR>")
            'Response.Write("Txt01=" & ViewState("ctl00$MainContent$Txt01"))

            'Response.Write("<BR>")

            'For i = 0 To Request.Form("Text1").Count - 1
            '    Response.Write(Request.Form("Text1")(i).ToString)
            'Next
            'Response.Write("<BR>")
            'Response.Write("<BR>")
            'For i = 0 To Request.Form("flavor").Count - 1
            '    Response.Write(Request.Form("flavor")(i))
            'Next
            'Response.Write("<BR>")

            'Dim arrayList As ArrayList
            'arrayList = CType(ViewState("arrayListInViewState"), ArrayList)

            'Me.GridView1.DataSource = arrayList
            'Me.GridView1.DataBind()


        End If
    End Sub

    Friend Function HaceTbla(ByVal DtRFilasActuales() As DataRow, ByVal Vinculo As String, Optional ByVal TblTitulo As String = "", Optional ByVal VarPar As String = "") As String      'Se definen 1 parámetros, Nombre Base de Datos y Consulta Inicial
        Dim ConvEnTblj As String
        Dim Fil As Integer = 0 : Dim TotFil As Integer = 0
        Dim Col As Integer = 0 : Dim TotCol As Integer = 0
        Dim FilArr As Integer = 0 : Dim ColArr As Integer = 0
        TotFil = dbDTable.Rows.Count - 1 : TotCol = dbDTable.Columns.Count - 1

        Dim TblFormyVinc(TotFil, TotCol) As String

        'Arma la Tabla que vee el usuario

        ' 0.- Arma la tabla del campo multivaluado.
        ' Organiza el formato y los vínculos de las tablas
        ' Aquí llama a la función para transformar el campo multivaluado en una tabla
        ConvEnTblj = ConvEnTbl(Vinculo)

        ' 1.- Primero debemos poner el título a la Tabla
        If TblTitulo <> "" Then
            Table01.Caption = TblTitulo
            Table01.CaptionAlign = TableCaptionAlign.Left
        Else
            Table01.Caption = ""
        End If

        ' 2.- Segundo debemos poner el título a cada columna
        Dim Tit As New TableRow()
        't.CssClass = "tbletit"
        For Col = 0 To dbDTable.Columns.Count - 1
            Dim ct As New TableCell()
            Dim cth As New TableHeaderCell()
            Dim lbl As New Label()
            'Si la columna define el tipo de Fila, o Se especifica que no se muestra, no la carga
            If dbDTable.Columns(Col).Caption.ToString <> "TIPOFILA" And InStr(dbDTable.Columns(Col).Caption.ToString, "†NM", CompareMethod.Text) = 0 Then
                'ct.CssClass = "tbletit"
                lbl.Text = dbDTable.Columns(Col).Caption.ToString
                cth.Controls.Add(lbl)
                Tit.Cells.Add(cth)
            End If
        Next Col
        Table01.Rows.Add(Tit)


        ' 3.- Tercero recorremos el recordset creando una fila nueva por cada registro 
        For Fil = 0 To DtRFilasActuales.Length - 1
            Dim r As New TableRow() 'Agrega una nueva Fila
            ' Borrar Inicio
            ' Especifica el formato de la fila
            If DtRFilasActuales(Fil)(0).ToString = "TOTAL" Then
                'Si la fila es un Total, tiene un formato específico
                r.CssClass = "sortbottom"   'Especifica el formato de la fila Titulo
                'Celda.CssClass = "tbleceltot"   'Especifica el formato de la fila Titulo
            ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then
                'Si la fila es de Datos, tiene un formato específico
                'r.CssClass = "TblDatEst"
            End If


            ' Borrar Fin
            For Col = 0 To dbDTable.Columns.Count - 1
                Dim Celda As New TableCell()
                Dim LinkButt As New LinkButton()
                Dim TextoAAgregar As String = ""
                Dim TipoControl As String = ""
                Dim TipoFormato As String = ""

                'Si la columna define el tipo de Fila, o Se especifica que no se muestra, no la carga
                If dbDTable.Columns(Col).Caption.ToString <> "TIPOFILA" And InStr(dbDTable.Columns(Col).Caption.ToString, "†NM", CompareMethod.Text) = 0 Then
                    'Aquí estamos en cada celda de la tabla que se va a realizar
                    If DtRFilasActuales(Fil)(0).ToString <> "NULL" Or DtRFilasActuales(Fil)(Col).ToString <> "" Then
                        'Especifica el formato de la celda
                        If DtRFilasActuales(Fil)(0).ToString = "TOTAL" Then
                            'Si la fila es un Total, tiene un formato específico
                            'Celda.CssClass = "sortbottom"   'Especifica el formato de la fila Titulo
                            'Celda.CssClass = "tbleceltot"   'Especifica el formato de la fila Titulo
                        ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then
                            'Si la fila es de Datos, tiene un formato específico
                            'Celda.CssClass = "TblCelEst"
                        End If



                        'If DtRFilasActuales(Fil)(Col).ToString = "NULL" Or DtRFilasActuales(Fil)(Col).ToString = "" Then
                        '    'NO HACE NADA
                        'Else
                        '    Celda.Controls.Add(New LiteralControl(DtRFilasActuales(Fil)(Col).ToString))
                        'End If
                        'ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then



                        'Ahora debemos recorrer el array para ver si tiene vinculo, formato, etc.
                        'Aquí se debe verificar:
                        ' Control a Utilizar
                        ' Si tiene Vínculo
                        ' Tipo de Formato del Valor
                        ' Tipo de fondo de la celda
                        ' Ver en excel que mas aspectos tiene la celda

                        '1.- TIPO DE CONTROL QUE SE DEBE AGREGAR
                        '    Recorre la matriz con la info
                        For FilArr = 1 To TblaArrFilTot
                            'Primero verifica si la fila esta incluída
                            If Fil = TblaTxtMultValenArray(FilArr, 0) Or TblaTxtMultValenArray(FilArr, 0) = -1 Then     'FIL
                                'Verifica si la columna esta incluída, si es así pone la especificación
                                If Col = TblaTxtMultValenArray(FilArr, 1) Or TblaTxtMultValenArray(FilArr, 1) = -1 Then    'COL
                                    'Verifica el tipo de columna, y en función de eso procede a tipificarla
                                    If TblaTxtMultValenArray(FilArr, 2) = "CONTROL" Then    'TIPO
                                        If TblaTxtMultValenArray(FilArr, 3) = "LINKBUTTON" Then   'VALOR
                                            TipoControl = "LinkButton"
                                            LinkButt.ID = "vinc" & Fil & Col

                                            'Verifica si el vinculo que viene de la consulta sql tiene codigo y descripción
                                            Dim DatVinc() As String
                                            If DtRFilasActuales(Fil)(Col).ToString = "" Then
                                                ReDim DatVinc(0)
                                                DatVinc(0) = DtRFilasActuales(Fil)(Col).ToString
                                            Else
                                                DatVinc = DtRFilasActuales(Fil)(Col).ToString.Split("†")
                                            End If

                                            If DatVinc.Length = 3 Then  'Tiene 2 valores (0 y 1), tiene codigo
                                                TextoAAgregar = DatVinc(2).ToString()
                                                If VarPar = "" Then
                                                    LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
                                                    'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
                                                Else
                                                    LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
                                                End If
                                            ElseIf DatVinc.Length = 2 Then  'Tiene 2 valores (0 y 1), tiene codigo
                                                TextoAAgregar = DatVinc(1).ToString()
                                                If VarPar = "" Then
                                                    LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
                                                    'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
                                                Else
                                                    LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
                                                End If
                                            Else
                                                TextoAAgregar = DatVinc(0).ToString()
                                                If VarPar = "" Then
                                                    LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(0).ToString()
                                                Else
                                                    LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(0).ToString()
                                                End If
                                            End If
                                        End If  'ESPECIFICACIONES
                                    End If
                                Else
                                    'No hace nada, ya que puede ser que en otra fila de array este especificado
                                End If
                            Else
                                'No hace nada, ya que puede ser que en otra fila de array este especificado
                            End If
                        Next

                        '2.- FORMATO DEL VALOR A AGREGAR
                        '    Recorre la matriz con la info
                        For FilArr = 1 To TblaArrFilTot
                            'Primero verifica si la fila esta incluída
                            If Fil = TblaTxtMultValenArray(FilArr, 0) Or TblaTxtMultValenArray(FilArr, 0) = -1 Then     'FIL
                                'Verifica si la columna esta incluída, si es así pone la especificación
                                If Col = TblaTxtMultValenArray(FilArr, 1) Or TblaTxtMultValenArray(FilArr, 1) = -1 Then    'COL
                                    'Celda que tiene un formato específico
                                    'Verifica el tipo de columna, y en función de eso procede a tipificarla
                                    If TblaTxtMultValenArray(FilArr, 2) = "FORMATO" Then    '
                                        If TblaTxtMultValenArray(FilArr, 3) = "MONEDA" Then   'VALOR
                                            If IsNumeric(DtRFilasActuales(Fil)(Col)) = True Then
                                                Dim MyNum As Double = 0
                                                If TextoAAgregar = "" Then
                                                    MyNum = DtRFilasActuales(Fil)(Col)
                                                    TextoAAgregar = MyNum.ToString("$#,##0;($#,##0);0")
                                                    'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
                                                Else
                                                    MyNum = CDbl(TextoAAgregar)
                                                    TextoAAgregar = MyNum.ToString("$#,##0;($#,##0);0")
                                                    'TextoAAgregar = String.Format("{0,1:C0}", CDbl(TextoAAgregar))
                                                End If
                                                'Todos los valores numéricos se alinean a la derecha
                                                Celda.HorizontalAlign = HorizontalAlign.Right
                                            Else
                                                'No hace nada ya que no se puede convertir el dato
                                            End If
                                        ElseIf TblaTxtMultValenArray(FilArr, 3) = "ENTERO" Then   'VALOR
                                            If IsNumeric(DtRFilasActuales(Fil)(Col)) = True Then
                                                Dim MyNum As Double = 0
                                                If TextoAAgregar = "" Then
                                                    MyNum = DtRFilasActuales(Fil)(Col)
                                                    TextoAAgregar = MyNum.ToString("0' u';(0' u');0")
                                                    'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
                                                Else
                                                    MyNum = CDbl(TextoAAgregar)
                                                    TextoAAgregar = MyNum.ToString("0' u';(0' u');0")
                                                End If
                                                'Todos los valores numéricos se alinean a la derecha
                                                Celda.HorizontalAlign = HorizontalAlign.Right
                                            Else
                                                'No hace nada ya que no se puede convertir el dato
                                            End If
                                        Else
                                            'No hace nada
                                        End If
                                    End If
                                Else
                                    'No hace nada, ya que puede ser que en otra fila de array este especificado
                                End If
                            Else
                                'No hace nada, ya que puede ser que en otra fila de array este especificado
                            End If
                        Next
                        'Cuando termina el array, se deben ver los parámetros especificados, si no hay nada se ponen por defecto, TipoDato Texto, Formato, Fondo Celda, etc
                        'Luego que recorrió por la tabla de especificaciones, agrega la Celda a la Tabla


                        'Debe verificar el tipo de Control que se debe agregar, si no se agrega el texto comun
                        If DtRFilasActuales(Fil)(Col).ToString = "" Or DtRFilasActuales(Fil)(Col).ToString = "0" Then
                            'NO PONE NADA YA QUE NO TIENE VALOR
                        Else
                            If TextoAAgregar <> "" Then 'Si la variable con el dato con formato no tiene valor, pone el dato del DataTable
                                If TextoAAgregar = "0" Then
                                    'Si el valor es igual a cero no pone nada
                                Else
                                    If TipoControl = "LinkButton" Then
                                        LinkButt.Text = TextoAAgregar
                                        Celda.Controls.Add(LinkButt)
                                    Else
                                        Celda.Controls.Add(New LiteralControl(TextoAAgregar))
                                    End If
                                End If
                            Else
                                If TipoControl = "LinkButton" Then
                                    LinkButt.Text = TextoAAgregar
                                    Celda.Controls.Add(LinkButt)
                                Else
                                    Celda.Controls.Add(New LiteralControl(DtRFilasActuales(Fil)(Col).ToString))
                                End If


                            End If
                        End If
                    Else
                        'NO HACE NADA
                    End If
                    'Response.Write("<TD><a href=detalle_rg.asp?Fecha="&Var_Fecha&"?Central="&oRS.Fields(I).name&"><div align=center><font size=2><font color=#0000A0>"&trim(oRS.Fields(I))&"</font></font></b></div></a></TD>")
                    r.Cells.Add(Celda)
                End If
            Next Col
            Table01.Rows.Add(r)
            'If Fil > 10 Then Exit For
        Next Fil

        'Si llega a esta instancia es que realizo la TABLA OK, lo informa
        HaceTbla = "TblaOK"
        Return HaceTbla
    End Function
    Friend Function ConvEnTbl(ByVal TextMultValuado As String) As String
        Dim Fil As Integer = 0
        Dim Col As Integer = 0

        'Pasa los datos en Filas
        Dim DatosEnFilas() As String : DatosEnFilas = TextMultValuado.Split("‡") : Dim DatosEnFilasyCol() As String

        'Redefine la matríz en función a los datos que hay en el campo multivaluado
        TblaArrFilTot = DatosEnFilas.Length - 1 : TblaArrColTot = DatosEnFilas(0).Split("†").Length - 1
        ReDim TblaTxtMultValenArray(TblaArrFilTot, TblaArrColTot)

        'Completa el array con la información del campo multivaluado
        For Fil = 0 To TblaArrFilTot
            'Paso la primer fila a la variable de la fila
            DatosEnFilasyCol = DatosEnFilas(Fil).Split("†")
            For Col = 0 To TblaArrColTot
                'Paso cada columna a la matriz. Ya aquí tengo fila y columna
                TblaTxtMultValenArray(Fil, Col) = DatosEnFilasyCol(Col)
            Next
        Next

        ConvEnTbl = "OK"
        Return ConvEnTbl
    End Function

    Private Sub Btn01_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn01.Click

        ViewState.Add("Pe1", "Val1")
        Dim MyCookie As New HttpCookie("DatBusq")       'Crea la Cookie userInfo
        Dim now As DateTime = DateTime.Now

        MyCookie.Value = "Juan " & now.ToString()       'Txt01.Text
        MyCookie.Expires = DateTime.Now.AddHours(1)
        Response.Cookies.Add(MyCookie)

    End Sub
End Class
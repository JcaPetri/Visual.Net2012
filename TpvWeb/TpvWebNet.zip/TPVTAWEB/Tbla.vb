﻿Module Tbla
    'Friend Function HaceTbla(ByVal DtRFilasActuales() As DataRow) As String      'Se definen 1 parámetros, Nombre Base de Datos y Consulta Inicial
    '    Dim Col As Integer
    '    Dim Fil As Integer

    '    '3.- Arma la Tabla que vee el usuario
    '    ' Ahora recorremos el recordset creando una fila nueva por cada registro 
    '    For Fil = 0 To DtRFilasActuales.Length - 1
    '        Dim r As New TableRow()
    '        If Fil = 0 Then
    '            r.CssClass = "tbletit"
    '        Else
    '            r.CssClass = "tbledat"
    '        End If
    '        For Col = 0 To dbDTable.Columns.Count - 1
    '            Dim c As New TableCell()
    '            If Fil = 0 Then
    '                c.CssClass = "tbletit"
    '            Else
    '                c.CssClass = "tblecel"
    '            End If
    '            c.Controls.Add(New LiteralControl(DtRFilasActuales(Fil)(Col).ToString))
    '            r.Cells.Add(c)
    '        Next Col
    '        Table01.Rows.Add(r)
    '    Next Fil

    '    'Si llega a esta instancia es que realizo la TABLA OK, lo informa
    '    HaceTbla = "TblaOK"
    '    Return HaceTbla
    'End Function
End Module

﻿function IraHomePage() {
    // Abre una página en la misma ventana actual   /JCPEConsulting/Default.aspx
    window.top.location.href = ResolveUrl("Default.aspx", "_self");
}


function statusreport() {
    alert("Se Ejecutó Bien");
}


if (window.addEventListener)
//    window.addEventListener("onload", resizeCaller, false)
else if (window.attachEvent)
//    window.attachEvent("onload", resizeCaller)
else
//    window.onload = resizeCaller;

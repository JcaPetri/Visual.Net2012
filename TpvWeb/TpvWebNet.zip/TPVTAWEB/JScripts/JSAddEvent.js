﻿//#####################################################################################################
//#####################################################################################################
//      Primero detecta el elemento activado, el explorador, luego le agrega el evento
//#####################################################################################################
//#####################################################################################################

var activeElement;

//#####################################################################################################
//      Detecta y devuelve el elemento activado
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
function EventElem(evento) {
    //alert("EventElem Inicio= " + evento);
    if (navigator.appName == "Microsoft Internet Explorer") {  //  Primero verifica si evento tiene valor, si es así quiere decir que es abierto por Internet Explorer
        //alert("Internet Explorer");
        evento = window.event       //Le asigno el valor al evento
        activeElement = window.event.srcElement;     //Si es IE, le asigna a la variable el objeto
    } else if (evento.target) { //  Mozilla Firefox, Netscape
        //alert("Firefox Netscape");
        activeElement = evento.target;   //Si no es IE, toma el objeto con target
    } else {
        //activeElement = evento.target;   //Si no es IE, toma el objeto con target
        //alert(activeElement);
        //alert("Ultimo else");
    }
    // Ya tiene valor active elemento, ahora trabaja para safari
    //alert(activeElement.nodeType);
    if (activeElement.nodeType == 3) {  // defeat Safari bug   Si es safari, toma el elemento con parentNode
        activeElement = activeElement.parentNode;
    }
    return activeElement;
}

//#####################################################################################################
//      addEventListener, attachEventListener o NS4 o IE5 MAC
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
function AttachEvent(obj, evt, fnc, useCapture) {
    //alert("AttachEvent se disparó");
    try {
        if (!useCapture) useCapture = false;        // ! es no igual.
        if (obj.addEventListener) {     //  W3C DOM, FireFox
            //alert("addEventListener");
            obj.addEventListener(evt, fnc, useCapture);
            return true;
        } else if (obj.attachEvent) {
            //alert("attachEventListener");
            return obj.attachEvent("on" + evt, fnc);
        } else {
            // alert("NS4 o IE5MAC sin attachEvent");
            // alert("obj=" + obj + "evt=" + evt + "fnc=" + fnc);
            MyAttachEvent(obj, evt, fnc);
            obj['on' + evt] = function () { MyFireEvent(obj, evt) };
        }
    }
    catch (Err) {
        alert("AttachEvent= " + Err);
    }
}

//The following are for browsers like NS4 or IE5Mac which don't support either
//attachEvent or addEventListener
function MyAttachEvent(obj, evt, fnc) {
    // alert("MyAttachEvent obj=" + obj + "evt=" + evt + "fnc=" + fnc);
    try {
        if (!obj.myEvents) obj.myEvents = {};
        if (!obj.myEvents[evt]) obj.myEvents[evt] = [];
        var evts = obj.myEvents[evt];
        evts[evts.length] = fnc;
    }
    catch (Err) {
        alert("MyAttachEvent= " + Err);
    }
}

function MyFireEvent(obj, evt) {
    try {
        if (!obj || !obj.myEvents || !obj.myEvents[evt]) return;
        var evts = obj.myEvents[evt];
        for (var i = 0, len = evts.length; i < len; i++) evts[i]();
    }
    catch (Err) {
        alert("MyFireEvent= " + Err);
    }
}
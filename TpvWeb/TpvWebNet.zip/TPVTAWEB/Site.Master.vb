﻿Imports TPVTAWEB.BDCnxADO   'Importa el Módulo para trabajar con las Bases de Datos

Public Class Site
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim Col As Integer
        Dim Fil As Integer
        NomDataTble = "DTSQL"
        Dim MenuSQL As String = ""
        Dim UserName As String = ""
        Dim UserPerf As String = ""

        If Not Page.IsPostBack Then
            '************************************************** INICIO **********************************************************
            '<<<<<<<< Procedimiento para conectarse y Ejecutar consultas >>>>>>>>>>>>>
            Rtado = ADOCnxBD("TPV")             'Llama a la funcion para conectar a la BD, de la hoja BDCnxADO
            '   Response.Write(Rtado & "<br>")      'Escribe si se conecto OK o NO
            'Realiza una consulta a la BD, genera un dataset
            If Page.User.Identity.IsAuthenticated Then
                'Dim LoggIn1 As Control = HeadLoginView.FindControl("HeadLoginName")
                'UserName = LoggIn1.UniqueID
                'Toma el perfil de usuario y en base a eso despliega el menu
                UserName = Page.User.Identity.Name.ToString()
                'Rtado = SqlBD("[PVTWEB].[dbo].[GU01_USUPER]", UserName, NomDataTble, "TPV", "DataReader")
                'Dim DtRFActuales() As DataRow = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)
                ''Itera por los datos
                'For Fil = 0 To DtRFActuales.Length - 1
                '    UserPerf = DtRFActuales(Fil)("GUS03_PERABR").ToString()
                'Next Fil

                Rtado = SqlBD("[PVTWEB].[dbo].[GRL_MENU]", "P1:" & UserName, NomDataTble, "TPV", "DataReader")
            Else
                UserName = Page.User.Identity.Name.ToString()
                Rtado = SqlBD("[PVTWEB].[dbo].[GRL_MENU]", "P1:USUGRAL", NomDataTble, "TPV", "DataReader")
                'ERROR - cuando trae un error debe salir de aquí
            End If

            'Aqui se obtuvieron los datos para que en el encabezado se arme el Menu
            'El resto se debe eliminar

            '   Response.Write(Rtado & "<br>")      'Escribe si se realizo la consulta OK o NO, si funcionó la funcion.
            Dim DtRFilasActuales() As DataRow = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)     '   2.- Tomo las filas en la variable = FilasActuales como DataRow
            'Los datos Ya estan en el DataRow, ahora hay que navegar por ellos para agregar los atributos
            '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FIN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

            'Itera por los datos
            For Fil = 0 To DtRFilasActuales.Length - 1
                For Col = 0 To dbDTable.Columns.Count - 1
                    If Col = 0 Then
                        MenuSQL = MenuSQL & DtRFilasActuales(Fil)(Col).ToString()
                    Else
                        MenuSQL = MenuSQL & "," & DtRFilasActuales(Fil)(Col).ToString()
                    End If
                Next Col
            Next Fil

            HiddenField1.Value = MenuSQL

        End If
    End Sub
End Class


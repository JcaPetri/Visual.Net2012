﻿'Este es el Modulo para conectarse con la Base de Datos
Imports System.Data.SqlClient

Module BDCnxADO
    'Variables Generales
    Friend dbCon As Data.SqlClient.SqlConnection         'Asigna a la variable dbConn la propiedades SqlConnection
    Friend dbCmd As Data.SqlClient.SqlCommand            'Asigna a la variable dbCmd la propiedad de SqlCommand
    Friend CadConx As String = ""                        'CadCon es la cadena con la que conectaremos a la base de datos.

    Friend dbDAdapter As Data.SqlClient.SqlDataAdapter   'Asigna a la variable SqlDataAdapter
    Friend dbDSet As Data.DataSet                        'Asigna a la variable DataSet
    Friend dbDTable As Data.DataTable                    'Asigna a la variable DataTable
    Friend dbDReader As Data.SqlClient.SqlDataReader     'Asigna a dbDataReader la propiedad de SqlDataReader

    Friend Rtado As String                              'Obtiene el resultado de las funciones
    Friend RtadoReader As String
    Friend NomDataTble As String

    '<<<< Se crea un procedimiento en el modulo para la conexión a la BD >>>>
    Friend Function ADOCnxBD(ByVal BDNom As String) As String      'Se definen 1 parámetros, Nombre Base de Datos y Consulta Inicial
        'Para conectar a la base de datos y crear los objetos que cargarán la tabla.
        'El valor de la base de datos viene del Cliente cuando se llama a la función de apertura de la conexión BDNom

        '1) Nombre de la base de datos
        If BDNom = "" Then              'Si el nombre de la BD o SQL NO es vacio, sale de la función
            ADOCnxBD = "BDDatErr001 - No se especificó la Base de Datos"    'Este es el código de error de la BD, genera un error en la BD.
            Return ADOCnxBD
            Exit Function
        End If

        'Define la cadena de conexión a la BD
        ''CONEXION EN LA MI PC
        CadConx = "Data Source=NOTEBOOKJCP;" & _
                 "Initial Catalog=" & BDNom & ";" & _
                 "Integrated Security=SSPI;Persist Security Info=True;" & _
                 "Workstation ID=NOTEBOOKJCP;Packet Size=4096"

        '' CONEXION EN TAGLE  sys-desarrollo
        'CadConx = "Data Source=10.1.4.35;" & _
        '            "Initial Catalog=PVTWEB;" & _
        '            "Persist Security Info=True;" & _
        '            "User ID=sa;Password=aplicaciones"
        

        Try     'Realiza la conexión, si da error lo informa y sale de la función
            dbCon = New Data.SqlClient.SqlConnection(CadConx)
        Catch ex As Exception
            ADOCnxBD = "BDConErr002=" & ex.Message.ToString
            Return ADOCnxBD
            Exit Function
        End Try

        Try     'Abre la Base de Datos, si da error lo informa y sale de la función
            dbCon.Open()
        Catch ex As Exception
            ADOCnxBD = "BDConErr003=" & ex.Message.ToString
            Return ADOCnxBD
            Exit Function
        End Try

        'Si llega a esta instancia es que realizo la conexión OK, lo informa
        ADOCnxBD = "BDConOK"
        Return ADOCnxBD
    End Function

    '<<<< Se crea un procedimiento en el modulo para ejecutar una consulta SQL>>>>
    Friend Function SqlBD(ByVal CmdStr As String, Optional ByVal SQLPar As String = "", Optional ByVal NomDT As String = "BDT", Optional ByVal BDnomDef As String = "", Optional ByVal TipoDT As String = "") As String     'Se definen 1 parámetros, Consulta
        'Los parámetros que se pasan con CmdStr = sentencia SQL, NomDT = valor al que se asignarán los valores obtenidos, BDnomDef = Nombre de la Base de Datos
        Dim ConRtado As String = ""     'Registra el resultado de la conexión

        If CmdStr = "" Then       'Si el nombre de la sentencia SQL es vacio, sale de la función
            SqlBD = "SqlErr001=SinSQL"
            Return SqlBD
            Exit Function
        End If

        If dbCon Is Nothing Then       'Verifica si la conexion esta generada, si no es así la crea
            ConRtado = ADOCnxBD(BDnomDef)  'Llama a la función de conexión con la BD por defecto
            If ConRtado <> "BDConOK" Then   'Si la conexión dio error lo informa
                SqlBD = "SqlErr002=" & ConRtado
                Return SqlBD
                Exit Function
            End If
        End If

        If dbCon.State <> ConnectionState.Open Then    'Verificar el estado, si no esta abierta la abre
            Try
                dbCon.Open()   'Abre la conexión
            Catch ex As Exception
                SqlBD = "SqlErr003=Abre x Estado" & ex.Message.ToString
                Return SqlBD
                Exit Function
            End Try
        End If

        If TipoDT = "DataSet" Then
            'Realiza la conexión a la Base de Datos y Ejecuta la consulta
            Try     'Creamos el objeto DataAdapter con la consulta SQL y la conección definida
                'Dim commandBuilder As New Data.SqlClient.SqlCommandBuilder(dbDataAdapter)   'Se utiliza para actualizar la base de datos
                'dbDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey          'Si la tabla no tiene clave primaria se la asigna

                dbDAdapter = New Data.SqlClient.SqlDataAdapter(CmdStr, dbCon)
            Catch ex As Exception
                SqlBD = "SqlErr-DataAdapter" & ex.Message.ToString
                Return SqlBD
                Exit Function
            End Try

            'Genera el DataSet
            dbDSet = New Data.DataSet()            'Creamos el objeto DataSet
            Try     'Trata de realizar la toma de datos, si se produce un error lo intercepta.
                dbDAdapter.Fill(dbDSet, NomDT)   'Llena el dataset con la info del data adapter, el segundo parametro es el nombre que le damos a la Table
            Catch ex As Exception
                SqlBD = "SqlErr-DataSet" & ex.Message.ToString
                Return SqlBD
                Exit Function
            End Try
        ElseIf TipoDT = "DataReader" Then
            'Realiza la conexión a la Base de Datos y Ejecuta la consulta

            Try     'Trata de realizar la toma de datos, si se produce un error lo intercepta.
                dbCmd = New Data.SqlClient.SqlCommand(CmdStr, dbCon)    'Se genera una nueva conexión
                dbCmd.CommandType = CommandType.StoredProcedure
                dbCmd.CommandTimeout = 120

                'Determina los parámetros que tiene la consulta, para ello toma los datos de la variable SQLPar
                Dim SqlParArr As String()
                Dim SqlParItm As String
                Dim ParNum As Integer = 0
                Dim VarParValor() As String
                If SQLPar <> "" Then
                    If SQLPar <> "NULL" Then
                        SqlParArr = SQLPar.Split("|")   'Obtiene los distintos parámetros @ParNum : Valor
                        For Each SqlParItm In SqlParArr
                            Dim objParam As SqlParameter
                            'VarParValor = SqlParArr(SqlParItm).Split(":")        'De cada parámetro separa el @Par : Valor
                            VarParValor = SqlParItm.ToString.Split(":")
                            ParNum = Val(VarParValor(0).ToString.Replace("P", ""))
                            'ParNum = Val(Replace("P", VarParValor(0).ToString, "", 1, , CompareMethod.Text))
                            objParam = dbCmd.Parameters.Add("@PAR" & ParNum, SqlDbType.NVarChar)    ', SqlDbType.Int
                            objParam.Direction = ParameterDirection.Input
                            objParam.Value = VarParValor(1).ToString
                        Next
                    End If
                    'AQUÍ HAY QUE VERIFICAR EL PARÁMETRO, Y EL NÚMERO DE PARÁMETRO, YA NO ES EL NÚMERO ASCENDENTE, SINO EL NÚMERO QUE TIENE ASIGNADO.

                    'Dim VarPar As String = ""
                    'Dim VarParOrd() As String
                    'Dim VarParNum() As String
                    'Dim VPCant As Integer = 0
                    'VarParOrd = VarParAcum.Split("|")
                    'For VPCant = 0 To VarParOrd.Length - 1
                    '    VarParNum = VarParOrd(VPCant).Split(":")
                    '    Select Case VarParNum(0)
                    '        Case "P1"
                    '            VarPar = VarParNum(1)
                    '        Case "P2"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P3"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P4"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P5"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P6"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P7"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P8"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P9"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P10"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P11"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P12"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case "P13"
                    '            VarPar = VarPar & "|" & VarParNum(1)
                    '        Case Else
                    '            VarPar = VarParAcum
                    '    End Select
                    'Next VPCant
                Else
                    'Si no tiene parámetros no hace nada
                End If

                dbDReader = dbCmd.ExecuteReader()                       'Se carga el datareader

                dbDTable = New Data.DataTable                          'Se genera una nueva DataTable
                dbDTable.Load(dbDReader)                               'Se carga el DataTable con el Reader

                'Luego de leer los datos los cierra.
                dbDReader.Close()
                dbCon.Close()

            Catch ex As Exception
                ' Borrar el Dataview
                SqlBD = "SqlErr-DataReader" & ex.Message.ToString & "/" & dbCmd.ToString
                Return SqlBD
                Exit Function
            End Try
        Else
            SqlBD = "SqlErr-SinEspecTipoDT"
            Return SqlBD
            Exit Function
        End If

        'Si llega a esta instancia es que realizo la consulta OK, lo informa
        SqlBD = "SqlOK"
        Return SqlBD
    End Function
End Module

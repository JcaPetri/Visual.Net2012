﻿Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient

Namespace AASPNET
    Public Class BaseDatos

    End Class
End Namespace

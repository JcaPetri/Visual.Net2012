﻿Public Class PagEnc
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim MenuSQL As String = ""
        '   Response.Write(Rtado & "<br>")      'Escribe si se realizo la consulta OK o NO, si funcionó la funcion.
        Dim DtRFilasActuales() As DataRow = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)     '   2.- Tomo las filas en la variable = FilasActuales como DataRow
        'Los datos Ya estan en el DataRow, ahora hay que navegar por ellos para agregar los atributos
        '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FIN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        'Itera por los datos, y arma el Menu
        Dim Fil As Integer
        Dim NumItem As String     'Numero ascendente para el número del item
        Dim NivelActual As Integer = 1
        Dim ItemAMostrar As String = ""
        Dim HrefVinculo As String = ""
        Dim DifNiv As Integer = 0
        Dim ContNiv As Integer = 0
        NumItem = 0
        If DtRFilasActuales.Length > 0 Then
            For Fil = 0 To DtRFilasActuales.Length - 1
                'TOMA LOS DATOS
                '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                'Permite definir el código unico del item
                NumItem = NumItem + 1
                'Aquí ya tenemos el Dato, ahora hay que armar la estructura del Menu
                'Obtenemos el Valor
                ItemAMostrar = Replace(DtRFilasActuales(Fil)(0).ToString(), "|", "")
                'Obtenemos el vinculo
                HrefVinculo = DtRFilasActuales(Fil)(1).ToString() : If HrefVinculo = "" Then HrefVinculo = "#"

                'INICIA MENU
                '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                If Fil = 0 Then
                    'Abre el Menu
                    Panel01.Controls.Add(New LiteralControl("<div id=""menucont"">"))
                    Panel01.Controls.Add(New LiteralControl("<ul id=""menuul"" class=""menunav"">"))
                End If

                'ITEMS DEL MENU
                '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                'Debemos definir el nivel del menu y sus dependencia
                If NivelActual = DtRFilasActuales(Fil)(10).ToString() Then
                    'El mismo nivel
                    'Cierra el item siempre y cuando no sea el primer item
                    If Fil <> 0 Then
                        Panel01.Controls.Add(New LiteralControl("</li>"))
                    End If
                ElseIf NivelActual < DtRFilasActuales(Fil)(10).ToString() Then
                    'Baja un nivel ,abre el UL, abre el LI y marca que se abrió un Subnivel
                    Panel01.Controls.Add(New LiteralControl("<ul>"))
                ElseIf NivelActual > DtRFilasActuales(Fil)(10).ToString() Then
                    'Sube la cantidad de niveles según la diferencia que hay entre el nivel actual y el anterior
                    ', debe cerrar el UL y el LI, ya que el nivel más bajo esta dentro de un LI
                    DifNiv = NivelActual - DtRFilasActuales(Fil)(10).ToString()
                    For ContNiv = 1 To DifNiv
                        Panel01.Controls.Add(New LiteralControl("</li>"))       'Cierra el LI del item
                        Panel01.Controls.Add(New LiteralControl("</ul>"))       'Cierra el UL sel submenu
                        Panel01.Controls.Add(New LiteralControl("</li>"))       'Cierra el LI del submenu
                    Next ContNiv
                End If

                'Abre el Item
                Panel01.Controls.Add(New LiteralControl("<li>"))
                If Fil = 0 Then 'Si es el primer item lo posiciona como el MenuActivo por defecto
                    Panel01.Controls.Add(New LiteralControl("<a class=""menuactive"" href=""" & HrefVinculo & """>" & ItemAMostrar & "<span class=""flecha"">&#9660</span></a>"))
                Else
                    Panel01.Controls.Add(New LiteralControl("<a href=""" & HrefVinculo & """>" & ItemAMostrar & "<span class=""flecha"">&#9660</span></a>"))
                End If

                'Releva el nivel del item del nivel actual, por cada fila en la celda Diez esta el nivel
                NivelActual = DtRFilasActuales(Fil)(10).ToString()

                'FINALIZA MENU
                '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                If Fil = DtRFilasActuales.Length - 1 Then
                    'Cierra el Menu
                    Panel01.Controls.Add(New LiteralControl("</li>"))       'Cierra el último item
                    Panel01.Controls.Add(New LiteralControl("</ul>"))       'Cierra el Menu
                    Panel01.Controls.Add(New LiteralControl("</div>"))      'Cierra el DIV
                End If
            Next Fil
        Else
            'No tiene Menu
        End If
    End Sub

End Class
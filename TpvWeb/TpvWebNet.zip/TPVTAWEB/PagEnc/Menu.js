﻿// -- Style Names
var itemStylesNames = ["Top Item", ];   // ["Top Item", ] Si esto está habilitado, no funcionan las variables individuales
var menuStylesNames = ["Top Menu", ];   // ["Top Menu", ] "Submenu" Si esto está habilitado, no funcionan las variables individuales
// -- Fin de Style Names

// -- Common
//var menuIdentifier="deluxeMenu";
var isHorizontal = 1;       // Determina si el menu se muestra horizontal=1 o vertical=0
var smColumns = 1;          // Cantidad de columnas del SubMenu como se despliga el menu =1, 2, 3
var smOrientation = 0;      // Determina la orientación del SubMenu horizontal=1 o vertical=0
var smViewType = 0;         // Orden que aparece el SubMenu 0=De Izq a Der hacia Abajo, 1= De Izq a Der hacia Arriba, 2=De Der a Izq hacia Abajo, 1= De Der a Izq hacia Arriba
var dmRTL = 0;              // Se usa cuando utilizamos páginas de Der a Izq
var pressedItem = -2;       // El número de menú que estará por defecto mas iluminado, -2 deshabilitado, -1 habilitado pero ninguno seleccionado, 0...10 item habilitado y seleccionado
var itemCursor = "";
var itemTarget = "_self";   // Si mismo, en la misma ventana
var statusString = "text";    // Testo que se muestra en la barra de estado cuando uno posiciona el mouse arriba del item, "link" = muestra el link a donde va; "text" = muestra el texto del item; "tip" = muestra el mensaje cuando pasas por arriba
var blankImage = ResolveUrl("~/Imagenes/MenuImg/back.gif");      // Dirección a la imagen en blanco, usualmente es una imagen de 1x1 px gif con fondo transparente

//--- Dimensions
var menuWidth = "";             // 100% Es el porcentaje horizontal que ocupa el menu en la pantalla.
var menuHeight = "8px";         // Es la altura del Menu si no se pone el tamaño depende del texto 20px
var smWidth = "";          // Es el ancho total del submenu cuando se desplega  150px
var smHeight = "";              // Es la altura total del submenu cuando se desplega

//--- Positioning
var absolutePos = 0;    // Si es 1 la posición es absoluta y no ocupa espacio en la pagina, 0 Ocupa espacio
var posX = "0";         // Distincia entre la esquina sup izq hacia la derecha
var posY = "0";         // Distincia entre la esquina sup izq hacia la abajo
var topDX = -10;        // Distancia del submenu desde la derecha
var topDY = -1;        // Distancia del Submenu desde arriba
var DX = 0;             //-5
var DY = 0;             //

//--- Font
var fontStyle = ["bold 12px Arial", "bold 12px Arial"];   // Estilo de la letra    bold 10px Tahoma,  Narrow
var fontColor = ["#999999", "#000000"];     // 1.- Color de la letra normal y 2.- cuando se pasa el mouse por arriba
var fontDecoration = ["none", "none"];      // 1.- Decoración Normal y 2.- Cuando se pasa el mouse por arriba. Opciones = none, underline, line-through, overline
var fontColorDisabled = "#3C3C3C";          // #AAAAAA Color de la fuente cuando el item está deshabilitado

//--- Appearance
var menuBackColor = "#FFFFFF";              //  Color del fondo del menu, esto es lo que esta debajo de los botones, transparent
var menuBackImage = "";
var menuBackRepeat = "repeat";              // Opciones = repeat, repeat-x, repeat-y, no-repeat
var menuBorderColor = "#00ffff";            // Color del borde del menu        #999999  #C0AF62 #C0C0C0
var menuBorderWidth = "0px";                // Borde del menu, de 0 a más 1
var menuBorderStyle = "solid";              // Opciones = none, solid, double, dotted, dashed, groove, ridge
var smFrameImage = ResolveUrl("~/Imagenes/MenuImg/SubRecuadEntero.png");          //../Imagenes/MenuImg/btn_back_1.gif
var smFrameWidth = 1;

//--- Item Appearance
var itemBackColor = ["#FFFFFF", "#c0c0c0"];      // ["#FCEEB0", "#65BDDC"] #F2F2F2Color de los items cuando se despliegan y el color de los items cuando se los selecciona, Pueden ser transparent,transparent
var itemBackImage = ResolveUrl("");              //~/Imagenes/MenuImg/btn5_blueWit3.gif ~/Imagenes/MenuImg/btn5_blueWit1sbc.gif", ~/Imagenes/MenuImg/btn5_blueWit3.gif
var itemSlideBack = 0;
var itemBorderWidth = "0px";                        //Pueden ser 1, 0
var itemBorderColor = ["#C0C0C0", "#4C99AB"];           //"#FCEEB0", "#4C99AB"     Borde del item, si tiene valor todos los items tienen borde, el segundo es cuando se selecciona.
var itemBorderStyle = ["solid", "solid"];               //"solid", "solid"
var itemSpacing = 0;                            //Espacio entre los distintos botones de menu, 1, 2
var itemPadding = "5px 5px 10px 10px";          // 4pxTamaño del boton, arriba, derecha, abajo, izquierda, el relleno   5px 5px 10px 10px
var itemAlignTop = "center";
var itemAlign = "left";
var subMenuAlign = "left";          // en la nueva versión no esta
var subMenuVAlign = "";             // ptop 
var itemCursor = "pointer";

////--- Item Icons
var iconTopWidth = 16;
var iconTopHeight = 16;
var iconWidth = 16;
var iconHeight = 16;
var arrowImageMain = [ResolveUrl("~/Imagenes/MenuImg/arrowmain.gif"), ResolveUrl("~/Imagenes/MenuImg/arrowmaino.gif")];    // Imagen a la derecha, cuando tiene subitems. En estado Normal y cuando se pasa el mouse       
var arrowWidth = 8;    // Ancho de la viñeta a la derecha del texto
var arrowHeight = 16;   // Alto de la viñeta a la derecha del texto
var arrowImageSub = [ResolveUrl("~/Imagenes/MenuImg/arrowsub.gif"), ResolveUrl("~/Imagenes/MenuImg/arrowsubo.gif")];  // Imagen a la derecha, cuando los SubItems tiene a su vez descendientes. En estado Normal y cuando se pasa el mouse    
var arrowWidthSub = 8;
var arrowHeightSub = 16;

//--- Separators
var separatorImage = "";
var separatorColor = "";
var separatorWidth = "0%";              // 100%
var separatorHeight = "0px";            //3px
var separatorAlignment = "center";
var separatorVImage = "";
var separatorVColor = "";
var separatorVWidth = "0";            //3px
var separatorVHeight = "0%";              // 100%
var separatorPadding = "0px";

//--- Floatable Menu
var floatable = 0;
var floatIterations = 8;  // Velocidad con la que aperece el menu desplegable
var floatableX = 1;
var floatableY = 1;
var floatableDX = 15;
var floatableDY = 15;

//--- Movable Menu
var movable = 0;    //Habilita la X del menu principal
var moveWidth = 12;
var moveHeight = 20;
var moveColor = "";
var moveImage = "";
var moveCursor = "auto";
var smMovable = 0;    // Habilita la opción del boton X para cerrar el submenu
var closeBtnW = 15;   // Tamaño de la imagen que va en la X
var closeBtnH = 15;   // Tamaño de la imagen que va en la X
var closeBtn = "";    // Imagen que va en la X
var blankImage = "";

//--- Transitional Effects & Filters
var transparency = "100";      // Transparencia del Menu y SubMenu hacia la pagina de atras, en % 100=Se ve todo, 20=Casi transparente
var transition = 104;  // Indice del tipo de transición con el que aprece el submenu, los efectos superiores a 24 tienen parámetros adicionales
var transOptions = "";
var transDuration = 550;  // Demora para que aparezca el submenu a traves de la transición
var transDuration2 = 200; // Demora para que desaparezca el submenu a traves de la transición
var shadowLen = 0;    // Tamaño de la sombra
var shadowColor = "#B1B1B1";  // Color de la transición - ver en C:\Program Files\Deluxe Tuner\help\transitions.html
var shadowTop = 0;    // La sombra del menú principal habilitada=1, deshabilitada=0
var onOverSnd = "";
var onClickSnd = "";

//--- CSS Support (CSS-based Menu)
var cssStyle = 0;       // Habilita=1 o Deshabilita=0, la opción de espcificar el estilo de texto de todo el menu con un estilo
var cssSubmenu = "";
var cssItem = ["", ""];
var cssItemText = ["", ""];

//--- Advanced
var dmObjectsCheck = 0;   // Relación que tiene el menu con el resto de los objetos en la pagina Deshabilitado=0, Habilitada=1 
var saveNavigationPath = 1;
var showByClick = 0;        // Muestra los submenu si se le hace click unicamente, Habilitado=1, Deshabilitado=0
var noWrap = 1;             // Amplia el tamaño del boton en función al texto, habilitado=1, deshabilitado=0 (aquí vueve de carro)
var pathPrefix_img = "";    // Menu.files/ Si esto esta mal no encuentra las imágenes de los botones
var pathPrefix_link = "";
var smShowPause = 200;    // La demora hasta que aparece el submenu
var smHidePause = 1000;   // La demora hasta que se oculta el submenu
var smSmartScroll = 1;    // Habilita el scroll en el submenu
var topSmartScroll = 0;
var smHideOnClick = 1;
var dm_writeAll = 0;
var useIFRAME = 0;
var popupMode = 0;


//--- AJAX-like Technology -- Esto es para cambiar el menu dinamicamente
var dmAJAX = 0;
var dmAJAXCount = 0;

//--- Dynamic Menu -- esto es para cambiar el menu dinamicamente
var dynamic = 0;

//--- Keystrokes Support
var keystrokes = 0;   // Habilita=1 o Deshabilita el uso del teclado para manejar el menu Ctrl+F2 foco en el menu, Flechas para navegar, Enter activar, Esc para salir
var dm_focus = 1; // Boton que toma primero el foco
var dm_actKey = 113; // Tecla para acceder al menu, 113=F2, 114=F3, 115+F4, etc

//--- Deprecated Features
var beforeItemImage = ["", ""];
var afterItemImage = ["", ""];
var beforeItemImageW = "";
var afterItemImageW = "";
var beforeItemImageH = "";
var afterItemImageH = "";
var statusString = "";
var itemTarget = "";
var dmSearch = 0;


var itemStyles = [""];
var menuStyles = [""];

//var itemStyles = [
//    ["itemBackColor=transparent,transparent", "itemBorderWidth=1", "fontStyle=bold 12px Tahoma", "fontColor=#FFFFFF,#0000FF", "itemBackImage=../Imagenes/MenuImg/btn5_blueWit1sbc.gif,Imagenes/MenuImg/btn5_blueWit3.gif"],
//];  // "itemWidth=123px", se lo saque y no paso nada.  Ancho de los botones     blanco = #FFFFFF negro = #000000
//var menuStyles = [
//   ["menuBackColor=transparent", "menuBorderWidth=1", "itemSpacing=1", "itemPadding=5px 10px 10px 10px"],
//];  // Distancia del texto a la izquierda, arriba, abajo, a la derecha


// 17 o 18 letras = 120px de ancho

//Toma el valor del formulario VB
//var menuDeVar = document.forms["ctl01"].elements["ctl00$TextBox2"].getAttribute("jsMenu");
var menuDeVar = document.forms["ctl01"].elements["ctl00$HiddenField1"].getAttribute("value");
// Genera la matriz multidimencional
var menuItems = menuDeVar.split("#");
for (var i = 0; i < menuItems.length; i++) {
    var tmp = menuItems[i].split(",");
    menuItems[i] = new Array();
    for (var j = 0; j < tmp.length; j++)
         menuItems[i][j] = tmp[j];
}

//Ejemplo de menu estático
//var menuItems = [
////[1.-"Texto del boton", 2.-"Página que abre", 3.-"Imagen a la izquierda del texto", 4.-"Imagen a la derecha del texto", 5.-"Mensaje Cuando Pasa el Mouse arriba", 6.-"Como abre el vinculo Target (_self, _blank, _top, _parent, _search, _custom), 7.-habilitado "0" o Deshabilitado "_" esto se combina con el target custom, 8.-"Item Style", 9.-"SubmenuStyle", 10.-"archivo Javascript que contiene los items del submenu que seran leidos desde el servidor"],
//    ["Home", "Default.aspx", , , , , "0", , , ],
//        ["|Quienes Somos?", "javascript:document.getElementById('MarcDer').src = 'General/QuienesSomos.aspx'", , , , , "0", , , ],
//        ["|Nuestra Vision", "javascript:document.getElementById('MarcDer').src = 'General/NuestraVision.aspx'", , , , , "0", , , ],
//    ["Nuestros Servicios", "", "", "", "Servicios por Tipo de Empresa", , "0", , , ],
//        ["|Emprendedores", "", , , , , , , , ],
//            ["||El Emprendedor", "", , , , , , , , ],
//            ["||La idea del Negocio", "", , , , , , , , ],
//            ["||El Mercado", "", , , , , , , , ],
//            ["||La Microempresa", "", , , , , , , , ],
//            ["||El Plan de Negocios", "", , , , , , , , ],
//            ["||Calidad", "", , , , , , , , ],
//            ["||Financiamiento", "", , , , , , , , ],
//        ["|PyMES", "", , , , , , , , ],
//            ["||Recursos Humanos", "", , , , , , , , ],
//                ["|||Seleccion de Personal", "", , , , , , , , ],
//                ["|||Formacion de Personal", "", , , , , , , , ],
//            ["||Contabilidad", "", , , , , , , , ],
//                ["|||Impuestos", "", , , , , , , , ],
//                ["|||Contabilidad General", "", , , , , , , , ],
//                ["|||Liquidacion de Sueldos", "", , , , , , , , ],
//            ["||Calidad", "", , , , , , , , ],
//                ["|||Gestion y Mejora de Procesos", "", , , , , , , , ],
//        ["|G.Empresas", "", , , , , , , , ],
//            ["||Recursos Humanos", "", , , , , , , , ],
//                ["|||Seleccion de Personal", "", , , , , , , , ],
//                ["|||Formacion de Personal", "", , , , , , , , ],
//            ["||Comercial", "", , , , , , , , ],
//                ["|||Formacion Equipos Ventas", "", , , , , , , , ],
//                ["|||Capacitacion Equipos Ventas", "", , , , , , , , ],
//    ["Formacion y Capacitacion", "", "", "", , , "0", , , ],
//        ["|Gerencial", "", , , , , , , , ],
//            ["||Coaching", "", , , , , , , , ],
//            ["||Negociacion", "", , , , "_", , , , ],
//        ["|Comercial", "", , , , , , , , ],
//            ["||Venta BN", "", , , , , , , , ],
//        ["|Informatica", "", , , , , , , , ],
//            ["||Excel Nivel Inicial", "javascript:document.getElementById('MarcDer').src = 'FormyCapac/Informatica/XLSNI.aspx'", , , , , , , , ],
//            ["||Excel Nivel Avanzado", "javascript:document.getElementById('MarcDer').src = 'FormyCapac/CursosPresenciales.aspx'", , , , , , , , ],
//        ["|Cursos E-Learning", "", , , , , , , , ],
//    ["Consultoria", "", "", "", , , "0", , , ],
//        ["|Evaluacion Proy. Inversion", "", , , , , , , , ],
//        ["|Control de Gestion", "", , , , , , , , ],
//    ["Sistemas Informaticos", "", "", "", , , "0", , , ],
//        ["|Desarrollos Web", "", , , , , , , , ],
//            ["|Desarrollos Flash", "", , , , "_", , , , ],
//            ["|Desarrollos .NET", "", , , , "_", , , , ],
//    ["Calidad", "", "", "", , , "0", , , ],
//        ["|Gestion y Mejora de Procesos", "", , , , , , , , ],
//];


function IraOtraPag(url) {
    // Abre una página en la misma ventana actual   /JCPEConsulting/Default.aspx
    var VincCompleto = ResolveUrl(url);
    //    alert(VincCompleto);
    window.open(VincCompleto, "_self");
};


function ResolveUrl(url) {
    if (url.indexOf("~/") == 0) {
        var urlpart1 = baseUrl;
        var urlpart2 = url.substring(2);
        var urlTxt = urlpart1 + urlpart2;
        url = urlTxt
    }
    return url;
};

dm_init();
//  dm_initFrame("Marc", 1, 0, 0);
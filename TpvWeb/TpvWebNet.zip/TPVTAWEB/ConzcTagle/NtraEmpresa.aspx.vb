﻿Public Class NtraEmpresa
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Img01.ImageUrl = "~/Imagenes/PostVta/Tagle.jpg"
    End Sub

End Class


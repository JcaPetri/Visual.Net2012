﻿Imports TPVTAWEB.BDCnxADO   'Importa el Módulo para trabajar con las Bases de Datos
Imports TPVTAWEB.Tbla       'Importa el Módulo para trabajar con las Tablas
Imports System.Globalization

Public Class PruebaTablas
    Inherits System.Web.UI.Page
    Friend TblaTxtMultValenArray(,) As String
    Friend TblaRangoFormatoArray(,) As String
    Friend TblaRangoFtoArrFilTot As Integer = 0     'TblaArrFilTot
    Friend TblaRangoFtoArrColTot As Integer = 0     'TblaArrColTot
    Friend FtoAplicar(,) As String                  'Matriz con los datos de los parámetros, sus valores y su nivel.
    Friend TablaDinam(,) As String                     'Matriz con los datos de la Tabla Dinámica
    Friend TablaDinamTotal(,) As String             'Matriz con el calculo de los Totales
    Public Var01Pas As String = ""
    Friend InfoTiempoInfGral As String = ""                 'Registra el Informe General, luego puede tener otros informes
    Friend InfoTiempoInfEsp As String = ""                  'Registra el Informe Individual
    Friend InfoTiempo As String = ""                        'Registra los tiempos de informe
    Friend InfoTiempoEjecucion As Date                          'Registra el Inicio
    Friend InfoTiempoDesde As Date                          'Registra el Inicio

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim TpoInfInicio As Date = TimeOfDay
        Dim InfoTiempoEjecucion As Date = TimeOfDay

        'Registra la marca de tiempos
        InfoTiempoDesde = TimeOfDay

        NomDataTble = "DTSQL"
        Dim Fil As Integer
        'Dim Col As Integer
        Dim MyStringBuilder As New StringBuilder

        'Toma los datos del Querystring y los carga en las variables
        Dim QKeys, QVal As Integer
        Dim KeysVal(), DatVal() As String
        Dim TblCod As String = ""
        Dim ProAlm As String = ""
        Dim VarPar As String = ""
        Dim VarParAcum As String = ""
        Dim DatQStrin As NameValueCollection
        Dim DtRFilAct() As DataRow
        Dim DtRIFilAct() As DataRow
        Dim TblRelac As String
        Dim TblTitulo As String = ""        'Variable para cargar el Titulo de informe
        Dim TblTitVinculo As String = ""
        Dim TblCssGral As String = ""
        Dim TblFormCss As String = ""
        Dim TblRangDatCalc As String = ""
        Dim TblOrden As String = Nothing
        Dim TablaAsig As String = "Table01"
        Dim TipoInforme As String = "TABLA"
        Dim VarParVinc As String = ""
        Dim TblOpcBusqDatos As String = ""          'Var para cargar el combo de opciones para cambiar el buceo / búsqueda de datos.
        Dim BucearOpcEleg As String = ""             'Var para definir el formato del combo de opciones
        Dim BucearOpcElegValor As String = ""       'Var con el valor elegido por el usuario
        Dim VarProxBuceoDat As String = ""             'Var con la info del dato para armar el proximo RadioButton de opciones para el buceo
        Dim TblFecActDatos As String = ""
        Dim BarraDirecc As String = ""              'Determina de donde viene el click, esto es para evitar que cuando se consulta el menu vuelva a tirar la consulta con los parámetros de la barra de direcciones

        '####### INICIO DE OBTENCIÓN DE DATOS DEL FORMULARIO #########################################################################################################################################3
        '1.- Obtiene la información de QueryString
        '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

        'Carga la info del querystring en la variable NameValueCollection DatQStrin.
        DatQStrin = Request.QueryString
        ' Pone todas las Claves en un array String.
        KeysVal = DatQStrin.AllKeys
        Dim CadenDecod As String = ""
        For QKeys = 0 To KeysVal.GetUpperBound(0)
            'Response.Write("Key: " & Server.HtmlEncode(KeysVal(QKeys)))
            ' Get all values under this key.
            DatVal = DatQStrin.GetValues(QKeys)
            For QVal = 0 To DatVal.GetUpperBound(0)
                'Response.Write(CStr(QVal) & " = " & Server.HtmlEncode(DatVal(QVal)) & "<br>")
                CadenDecod = Server.HtmlDecode(KeysVal(QKeys))
                If CadenDecod = "TblCod" Then
                    TblCod = Server.HtmlDecode(DatVal(QVal))     'Server.HtmlEncode(
                ElseIf CadenDecod = "TblPars" Then
                    If VarPar = "" Then
                        If InStr(1, Server.HtmlDecode(DatVal(QVal)), "USUNAME", CompareMethod.Text) > 0 Then
                            VarPar = Server.HtmlDecode(DatVal(QVal))
                            VarPar = VarPar.Replace("USUNAME", Page.User.Identity.Name.ToString())
                        Else
                            VarPar = Server.HtmlDecode(DatVal(QVal))
                            If VarParAcum = "" Then
                                VarParAcum = VarPar
                            Else
                                VarParAcum = VarParAcum & "|" & VarPar
                            End If
                        End If
                    Else
                        VarPar = VarPar & "|"
                    End If
                ElseIf CadenDecod = "TblTit" Then
                    TblTitulo = Server.HtmlDecode(DatVal(QVal))
                ElseIf CadenDecod = "BucRdioBut" Then
                    BucearOpcEleg = Server.HtmlDecode(DatVal(QVal))     'Información del Campo elegido
                ElseIf CadenDecod = "ProxBuceo" Then
                    VarProxBuceoDat = Server.HtmlDecode(DatVal(QVal))
                    'ElseIf CadenDecod = "MN" Then
                    '    BarraDirecc = "VieneMenu"
                End If
            Next QVal
        Next QKeys
        InfoTiempoInfGral = TblCod
        TblTitulo = TblTitulo
        VarPar = VarPar
        BucearOpcEleg = BucearOpcEleg
        VarParAcum = VarParAcum

        If Not Page.IsPostBack Then
            'Aquí se ejecuta el formulario por primera vez
            BarraDirecc = BarraDirecc
            'Exit Sub
        Else
            'Dim MarcPag As New Label()
            'MarcPag.ID = "MarcPag"
            'MarcPag.Text = TblCod
            'MarcPag.Visible = "False"
            'Panel1.Controls.Add(MarcPag)

            '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            '2.- Obtiene la información de los campos del formulario
            ' BUSCA LA INFORMACIÓN QUE ESTA EN LOS CAMPOS DEL FORMULARIO Y LOS PASA A UN ARRAY de Campo = Valor
            Dim FormVarArr(,) As String             'Toma los valores del formulario
            Dim FormVar As NameValueCollection      'Variables del formulario
            Dim VarArr() As String                  'Array para tomar los valores de las variables del formulario
            Dim LpArr As Integer                    'Valore para recorrer las variable
            Dim NumCar As Integer                   'Valores para interactuar por los valores de la variable, ya que cada variable es por caracter

            ' Toma las variables del formulario en NameValueCollection variable.
            FormVar = Request.Form
            ' Toma los valores de  las variables del formulario en un array.
            VarArr = FormVar.AllKeys
            ReDim FormVarArr(VarArr.GetUpperBound(0), 1)

            'If BarraDirecc = "VieneMenu" Then

            'End If
            'If VarArr.GetUpperBound(0) = 0 Then

            'End If

            For LpArr = 0 To VarArr.GetUpperBound(0)    'Interactua por las variables del formulario.
                FormVarArr(LpArr, 0) = VarArr(LpArr)    'Nombre de control
                For NumCar = 0 To Request.Form(VarArr(LpArr)).Count - 1     'Este bucle se realiza porque la palabras vienen letra por letra
                    FormVarArr(LpArr, 1) = FormVarArr(LpArr, 1) & Request.Form(VarArr(LpArr))(NumCar).ToString
                Next
            Next LpArr

            'For LpArr = 0 To VarArr.GetUpperBound(0)        'Interactua por las variables del formulario.
            '    'Coincide que se debe Modificar el Vinculo, y que en el link coincide con con Campo que tiene el dato
            '    If BucearOpcEleg <> "" And InStr(FormVarArr(LpArr, 0), BucearOpcEleg, CompareMethod.Text) > 0 Then       'Nombre de control
            '        TblCod = FuncHaceVinc(TblCod, FormVarArr(LpArr, 1), "", "Tbl")                  'Verifica si cambia la TblCod del informe
            '        VarPar = FuncHaceVinc(VarParAcum, FormVarArr(LpArr, 1))                         'Verifica si cambia los parámetros
            '    End If
            'Next LpArr


            'For Each elemento In Request.Form
            '    Response.Write(elemento & ": " & Request.Form(elemento) & "&lt;br&gt;")
            'Next
            'Resultado en las variables:
            '   FormVarArr(LpArr, 0)    Nombre del control
            '   FormVarArr(LpArr, 1)    Valor del control
            '####### FIN DE OBTENCIÓN DE DATOS DEL FORMULARIO #########################################################################################################################################3


            '############ - INICIO DE REEMPLAZO DE PARAMETROS - ###################################################################################################################################
            'AQUÍ DEBEMO VERIFICAR SI HAY QUE CAMBIAR ALGÚN PARÁMETRO DE LA CADENA DE BÚSQUEDA,
            'Una vez obtenida la información, vemos si hay que cambiar los parámetros que se utilizan para realizar la consulta al servidor.
            'Segun la infomación obtenida en los dos puntos anteriores, se analiza si hay que cambiar algo.

            '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            '1ero Cambio Total de los parámetros
            'Analiza si hay datos dentro del RadioButton
            'Carga en las variables los datos que eligió el usuario
            For LpArr = 0 To VarArr.GetUpperBound(0)        'Interactua por las variables del formulario.
                'Coincide que se debe Modificar el Vinculo, y que en el link coincide con con Campo que tiene el dato
                If BucearOpcEleg <> "" And InStr(FormVarArr(LpArr, 0), BucearOpcEleg, CompareMethod.Text) > 0 Then       'Nombre de control
                    'Primero debe extraer la opción que eligió el usuario
                    If InStr(Left(FormVarArr(LpArr, 1), 4), "RBO:", CompareMethod.Text) > 0 Then
                        Dim SubCadIni As Integer : Dim SubCadFin As Integer
                        SubCadIni = InStr(FormVarArr(LpArr, 1), ":", CompareMethod.Text)
                        SubCadFin = InStr(FormVarArr(LpArr, 1), ";", CompareMethod.Text)
                        BucearOpcElegValor = FormVarArr(LpArr, 1).Substring(SubCadIni, SubCadFin - SubCadIni - 1)
                        FormVarArr(LpArr, 1) = FormVarArr(LpArr, 1).Substring(SubCadFin, Len(FormVarArr(LpArr, 1)) - SubCadFin)
                    End If
                    'Segundo carga los parámetros
                    TblCod = FuncHaceVinc(TblCod, FormVarArr(LpArr, 1), "", "Tbl")                  'Verifica si cambia la TblCod del informe
                    VarPar = FuncHaceVinc(VarParAcum, FormVarArr(LpArr, 1))                         'Verifica si cambia los parámetros
                End If
            Next LpArr


            '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            '2ero Cambio parcial de los parámetros
            'para ello recorremos la cadena de conexión vs los campos del formulario
            'si hay coincidencia en la Clave, eliminamos el dato de la cadena y lo reemplazamos por el dato ingresado por el usuario.
            Dim VarABusc As String = ""
            Dim VinModif As String = ""

            'Aquí hay que ver que pueden ser varios los campos a buscar
            'para ello debe ver la cantidad de parámetros que se pueden reemplazar hasta llegar al caracter de retorno de carro.

            'que no hay mas parámetros
            'Mientras encuentre reemplazo de parámetros hace el bucle
            Dim ContSeg As Integer = 0
            Dim ValInic As Integer
            Dim ValFin As Integer
            Dim ValCboaReemp As String = ""
            Dim ValdelCboUsu As String = ""
            ValInic = InStr(VarPar, "CtrlFrm=", CompareMethod.Text)
            Do While InStr(VarPar, "CtrlFrm=", CompareMethod.Text) > 0
                ContSeg = ContSeg + 1 : If ContSeg > 100 Then Exit Do 'Para que no se genere un bucle infinito
                'Ya se que en la VarPar hay parámetros que deben sustituirse por los valores de los campos del formulario
                'Para ello debemos verificar el parámetro que hay que cambiar, si:
                'coincide el nombre del campo luego de CtrlFrm con el nombre de algún campo del formulario
                'Toma la primer ocurrencia y el valor del campo que hay que buscar
                Dim ValParBusq As String = ""
                ValInic = InStr(VarPar, "CtrlFrm=", CompareMethod.Text) + 8
                ValParBusq = Mid(VarPar, ValInic, Len(VarPar))
                'Busca el final de la cadena, puede ser: 
                '                                   1.- Otro parámetro que comienza con ;P, 
                '                                   2.- el final que es un retorno de carro, o
                '                                   3.- No encuentra final por ende es el final de la cadena

                If InStr(ValParBusq, "|", CompareMethod.Text) > 0 Then
                    ValFin = InStr(ValParBusq, "|", CompareMethod.Text)
                ElseIf InStr(ValParBusq, ";P", CompareMethod.Text) > 0 Then
                    ValFin = InStr(ValParBusq, ";P", CompareMethod.Text)
                ElseIf InStr(ValParBusq, "¶", CompareMethod.Text) > 0 Then
                    ValFin = InStr(ValParBusq, "¶", CompareMethod.Text)
                Else
                    ValFin = Len(ValParBusq) + 1
                End If
                ValFin = ValInic + ValFin       'Le agrega la cantidad de caracteres iniciales, que se lo habíamos borrado.

                'Ya con los datos de inicio y final extraigo los datos
                ValCboaReemp = Mid(VarPar, ValInic, ValFin - ValInic)

                'Ya tengo el Cbo que se debe reemplazar ahóra busco el control y el valor del mismo
                For LpArr = 0 To VarArr.GetUpperBound(0)    'Bucle por todos los Ctrl del Formulario
                    If InStr(FormVarArr(LpArr, 0), ValCboaReemp, CompareMethod.Text) > 0 Then
                        ValdelCboUsu = FormVarArr(LpArr, 1)
                    End If
                Next LpArr

                ValCboaReemp = "CtrlFrm=" & ValCboaReemp

                VarPar = Replace(VarPar, ValCboaReemp, ValdelCboUsu)
                'VarParAcum = VarPar
            Loop

            '3ero Cambio del título
            'Si el Título debe tomar el valor del campo elegido, lo reemplaza
            Do While InStr(TblTitulo, "CtrlFrm=", CompareMethod.Text) > 0
                ContSeg = ContSeg + 1 : If ContSeg > 100 Then Exit Do 'Para que no se genere un bucle infinito
                'Busca el inicio de la cadena
                ValInic = InStr(TblTitulo, "CtrlFrm=", CompareMethod.Text) + 8
                'Busca el final de la cadena
                ValFin = Len(TblTitulo) + 1

                'Ya con los datos de inicio y final extraigo los datos
                ValCboaReemp = Mid(TblTitulo, ValInic, ValFin - ValInic)

                'Ya tengo el Cbo que se debe reemplazar ahóra busco el control y el valor del mismo
                For LpArr = 0 To VarArr.GetUpperBound(0)    'Bucle por todos los Ctrl del Formulario
                    If InStr(FormVarArr(LpArr, 0), ValCboaReemp, CompareMethod.Text) > 0 Then
                        ValdelCboUsu = FormVarArr(LpArr, 1)
                    End If
                Next LpArr

                ValCboaReemp = "CtrlFrm=" & ValCboaReemp

                TblTitulo = Replace(TblTitulo, ValCboaReemp, ValdelCboUsu)
            Loop
            '############ - FIN DE REEMPLAZO DE PARAMETROS - ###################################################################################################################################

            '############ - REGISTRO DE TIEMPOS - ############# ‡ §
            InfoTiempoInfEsp = "InfGral"
            'Registra la marca de tiempos, vuelve a tomar la otra marca
            InfoTiempo = InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§0§100§Toma Parametros§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
            InfoTiempoDesde = TimeOfDay
            '############ - ^^^^^^^^^^^^^^^^^^^ - #############

            '####################################################################################################################################################
            'Verifica si es la primera vez que se abre el formulario
            'la primera vez puede haber un informe con varias tablas, por eso el bucle. 
            'La segunda ves solo se genera una tabla.
            '************************************************** INICIO **********************************************************
            '<<<<<<<< Procedimiento para conectarse y Ejecutar consultas >>>>>>>>>>>>>
            Rtado = ADOCnxBD("PVTWEB")             'Llama a la funcion para conectar a la BD, de la hoja BDCnxADO
            'MyStringBuilder.Append(Rtado & "<br>")      'Escribe si se conecto OK o NO

            'Aquí no debe verificar si es Postback, si es informe hace muchos bucles, si no solo hace uno solo, que es para la tabla
            'De esta forma me independizo del goto.
            'Siempre ejecuta primero el GRL_INFME, si no tiene nada, ejecuta la tabla sola.

            '1.- Toma la información de la base de datos para armar el informe
            '    información de la TABLA SQL [GRLM013_INFME] donde estan los informes y sus parámetros
            Rtado = SqlBD("[PVTWEB].[dbo].[GRL_INFME]", TblCod, NomDataTble, "PVTWEB", "DataReader")

            If Left(Rtado, 6) = "SqlErr" Then
                Response.Write(Rtado)
                Exit Sub
            End If

            '############ - REGISTRO DE TIEMPOS - ############# ‡ §
            InfoTiempoInfEsp = "InfGral"
            'Registra la marca de tiempos, vuelve a tomar la otra marca
            InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§0§150§SQL GRL_INFME§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
            InfoTiempoDesde = TimeOfDay
            '############ - ^^^^^^^^^^^^^^^^^^^ - #############

            '********************************************************************************************************************
            'Toma los datos de la BD y luego los asigna al DataRow, de aca saca cuantas tablas por informe
            DtRIFilAct = dbDTable.Select(Nothing, "[GRLM013_INFORD] ASC", DataViewRowState.CurrentRows)
            TblRelac = ""

            Dim filinf As Integer
            Dim CantFil As Integer
            Dim EsInforme As Boolean
            Dim DatActFec(20) As String

            'Si tiene más de una fila la consulta, EsInforme y tiene varias tablas, caso contrario Solo una
            If DtRIFilAct.Length > 0 Then
                EsInforme = True
                CantFil = DtRIFilAct.Length - 1     'Cantidad de Tablas
            Else
                EsInforme = False
                CantFil = 0
            End If

            ' Ahora recorremos el recordset para ejecutar una o varias tablas / graficos por informe 
            For filinf = 0 To CantFil
                'Ahora hace por cada fila de la tabla informe hace un informe.
                If EsInforme = True Then
                    'Si se genera a través de un informe, se deben tomar los parámetros de cada fila, para armar cada tabla
                    'Define la tabla que se va a realizar
                    TblCod = DtRIFilAct(filinf)(1).ToString

                    'Define la tabla que se utilizará
                    If DtRIFilAct(filinf)(2).ToString <> "" Then
                        TablaAsig = DtRIFilAct(filinf)(2).ToString
                    End If

                    'Determina los parámetros para abrir la tabla
                    If DtRIFilAct(filinf)(3).ToString <> "" Then
                        VarParAcum = DtRIFilAct(filinf)(3).ToString
                        VarParAcum = VarParAcum.Replace("USUNAME", Page.User.Identity.Name.ToString())
                        VarParVinc = FuncVarPar(VarParAcum)
                    Else
                        VarParAcum = "NULL"
                        VarParVinc = VarParAcum
                    End If

                    'Determina si el informe tiene Radiobutton de opciones para bucear
                    If LTrim(RTrim(DtRIFilAct(filinf)(4).ToString)) <> "" Then
                        'Se carga la información para agregar combos de opciones para cada tabla
                        TblOpcBusqDatos = LTrim(RTrim(DtRIFilAct(filinf)(4).ToString))
                    Else
                        'No tiene opciones de búsqueda para el buceo
                        TblOpcBusqDatos = ""
                    End If

                    'Determina el Título de la tabla / informe
                    If DtRIFilAct(filinf)(5).ToString <> "" Then
                        If InStr(1, DtRIFilAct(filinf)(3).ToString, "USUNAME", CompareMethod.Text) > 0 Then
                            TblTitulo = DtRIFilAct(filinf)(5).ToString & " - " & Page.User.Identity.Name.ToString()
                        Else
                            TblTitulo = LTrim(RTrim(DtRIFilAct(filinf)(5).ToString))
                        End If
                    End If
                Else
                    'Es solo una tabla que viene de otra, por lo tanto la información viene de los parámetros
                    TblCod = TblCod
                    NomDataTble = NomDataTble
                    VarParAcum = VarParAcum
                    TblTitulo = TblTitulo

                    If VarProxBuceoDat <> "" Then
                        'Aquí hay que verificar si el radiobutton viene de la Tabla ProxBuceo, si es así busca el parámetro
                        'para ello ejecuta la consulta SQL via el ProcAlm GRL_TBLBUCEO, a la tabla GRLM014_BUCEO
                        'le pasa las dos variables:     VarProxBuceoDat = [GRLM014_CODBUCEO]
                        '                               BucearOpcEleg = [GRLM014_BUCEOPAR]
                        Dim VarBucePar As String = ""
                        VarBucePar = "P0:" & VarProxBuceoDat
                        If BucearOpcElegValor <> "" Then
                            VarBucePar = VarBucePar & "|P1:" & BucearOpcElegValor
                        End If

                        '1.- Toma la información de la base de datos para armar la tabla
                        Rtado = SqlBD("[PVTWEB].[dbo].[GRL_TBLBUCEO]", VarBucePar, NomDataTble, "PVTWEB", "DataReader")
                        If Left(Rtado, 6) = "SqlErr" Then
                            Response.Write(Rtado)
                            Exit Sub
                        End If
                        '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                        InfoTiempoInfEsp = TblCod
                        'Registra la marca de tiempos, vuelve a tomar la otra marca
                        InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§170§SQL GRL_TBLBUCEO§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                        InfoTiempoDesde = TimeOfDay
                        '############ - ^^^^^^^^^^^^^^^^^^^ - #############

                        'Obtiene los Parametros de la tabla, para con ellos poder ejecutar las consultas y hacer luego las tablas.
                        'aquí es donde se toma la información de Tipo de Informe, Formato, Vinculos, etc.
                        DtRFilAct = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)
                        ' Ahora recorremos el recordset relevando los parámetros definidos en la Tabla
                        For Fil = 0 To DtRFilAct.Length - 1
                            If DtRFilAct(Fil)(0).ToString <> "" Then
                                TblOpcBusqDatos = DtRFilAct(Fil)(0).ToString
                            End If
                        Next Fil
                    Else
                        'No tiene opciones de búsqueda para el buceo
                        TblOpcBusqDatos = ""
                    End If
                End If


                ''####################################################################################################
                ''1.- Toma la información de la base de datos para armar la tabla
                '     Finaliza el procedimiento para que no se vuelva a ejecutar la tabla
                '1.- Toma la información de la base de datos para armar la tabla
                Rtado = SqlBD("[PVTWEB].[dbo].[GRL_TBLARM]", TblCod, NomDataTble, "PVTWEB", "DataReader")

                If Left(Rtado, 6) = "SqlErr" Then
                    Response.Write(Rtado)
                    Exit Sub
                End If

                '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                InfoTiempoInfEsp = TblCod
                'Registra la marca de tiempos, vuelve a tomar la otra marca
                InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§200§SQL GRL_TBLARM§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                InfoTiempoDesde = TimeOfDay
                '############ - ^^^^^^^^^^^^^^^^^^^ - #############

                '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^66
                'Obtiene los Parametros de la tabla, para con ellos poder ejecutar las consultas y hacer luego las tablas.
                'aquí es donde se toma la información de Tipo de Informe, Formato, Vinculos, etc.
                DtRFilAct = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)
                TblRelac = ""

                'Ponemos a cero todas las variables, para que una tabla no tenga los de otra anterior
                TipoInforme = "" : TblTitVinculo = "" : ProAlm = "" : TblOrden = "" : TblOrden = "" : TblCssGral = ""
                TblFormCss = "" : TblRangDatCalc = "" : TblFecActDatos = ""
                ' Ahora recorremos el recordset relevando los parámetros definidos en la Tabla
                For Fil = 0 To DtRFilAct.Length - 1
                    If DtRFilAct(Fil)(0).ToString = "TBLTIPO" Then
                        'Se carga el tipo de Tabla / Formulario
                        TipoInforme = DtRFilAct(Fil)(1).ToString
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLTITVINC" Then
                        'Se carga el vinculo del Título
                        TblTitVinculo = DtRFilAct(Fil)(1).ToString
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLDATOS" Then
                        'Se carga en la variable el Proc Alm que dará origen a la tabla inicial
                        ProAlm = DtRFilAct(Fil)(1).ToString
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLORDEN" Then
                        'Se carga la información para ordenar la tabla
                        TblOrden = DtRFilAct(Fil)(1).ToString
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLCSSGRAL" Then
                        'Se carga la información para definir el formato de la tabla
                        TblCssGral = DtRFilAct(Fil)("COD_PROCALM").ToString
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLFORMCSS" Then
                        'Se carga la información para definir el formato de la tabla
                        TblFormCss = DtRFilAct(Fil)("COD_PROCALM").ToString
                        'Esta se deberia eliminar
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLRANGODATCALC" Then
                        'Se carga la información para hacer los calculos de las columnas
                        TblRangDatCalc = DtRFilAct(Fil)("COD_PROCALM").ToString
                    ElseIf DtRFilAct(Fil)(0).ToString = "TBLFECACTDAT" Then
                        'Se carga la información para buscar la fecha de act de los datos
                        TblFecActDatos = DtRFilAct(Fil)("COD_PROCALM").ToString
                    End If
                Next Fil
                '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

                '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                'Busca la fecha y hora de la actualización de los datos para cargarlo en la variable FechActDatos
                Dim DatFecAct() As String
                Dim DataActu() As String
                Dim FechActDatos As String = ""

                'Toma los datos y los separa para su analisis
                If TblFecActDatos <> "" Then
                    DatFecAct = TblFecActDatos.Split("‡")
                    DataActu = DatFecAct(1).Split("|")

                    'Recorre la matriz para ver si la fecha de esa tabla fue cargada
                    Dim FecCarg As Boolean = False
                    For FDA = 0 To 20
                        If DatActFec(FDA) = DataActu(0) Then
                            FecCarg = True
                            Exit For
                        End If
                    Next FDA

                    If FecCarg = True Then
                        FechActDatos = ""
                    Else    'Los datos no fueron cargados
                        'Primero debe cargar el dato en la matriz de comprobación
                        For FDA = 0 To 20
                            If IsNothing(DatActFec(FDA)) = True Or DatActFec(FDA) = "" Then
                                DatActFec(FDA) = DataActu(0)
                                Exit For
                            End If
                        Next FDA

                        'Segundo debe buscar el dato en el sistema y formar la variable que se mostrará
                        'Ejecuta la consulta para obtener la información
                        'Proc Alm, Parámetros, NombreDataTable
                        Rtado = SqlBD(DatFecAct(0), DatFecAct(1), NomDataTble, "PVTWEB", "DataReader")
                        If Left(Rtado, 6) = "SqlErr" Then
                            Response.Write(Rtado)
                            Exit Sub
                        End If

                        '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                        InfoTiempoInfEsp = TblCod
                        'Registra la marca de tiempos, vuelve a tomar la otra marca
                        InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§250§SQL GRL_FECACTDAT§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                        InfoTiempoDesde = TimeOfDay
                        '############ - ^^^^^^^^^^^^^^^^^^^ - #############

                        Dim DtRFilActFA() As DataRow

                        DtRFilActFA = dbDTable.Select(Nothing, Nothing, DataViewRowState.CurrentRows)
                        For Fil = 0 To DtRFilActFA.Length - 1   'Desde la primer Fila
                            FechActDatos = "actualizada al " & DtRFilActFA(Fil)(1).ToString
                        Next Fil
                    End If
                End If
                FechActDatos = FechActDatos
                '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

                '**********************************************************************************************************************************
                'Consulta con los datos reales que vera el usuario
                '1.- La conexión, lectura de los datos y su traslado a la Tabla se hace en la función.
                If VarParVinc = "" Then
                    VarParVinc = FuncVarPar(VarPar)
                End If
                Rtado = SqlBD(ProAlm, VarParVinc, NomDataTble, "PVTWEB", "DataReader")

                If Left(Rtado, 6) = "SqlErr" Then
                    Response.Write(Rtado)
                    Exit Sub
                End If


                '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                InfoTiempoInfEsp = TblCod
                'Registra la marca de tiempos, vuelve a tomar la otra marca
                InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§300§SQL DATOS A MOSTRAR§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                InfoTiempoDesde = TimeOfDay
                '############ - ^^^^^^^^^^^^^^^^^^^ - #############

                '2.- Realiza la Tabla o el Formulario, si el DataTable tiene datos
                If dbDTable.Rows.Count > 0 Then
                    If TipoInforme = "TABLA" Then
                        '3.- Tomo las filas en la variable = FilasActuales como DataRow
                        Rtado = HaceTbla(dbDTable.Select(Nothing, TblOrden, DataViewRowState.CurrentRows), TblRelac, TblFormCss, TblTitulo, TblCssGral, TblTitVinculo, VarParAcum, TablaAsig, TblRangDatCalc, FechActDatos, TblOpcBusqDatos)
                        TblTitulo = ""
                        'Response.Write(Rtado)

                        '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                        InfoTiempoInfEsp = TblCod
                        'Registra la marca de tiempos, vuelve a tomar la otra marca
                        InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§10001§FIN TABLA§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                        InfoTiempoDesde = TimeOfDay
                        '############ - ^^^^^^^^^^^^^^^^^^^ - #############

                    ElseIf TipoInforme = "FORMULARIO" Then
                        Rtado = HaceForm(dbDTable.Select(Nothing, TblOrden, DataViewRowState.CurrentRows), TblRelac, TblFormCss, TblTitulo, TblCssGral, TblTitVinculo, VarParAcum, TablaAsig, TblRangDatCalc, FechActDatos)
                        TblTitulo = ""
                        'Response.Write(Rtado)

                        '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                        'Registra la marca de tiempos, vuelve a tomar la otra marca
                        InfoTiempoInfEsp = TblCod
                        InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§10002§FIN FORM§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                        InfoTiempoDesde = TimeOfDay
                        '############ - ^^^^^^^^^^^^^^^^^^^ - #############
                    End If
                Else
                    'NO hay datos, por lo tanto lo informa al usuario
                    Dim TitLabel As New Label()
                    TitLabel.Text = "Sin registros"
                    TitLabel.CssClass = "caption"
                    Panel1.Controls.Add(New LiteralControl("<a href='javascript:history.back()'> <img src='../Imagenes/Varias/FlechaAtras.png' alt='Atras' class='fatrasI' /> </a>"))
                    Panel1.Controls.Add(TitLabel)

                    '############ - REGISTRO DE TIEMPOS - ############# ‡ §
                    InfoTiempoInfEsp = TblCod
                    'Registra la marca de tiempos, vuelve a tomar la otra marca
                    InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§10003§FIN SIN DATOS§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay
                    InfoTiempoDesde = TimeOfDay
                    '############ - ^^^^^^^^^^^^^^^^^^^ - #############

                End If

                If Left(Rtado, 6) = "SqlErr" Then
                    Response.Write(Rtado)
                    Exit Sub
                End If
            Next filinf

            Dim TpoInfFin As Date = TimeOfDay

            'Incorpora la fecha de la actualización de los datos
            Dim TPOINFLabel As New Label()
            TPOINFLabel.Text = "Tiempo de demora del informe " & DateDiff(DateInterval.Second, TpoInfInicio, TpoInfFin) & " seg."
            TPOINFLabel.CssClass = "fadatos"
            'Panel1.Controls.Add(New LiteralControl("<BR>"))
            Panel1.Controls.Add(TPOINFLabel)

            '############ - MUESTRA REGISTRO DE TIEMPOS - ############# ‡ §
            InfoTiempoInfEsp = "InfGral"
            'Registra la marca de tiempos, vuelve a tomar la otra marca
            InfoTiempo = InfoTiempo & "‡" & InfoTiempoEjecucion & "§" & InfoTiempoInfGral & "§" & InfoTiempoInfEsp & "§" & filinf + 1 & "§9999§FINAL§" & DateDiff(DateInterval.Second, InfoTiempoDesde, TimeOfDay) & " seg.§" & InfoTiempoDesde & "§" & TimeOfDay

            Dim TblInf As New Table
            TblInf.ID = "TblInf"
            TblInf.CssClass = "TblInfCss"
            Dim VarExpFil As String()
            Dim Tfil As Integer
            Dim TfilN As String     'Pone el número de la fila para definir el label ID
            Dim Tcol As Integer
            Dim TcolN As String     'Pone el número de la columna para definir el label ID
            VarExpFil = InfoTiempo.Split("‡")
            If VarExpFil.Length > 0 Then    'Quiere decir que tiene más de una fila
                For Tfil = 0 To VarExpFil.Length - 1
                    If Tfil < 10 Then
                        TfilN = "00" & Tfil
                    ElseIf Tfil < 100 Then
                        TfilN = "0" & Tfil
                    End If
                    Dim TblInfRow As New TableRow()       'Agrega una nueva variable para una nueva Fila
                    Dim VarExpCol As String()
                    VarExpCol = VarExpFil(Tfil).Split("§")
                    If VarExpCol.Length > 0 Then    'Quiere decir que tiene más de una columna
                        For Tcol = 0 To VarExpCol.Length - 1
                            If Tcol < 10 Then
                                TcolN = "00" & Tcol
                            ElseIf Tcol < 100 Then
                                TcolN = "0" & Tcol
                            End If
                            Dim TblInfDatCel As New TableCell()            'Table Cell
                            Dim TblInfLabl As New Label()                   'Label
                            TblInfLabl.ID = "lbl" & Tfil & Tcol
                            TblInfLabl.Text = VarExpCol(Tcol).ToString
                            TblInfDatCel.Controls.Add(TblInfLabl)
                            TblInfRow.Cells.Add(TblInfDatCel)
                        Next Tcol
                    End If
                    TblInf.Rows.Add(TblInfRow)
                Next Tfil
                'Agrega la Tabla al Panel
                Panel1.Controls.Add(TblInf)
            End If

            'Muestra los datos
            Panel1.Controls.Add(New LiteralControl("<BR>"))

            '############ - ^^^^^^^^^^^^^^^^^^^ - #############
            'Borra todas las variables
            TblCod = "" : ProAlm = "" : VarPar = "" : VarParAcum = "" : TblTitulo = "" : VarParVinc = "" : TblTitVinculo = ""
            NomDataTble = "" : TblCssGral = "" : TblFormCss = "" : TblRangDatCalc = "" : TblOpcBusqDatos = ""
            BucearOpcEleg = "" : BucearOpcElegValor = "" : VarProxBuceoDat = "" : TblFecActDatos = ""

            ''<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FIN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            '' ##########################################################################################################################################3
        End If
    End Sub

    Friend Function HaceForm(ByVal DtRFilasActuales() As DataRow, ByVal Vinculo As String, ByVal TblFomCss As String, Optional ByVal TblTitulo As String = "", Optional ByVal TblCssGral As String = "", Optional ByVal TblTituloVinculo As String = "", Optional ByVal VarPar As String = "", Optional ByVal VarTblArmASP As String = "Table01", Optional ByVal VarTblRangDatCalc As String = "", Optional FADatos As String = "") As String      'Se definen 1 parámetros, Nombre Base de Datos y Consulta Inicial
        Dim ConvEnTbljDob As String     'Para tomar la información del Formato

        Dim Fil As Integer = 0 : Dim TotFil As Integer = 0
        Dim Col As Integer = 0 : Dim TotCol As Integer = 0
        Dim FilArr As Integer = 0 : Dim ColArr As Integer = 0
        TotFil = dbDTable.Rows.Count - 1 : TotCol = dbDTable.Columns.Count - 1

        'Datos del Campo
        Dim NomCpoVis As String = "VISIBLE"            'Determina si se muestra o no el nombre del campo
        Dim NomCol As String = ""               'Nombre de la Columna
        Dim NomCampo As String = ""             'Nombre del compo
        Dim ValCampo As String = ""             'Datos del Campo
        Dim TextoAAgregar As String = ""        'Datos del campo con modificaciones de formato
        Dim DatoTipComp As String = ""          'Dato con el tipo de componente que se agrega, LABEL, LINKBUTTON, ETC
        Dim DatoTipCompRtado() As String

        'Formato de la Celda
        Dim FtoColAncho As String = ""
        Dim FtoColOrden As String = ""
        Dim FtoColAlin As String = ""
        Dim FtoCsStyle As String = ""

        ' 1.- Primero debemos poner el título al Formulario
        Dim TitLabel As New Label()
        Dim TitLinkButt As New LinkButton()
        If RTrim(LTrim(TblTitulo)) <> "" Then
            If TblTituloVinculo = "" Then
                TitLabel.Text = TblTitulo
                TitLabel.CssClass = "caption"
                Panel1.Controls.Add(TitLabel)
            Else
                TitLinkButt.Text = TblTitulo.ToString
                'TitLinkButt.PostBackUrl = TblTituloVinculo & "&TblPars=" & VarPar & "&TblTit=" & TblTitulo.ToString & " - COMPLETO"
                TitLinkButt.CssClass = "caption"
                Panel1.Controls.Add(TitLinkButt)
            End If
        Else
            'Tbl.Caption = ""
        End If

        'Incorpora la fecha de la actualización de los datos
        If FADatos <> "" Then
            Dim FADLabel As New Label()
            FADLabel.Text = FADatos
            FADLabel.CssClass = "fadatos"
            'Panel1.Controls.Add(New LiteralControl("<BR>"))
            'Pone la flecha vuelve atras
            Panel1.Controls.Add(New LiteralControl("<a href='javascript:history.back()'> <img src='../Imagenes/Varias/FlechaAtras.png' alt='Atras' class='fatras' /> </a>"))
            Panel1.Controls.Add(FADLabel)
        End If

        If TblFomCss <> "" Then
            ConvEnTbljDob = ConvEnTblDoble(TblFomCss)   'La variable trae el resultado de si funciono o no la funcion, el contenido esta en la matriz TblaRangoFormatoArray
        End If

        'Los Formularios siempre tienen 1 solo registro
        Fil = 0     'Como siempre es una fila, el valor es 1.
        If TotFil >= 0 Then
            Panel1.Controls.Add(New LiteralControl("<div class='MargAnt'>"))
            'Dim DatosMultiValuados() As String
            Dim PrimerCampo As Boolean
            PrimerCampo = True
            For Col = 0 To dbDTable.Columns.Count - 1

                'Variables para tomar el contenido del formato
                Dim RtadoTblFtoUsu As Integer = 0
                ValCampo = DtRFilasActuales(Fil)(Col).ToString
                Dim TipoFormatoCss As String = ""
                If IsNothing(ValCampo) = True Then
                    ValCampo = ""
                    'ElseIf Left(ValCampo, 4) = "<br>" Then
                    '    ValCampo = ""
                    '    TipoFormatoCss = "<br>"
                End If

                'Nombre del Campo, esto es para agregar al nombre del objeto para que cada uno tenga siempre un nombre distinto y no genera erro
                NomCol = ""
                NomCol = dbDTable.Columns(Col).Caption.ToString

                If Left(NomCol, 4) = "<br>" Or Left(NomCol, 4) = "<hr>" Then
                    NomCampo = NomCol.Substring(4, Len(NomCol) - 4)
                Else
                    NomCampo = NomCol
                End If
                If Col < 10 Then
                    NomCol = NomCol & "0" & Col
                Else
                    NomCol = NomCol & Col
                End If

                'En caso de que el nombre del campo tenga un salto de pagina, y otro indicador
                'lo agrega y ajusta el nombre del campo sin ese valor.
                Dim TieneValor As Boolean
                TieneValor = True
                If Left(NomCol, 4) = "<br>" Then
                    'Agrega un retorno de carro
                    Panel1.Controls.Add(New LiteralControl("<br />"))
                    'Verifica si solo la columna tiene salto de pagina
                    If ValCampo = "<br>" Or NomCol = "<br>" Then
                        TieneValor = False
                    End If
                    NomCol = NomCol.Substring(4, Len(NomCol) - 4)
                ElseIf Left(NomCol, 4) = "<hr>" Then
                    'Agrega un separador
                    Panel1.Controls.Add(New LiteralControl("<hr />"))
                    'Verifica si solo la columna tiene salto de pagina
                    If ValCampo = "<hr>" Or NomCol = "<hr>" Then
                        TieneValor = False
                    End If
                    NomCol = NomCol.Substring(4, Len(NomCol) - 4)
                    TieneValor = True
                End If

                'Si la columna es de un valor a agragar
                If TieneValor = True Then
                    'Agrega el valor del campo
                    RtadoTblFtoUsu = FuncTblFtoUsu(Fil, Col)                    'Devuelve el Formato del usuario en una Tabla para aplicar al Formato .Net
                    'Si el formato a aplicar es superior siempre prevalece. 
                    'Eje: la Celda es el último formato Nivel 4, la hoja es el general Nivel 0. La hoja puede tener un tamano de letra, pero la celda otro y este es el que va.
                    'Aplica el formato establecido, luego establece el nivel de formato que se aplicó. 
                    Dim FtoAplCant As Integer = 0

                    For FtoAplCant = 0 To RtadoTblFtoUsu
                        Select Case FtoAplicar(FtoAplCant, 5)       'El Valor 5, es el FtoAplizar Nivel
                            Case 0      'Nivel Hoja
                            Case 1      'Nivel Fila
                            Case 2      'Nivel Columna
                            Case 3, 4      'Nivel Rango o Celda
                                'Tipo de campo que se incorpora
                                If FtoAplicar(FtoAplCant, 0) = "DATO" And FtoAplicar(FtoAplCant, 1) = "CATEGORIA" Then
                                    'Si se usa el Texto a Agregar es porque, el campo con el valor es multivaluado, (Ej: dato del vinculo, dato a mostrar).
                                    If TextoAAgregar = "" Then      'Verifica esto, ya que el valor del campo puede ser multivaluado (para vinculo, valor que se muestra, etc).
                                        TextoAAgregar = ValCampo
                                    End If
                                    TextoAAgregar = DatFto(TextoAAgregar, FtoAplicar(FtoAplCant, 2))
                                ElseIf FtoAplicar(FtoAplCant, 0) = "FUENTE" And FtoAplicar(FtoAplCant, 1) = "ALINHORIZ" Then
                                    FtoColAlin = FuncFtoColAlin(FtoAplicar(FtoAplCant, 2))
                                ElseIf FtoAplicar(FtoAplCant, 0) = "FORMATO" And FtoAplicar(FtoAplCant, 1) = "CSSTYLE" Then
                                    FtoCsStyle = FuncFtoCsStyle(FtoAplicar(FtoAplCant, 2))
                                ElseIf FtoAplicar(FtoAplCant, 0) = "NOMCPO" And FtoAplicar(FtoAplCant, 1) = "VISIBILIDAD" Then
                                    NomCpoVis = FtoAplicar(FtoAplCant, 1)
                                    ''‡0:0;0:2†NOMCPO¶VISIBILIDAD¶OCULTAR¶¶
                                ElseIf FtoAplicar(FtoAplCant, 0) = "DATO" And FtoAplicar(FtoAplCant, 1) = "TIPCOMP" Then
                                    '0 = FtoTipo, 1 = FtoParametro, 2 = FtoParValor, 3 = FtoParValorAdic, 4 = FtoParRegla, 5 = FtoNivel
                                    '1.- Segundo parámetro VISIVILIDAD
                                    'Tipo de campo que se incorpora
                                    '1.- Primer parametro = tipo de dato, 2.- Segundo parametro = valor del campo, 3.- Tercer parametro = Vinculo
                                    If ValCampo <> "" Then
                                        DatoTipComp = FuncDatoTipComp(FtoAplicar(FtoAplCant, 2), ValCampo, FtoAplicar(FtoAplCant, 3), VarPar, Fil, Col)
                                    End If
                                End If
                        End Select
                    Next FtoAplCant     'Pasa el formato a .net

                    '############################################################################################
                    'Incorpora los Valores a las propiedades del componente
                    'Dependiendo el tipo de campo especificado es lo que se incorpora, 
                    'aquí puede incorporar Label, LinkButton, InputBox, etc, y en función de esto son los parámetros específicos que se completan.
                    'Hay que analizar el análisis de la variable TextoAAgregar

                    'Primero debe agregar el Nombre del Campo, para luego agregar su contenido
                    If NomCpoVis = "VISIBLE" Then
                        If NomCampo <> "" Then
                            Dim LablCpo As New Label
                            LablCpo.Text = NomCampo                    'Agrega el valor del campo al label
                            'CSSTYLE
                            If FtoCsStyle <> "" Then
                                LablCpo.CssClass = FtoCsStyle & "Tit"
                            End If
                            LablCpo.ID = "tlbl" & NomCol            'Agrega el id al linkbutton para que sean todos distintos
                            Panel1.Controls.Add(LablCpo)
                            NomCampo = ""                           'Limpia las variables
                        End If
                        NomCpoVis = "VISIBLE"
                    End If
                    
                    DatoTipCompRtado = DatoTipComp.Split("‡")
                    If DatoTipCompRtado(0) = "LINKBUTTON" Then               '2.- Determina el tipo de objeto que agrega
                        Dim LinkButt As New LinkButton()
                        Dim VincCompl As String = ""
                        'CONTENIDO
                        If TextoAAgregar <> "" Then
                            LinkButt.Text = TextoAAgregar                 'Agrega el valor del campo al linkbutton
                        Else
                            LinkButt.Text = DatoTipCompRtado(1)                 'Agrega el valor del campo al linkbutton
                        End If
                        LinkButt.ID = "dlbt" & NomCol                    'Agrega el id al linkbutton para que sean todos distintos

                        'VINCULO
                        VincCompl = DatoTipCompRtado(2)
                        LinkButt.PostBackUrl = VincCompl          'Agrega el vinculo

                        'CSSTYLE
                        If FtoCsStyle <> "" Then
                            LinkButt.CssClass = FtoCsStyle
                            FtoCsStyle = ""
                        End If
                        'LinkButt.OnClientClick(Var01Pas = "Juan")
                        Panel1.Controls.Add(LinkButt)
                        DatoTipComp = ""                                    'Borra la variable ya utilizada
                        Array.Clear(DatoTipCompRtado, 0, DatoTipCompRtado.Length)       'Ya utilizada, borra el array
                        ValCampo = "" : TextoAAgregar = ""      'Limpia las variables
                    ElseIf DatoTipCompRtado(0) = "TEXTBOX" Then
                        Dim TxtBox As New TextBox
                        If DatoTipCompRtado(1) = " " Then
                            'TxtBox.Text = ""                                     'Campo vacio
                        Else
                            TxtBox.Text = DatoTipCompRtado(1)                    'Agrega el valor del campo al label
                        End If

                        'CSSTYLE
                        If FtoCsStyle <> "" Then
                            TxtBox.CssClass = FtoCsStyle
                        End If
                        TxtBox.ID = "dtxb" & NomCol                    'Agrega el id al linkbutton para que sean todos distintos
                        'TxtBox.Attributes.Add("DA", "Juan")
                        Panel1.Controls.Add(TxtBox)
                        DatoTipComp = ""                                    'Borra la variable ya utilizada
                        Array.Clear(DatoTipCompRtado, 0, DatoTipCompRtado.Length)       'Ya utilizada, borra el array
                        'TblDatCel.Controls.Add(New LiteralControl(ValCampo))            'Agrega el label a la Celda
                        ValCampo = "" : TextoAAgregar = ""      'Limpia las variables
                    ElseIf DatoTipCompRtado(0) = "LABEL" Then
                        Dim Labl As New Label
                        Labl.Text = DatoTipCompRtado(1)                    'Agrega el valor del campo al label
                        'CSSTYLE
                        If FtoCsStyle <> "" Then
                            Labl.CssClass = FtoCsStyle
                            FtoCsStyle = ""
                        End If
                        Labl.ID = "dlbl" & NomCol                    'Agrega el id al linkbutton para que sean todos distintos
                        Panel1.Controls.Add(Labl)
                        DatoTipComp = ""                                    'Borra la variable ya utilizada
                        Array.Clear(DatoTipCompRtado, 0, DatoTipCompRtado.Length)       'Ya utilizada, borra el array
                        'TblDatCel.Controls.Add(New LiteralControl(ValCampo))            'Agrega el label a la Celda
                        ValCampo = "" : TextoAAgregar = ""      'Limpia las variables
                    ElseIf DatoTipCompRtado(0) = "RADIOBUTTON" Then
                        'Debe realizar un bucle por las distintas opciones del RadioButton
                        Dim RadioButtonOpcion() As String
                        Dim RdioButOpParVal() As String
                        Dim RBO As Integer
                        RadioButtonOpcion = DatoTipCompRtado(1).Split("†")      'Separa las distintas opciones
                        For RBO = 0 To RadioButtonOpcion.GetUpperBound(0)
                            '†				            -- Separa cada opción del Radio Button
                            'ID:NombreId			    -- Es el nombre individual del control
                            '¶GroupName:Opb01		    -- Es el nombre que agrupa los distintos Checked
                            '¶Text:ValordelCompo		-- Es el valor que figura en el combo
                            '¶Checked:True o False		-- Determina si esta chequeado por defecto
                            '¶CssClass:ValorEspec		-- Contiene el formato del combo
                            '¶AutoPostBack:True o False	-- Si cuando se hace click recarga la pagina

                            'ID:CLITIPO†Text:Cliente Tipo†Checked:True;‡ID:FACNUM†Text:Factura' AS '<br>Opb01'
                            Dim RdioB As New RadioButton        'Especifica el nuevo objeto RadioButton
                            Dim RBPV As Integer                 'Variable para hacer bucle en el RB Parametros : Valor
                            Dim ParValor() As String
                            RdioButOpParVal = RadioButtonOpcion(RBO).Split("§")          'Separa los distintos parámetros del RB
                            For RBPV = 0 To RdioButOpParVal.GetUpperBound(0)
                                ParValor = RdioButOpParVal(RBPV).Split("¶")
                                Select Case ParValor(0)
                                    Case "ID"
                                        RdioB.ID = ParValor(1)
                                    Case "Text"
                                        RdioB.Text = ParValor(1)
                                    Case "Checked"
                                        If ParValor(1) = "True" Then
                                            RdioB.Checked = True
                                        End If
                                    Case "GroupName"
                                        RdioB.GroupName = ParValor(1)
                                End Select
                            Next RBPV
                            'RdioB.Attributes.Add("Par1", "Esto es una Prueba")
                            'Si en los parámetros de la consulta SQL no trae el GroupName, agrega el GroupName como nombre del campo
                            If RdioB.GroupName = "" Then
                                RdioB.GroupName = NomCol        'Nombre al Grupo de Controles
                            End If

                            Panel1.Controls.Add(RdioB)      'Agrega el RadioButton
                            'Pone a cero las variables ya utilizadas
                            'RdioB.ID = ""
                            'RdioB.Text = ""
                            'RdioB.GroupName = ""
                            'RdioB.Checked = False
                        Next RBO
                    Else
                        Dim Labl As New Label()
                        If TextoAAgregar = "" Then              'Verifica esto, ya que el valor del campo puede ser multivaluado (para vinculo, valor que se muestra, etc).
                            TextoAAgregar = ValCampo
                        End If
                        If ValCampo <> "" Then
                            Labl.Text = TextoAAgregar                    'Agrega el valor del campo al label
                            'CSSTYLE
                            If FtoCsStyle <> "" Then
                                Labl.CssClass = FtoCsStyle
                                FtoCsStyle = ""
                            End If
                            Panel1.Controls.Add(Labl)
                        End If
                        ValCampo = "" : TextoAAgregar = ""      'Limpia las variables
                    End If

                End If
            Next Col
            Panel1.Controls.Add(New LiteralControl("</div>"))
            Panel1.Controls.Add(New LiteralControl("<br />"))
            'Si llega a esta instancia es que realizo el FORUMULARIO OK, lo informa
        End If
        HaceForm = "TblaOK"
        Return HaceForm
    End Function

    Friend Function HaceTbla(ByVal DtRFilasActuales() As DataRow, ByVal Vinculo As String, ByVal TblFomCss As String, Optional ByVal TblTitulo As String = "", Optional ByVal TblCssGral As String = "", Optional ByVal TblTituloVinculo As String = "", Optional ByVal VarPar As String = "", Optional ByVal VarTblArmASP As String = "Table01", Optional ByVal VarTblRangDatCalc As String = "", Optional FADatos As String = "", Optional VarTblOpcBusqDatos As String = "") As String      'Se definen 1 parámetros, Nombre Base de Datos y Consulta Inicial
        'Dim ConvEnTblj As String
        Dim ConvEnTbljDob As String

        Dim Fil As Integer = 0 : Dim TotFil As Integer = 0
        Dim Col As Integer = 0 : Dim TotCol As Integer = 0

        Dim FilArr As Integer = 0 : Dim ColArr As Integer = 0
        TotFil = dbDTable.Rows.Count - 1 : TotCol = dbDTable.Columns.Count - 1
        Dim TblFormyVinc(TotFil, TotCol) As String
        Dim Tbl As New Table
        Dim ArmVinc As String = ""
        Dim VarProxBuceo As String = ""

        'Variables para formato del Estilo de la Tabla
        Dim CssFilImp(2) As String : CssFilImp(0) = "" : CssFilImp(1) = "" : CssFilImp(2) = ""
        Dim CssFilPar(2) As String : CssFilPar(0) = "" : CssFilPar(1) = "" : CssFilPar(2) = ""
        Dim CssFilUlt(2) As String : CssFilUlt(0) = "" : CssFilUlt(1) = "" : CssFilUlt(2) = ""
        'Variables para el formato agrupado
        Dim AgrupCont(2) As String : AgrupCont(0) = "" : AgrupCont(1) = "" : AgrupCont(2) = ""
        'Le coloca el nombre de la Tabla, si es TABLE01, TABLE02, ETC.
        Tbl.ID = VarTblArmASP

        '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        'FORMATO DE TODA LA TABLA
        'Especifica el formto general de la Tabla
        Dim ParVal() As String          'Parametro = Valor
        Dim CssTotFil As Integer = 0
        Dim CssTotCol As Integer = 0
        If TblCssGral <> "" Then
            ConvEnTbljDob = FuncConvEnTbl(TblCssGral)   'La variable trae el resultado de si funciono o no la funcion, el contenido esta en la matriz TblaRangoFormatoArray
            'Dim DiAr As Integer
            'DiAr = TblaRangoFormatoArray.GetLength(0)
            'DiAr = TblaRangoFormatoArray.GetLength(1)
            'DiAr = TblaRangoFormatoArray.GetLowerBound(0)
            'DiAr = TblaRangoFormatoArray.GetLowerBound(1)
            CssTotFil = TblaRangoFormatoArray.GetUpperBound(0)
            CssTotCol = TblaRangoFormatoArray.GetUpperBound(1)

            For Fil = 0 To CssTotFil
                For Col = 0 To CssTotCol
                    ParVal = TblaRangoFormatoArray(Fil, Col).Split("¶")
                    If ParVal.Length > 0 Then
                        If ParVal(0).ToString = "TABLA" Then
                            If ParVal.Length - 1 >= 1 Then Tbl.CssClass = ParVal(1).ToString
                        ElseIf ParVal(0).ToString = "AGRCONT" Then
                            AgrupCont(0) = "AGRCONT"
                            If ParVal.Length - 1 >= 1 Then AgrupCont(1) = ParVal(1).ToString
                            If ParVal.Length - 1 >= 2 Then AgrupCont(2) = ParVal(2).ToString
                        ElseIf ParVal(0).ToString = "FILAIMP" Then
                            CssFilImp(0) = "FILAIMP"
                            If ParVal.Length - 1 >= 1 Then CssFilImp(1) = ParVal(1).ToString
                            If ParVal.Length - 1 >= 2 Then CssFilImp(2) = ParVal(2).ToString
                        ElseIf ParVal(0).ToString = "FILAPAR" Then
                            CssFilPar(0) = "FILAPAR"
                            If ParVal.Length - 1 >= 1 Then CssFilPar(1) = ParVal(1).ToString
                            If ParVal.Length - 1 >= 2 Then CssFilPar(2) = ParVal(2).ToString
                        ElseIf ParVal(0).ToString = "ULTFILA" Then
                            CssFilUlt(0) = "ULTFILA"
                            If ParVal.Length - 1 >= 1 Then CssFilUlt(1) = ParVal(1).ToString
                            If ParVal.Length - 1 >= 2 Then CssFilUlt(2) = ParVal(2).ToString
                        End If
                    Else
                        'No hace nada ya que no tiene Parametro = valor
                    End If
                Next Col
            Next Fil
        Else
            'NO TIENE ESPECIFICADO FORMATO DE TABLA GENERAL
        End If

        ' 1.- Primero Debemos poner el título a la Tabla
        If TblTitulo <> "" Then
            If TblTituloVinculo = "" Then
                Dim TitLabel As New Label()
                TitLabel.Text = TblTitulo.ToString
                TitLabel.CssClass = "caption"
                Panel1.Controls.Add(New LiteralControl("<a href='javascript:history.back()'> <img src='../Imagenes/Varias/FlechaAtras.png' alt='Atras' class='fatrasI' /> </a>"))
                Panel1.Controls.Add(TitLabel)
            Else
                Dim TitLinkButt As New LinkButton()
                Dim TitCompleto As String = ""
                Dim VarParVinc As String = ""
                'VarParVinc = FuncHaceVinc(VarPar, VincPar(1).ToString, VarParVinc)

                TitLinkButt.Text = TblTitulo.ToString
                'TitCompleto = TblTituloVinculo & "&TblPars=" & VarParVinc & "&TblTit=" & TblTitulo.ToString
                TitLinkButt.PostBackUrl = TitCompleto
                TitLinkButt.CssClass = "caption"
                Panel1.Controls.Add(New LiteralControl("<a href='javascript:history.back()'> <img src='../Imagenes/Varias/FlechaAtras.png' alt='Atras' class='fatras' /> </a>"))
                Panel1.Controls.Add(TitLinkButt)
            End If
        Else
            'Si no tiene título, no pone nada
        End If

        'Incorpora la fecha de la actualización de los datos
        If FADatos <> "" Then
            Dim FADLabel As New Label()
            FADLabel.Text = FADatos
            FADLabel.CssClass = "fadatos"
            'Panel1.Controls.Add(New LiteralControl("<BR>"))
            'Pone la flecha vuelve atras
            Panel1.Controls.Add(New LiteralControl("<a href='javascript:history.back()'> <img src='../Imagenes/Varias/FlechaAtras.png' alt='Atras' class='fatras' /> </a>"))
            Panel1.Controls.Add(FADLabel)
        End If

        'Analiza si debe incorporar las opciones de búsqueda, en caso de que así sea debe determinar:
        'Primero la ubicación, Segundo el nombre del radiobutton, Tercero el Radiobutton.
        'Esto lo deja en las variables, para que luego se incorporen
        Dim VarTblOpcBusqDatosUbic As String = ""           'Info de la ubicación del Radiobutton, sobre la tabla o debajo
        Dim TitRadioButton As New Label()                   'titulo del radiobutton
        Dim RadioButtonOpcion() As String                   'Información en detalle del radiobuttom
        Dim RadioButtonNombre As String = ""                 'Nombre del radiobutton, sirve para agregarlo al vinculo, y de esa manera cuando se realice click y se carga nuevamente el form, solo busca el cbo excacto
        'Realiza las 3 variable

        If VarTblOpcBusqDatos <> "" Then
            'Si ingresa quiere decir que tienen la opciones incorporadas, ahora debemos extraer la información para incorporar el valor
            Dim VarTblOpcBusqDatExp As String()
            VarTblOpcBusqDatExp = VarTblOpcBusqDatos.Split("‡")
            '1er Col = Ubicacion
            '2da Col = Nombre del Radiobutton
            '3er Col = Info de los valores del Radiobutton
            'Para ello debemos recorrer lo variable
            Dim VarTblODatNum As Integer
            For VarTblODatNum = 0 To VarTblOpcBusqDatExp.GetUpperBound(0)
                Dim VarTblPara As String()
                VarTblPara = VarTblOpcBusqDatExp(VarTblODatNum).Split("¶")
                If VarTblPara(0) = "VincRadioButton" Then
                    RadioButtonNombre = VarTblPara(1)
                    Exit For
                    'Si tiene la opción del Radiobutton y coincide con VincRadioButton es un vinculo a un combo de informe, por ende no hace el combo
                    'ya que esta a nivel de informe y no de tabla
                ElseIf VarTblPara(0) = "Ubicacion" Then
                    '1er Col = Ubicacion
                    VarTblOpcBusqDatosUbic = VarTblPara(1).ToString
                ElseIf VarTblPara(0) = "Nombre" Then
                    '2da Col = Nombre del Radiobutton, El objeto esta declarado al nivel superior
                    TitRadioButton.Text = VarTblPara(1).ToString
                ElseIf VarTblPara(0) = "ProxBuceo" Then
                    '3era Col = código del procimo buceo para la tabla que viene, según haga click.
                    VarProxBuceo = VarTblPara(1).ToString
                ElseIf VarTblPara(0) = "Valores" Then
                    '3er Col = Info de los valores del Radiobutton
                    'Solo busca el nombre del radiobutton, para agregarlo al vinculo
                    'Debe realizar un bucle por las distintas opciones del RadioButton
                    VarTblOpcBusqDatExp(VarTblODatNum) = Right(VarTblOpcBusqDatExp(VarTblODatNum), Len(VarTblOpcBusqDatExp(VarTblODatNum)) - 8)
                    RadioButtonOpcion = VarTblOpcBusqDatExp(VarTblODatNum).Split("†")      'Separa las distintas opciones
                    'Los RadioButtom, se agrega un buttom por cada opción
                    Dim RdioButOpParVal() As String
                    Dim RBO As Integer
                    For RBO = 0 To RadioButtonOpcion.GetUpperBound(0)
                        '†				            -- Separa cada opción del Radio Button
                        'ID:NombreId			    -- Es el nombre individual del control
                        '¶GroupName:Opb01		    -- Es el nombre que agrupa los distintos Checked
                        '¶Text:ValordelCompo		-- Es el valor que figura en el combo
                        '¶Checked:True o False		-- Determina si esta chequeado por defecto
                        '¶CssClass:ValorEspec		-- Contiene el formato del combo
                        '¶AutoPostBack:True o False	-- Si cuando se hace click recarga la pagina

                        'ID:CLITIPO†Text:Cliente Tipo†Checked:True;‡ID:FACNUM†Text:Factura' AS '<br>Opb01'
                        Dim RdioB As New RadioButton        'Especifica el nuevo objeto RadioButton
                        Dim RBPV As Integer                 'Variable para hacer bucle en el RB Parametros : Valor
                        Dim ParValor() As String
                        RdioButOpParVal = RadioButtonOpcion(RBO).Split("§")          'Separa los distintos parámetros del RB
                        For RBPV = 0 To RdioButOpParVal.GetUpperBound(0)
                            ParValor = RdioButOpParVal(RBPV).Split("¶")
                            Select Case ParValor(0)
                                Case "GroupName"
                                    RadioButtonNombre = ParValor(1)
                                    Exit For
                            End Select
                        Next RBPV
                        If RadioButtonNombre <> "" Then Exit For
                    Next RBO
                End If
            Next VarTblODatNum
        End If

        'Agrega el radiobuttom para la busqueda si corresponde
        If VarTblOpcBusqDatosUbic = "Sobre Tabla" Then
            'Verifica si hay radio buttom
            If (RadioButtonOpcion IsNot Nothing AndAlso RadioButtonOpcion.Count > 0) Then
                Panel1.Controls.Add(New LiteralControl("<br /> <br />"))
                'Titulo del RadioButtom
                Panel1.Controls.Add(TitRadioButton)

                'Los RadioButtom, se agrega un buttom por cada opción
                Dim RdioButOpParVal() As String
                Dim RBO As Integer
                For RBO = 0 To RadioButtonOpcion.GetUpperBound(0)
                    '†				            -- Separa cada opción del Radio Button
                    'ID:NombreId			    -- Es el nombre individual del control
                    '¶GroupName:Opb01		    -- Es el nombre que agrupa los distintos Checked
                    '¶Text:ValordelCompo		-- Es el valor que figura en el combo
                    '¶Checked:True o False		-- Determina si esta chequeado por defecto
                    '¶CssClass:ValorEspec		-- Contiene el formato del combo
                    '¶AutoPostBack:True o False	-- Si cuando se hace click recarga la pagina

                    'ID:CLITIPO†Text:Cliente Tipo†Checked:True;‡ID:FACNUM†Text:Factura' AS '<br>Opb01'
                    Dim RdioB As New RadioButton        'Especifica el nuevo objeto RadioButton
                    Dim RBPV As Integer                 'Variable para hacer bucle en el RB Parametros : Valor
                    Dim ParValor() As String
                    RdioButOpParVal = RadioButtonOpcion(RBO).Split("§")          'Separa los distintos parámetros del RB
                    For RBPV = 0 To RdioButOpParVal.GetUpperBound(0)
                        ParValor = RdioButOpParVal(RBPV).Split("¶")
                        Select Case ParValor(0)
                            Case "ID"
                                RdioB.ID = ParValor(1)
                            Case "Text"
                                RdioB.Text = ParValor(1)
                            Case "Checked"
                                If ParValor(1) = "True" Then
                                    RdioB.Checked = True
                                End If
                            Case "GroupName"
                                RdioB.GroupName = ParValor(1)
                        End Select
                    Next RBPV
                    Panel1.Controls.Add(RdioB)      'Agrega el RadioButton
                    'RdioB.Attributes.Add("Par1", "Esto es una Prueba")
                    'Si en los parámetros de la consulta SQL no trae el GroupName, agrega el GroupName como nombre del campo
                    'If RdioB.GroupName = "" Then
                    '    RdioB.GroupName = NomCol        'Nombre al Grupo de Controles
                    'End If

                    'Pone a cero las variables ya utilizadas
                    'RdioB.ID = ""
                    'RdioB.Text = ""
                    'RdioB.GroupName = ""
                    'RdioB.Checked = False
                Next RBO
                Panel1.Controls.Add(New LiteralControl("<BR>"))
            Else
                'No hay datos del radiobuttom, no carga nada
            End If
        End If

        '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        'Arma la Tabla que vee el usuario
        ' 2.- Arma la tabla del campo multivaluado.
        ' Organiza el formato y los vínculos de las tablas
        ' Debemos poner el título a cada columna
        ' Genera la Tabla TblaRangoFormatoArray, con la información para armar la Tabla
        ' Aquí ya tenemos una tabla donde:
        ' Primero esta el rango donde se aplica.
        ' Luego esta el formato que hay que aplicar al rango (este es un campo multivaluado, ya que puede haber distintos formatos a aplicar, letra, tamano, tipo, etc).

        If TblFomCss <> "" Then
            ConvEnTbljDob = ConvEnTblDoble(TblFomCss)   'La variable trae el resultado de si funciono o no la funcion, el contenido esta en la matriz TblaRangoFormatoArray
        End If

        'Variables usadas para los formatos
        Dim FilTot As Integer = 0
        Dim ColTot As Integer = 0

        'Datos del Campo
        Dim ValCampo As String = ""                 'Datos del Campo
        Dim ValCampoFila = "Distinto"               'Datos del valor del campo de la fila anterior
        Dim ValCampoRtado As String = "Distinto"    'Datos de la Comparación del ValCampo Vs ValCampoAnt
        Dim ValCampoFilaFormato As String = "FILAPAR"      'Valor del formato de la fila anterior
        Dim TextoAAgregar As String = ""        'Datos del campo con modificaciones de formato
        Dim DatoTipComp As String = ""          'Dato con el tipo de componente que se agrega, LABEL, LINKBUTTON, ETC
        Dim DatoTipCompRtado() As String


        'Formato de la Celda
        Dim FtoColAncho As String = ""
        Dim FtoColOrden As String = ""
        Dim FtoColAlin As String = ""

        '##################################################################################################################################################
        '   ANTES DE GENERAR LA TABLA DINÁMICA - CALCULA LOS TOTALES - ASÍ SE LOS AGREGA LUEGO ANTES O DESPUES DEL FINAL
        '--------------------------------------------------------------------------------------------------------------------------------------------------
        Dim CalcTotaTabla As String
        Dim CantRegTot As Integer
        If VarTblRangDatCalc <> "" Then
            CalcTotaTabla = FuncCalcTotaTabla(DtRFilasActuales, TotFil, TotCol, VarTblRangDatCalc)
            'Ya tiene calculado los valores totales
            CantRegTot = CalcTotaTabla + 1    'Se le suma 1, ya que el valor 0 es la primer unidad
        End If

        '   GENERA TABLA DINÁMICA - con los datos de la consulta
        '--------------------------------------------------------------------------------------------------------------------------------------------------
        Dim DTableCantFil As Integer
        DTableCantFil = dbDTable.Rows.Count
        ReDim TablaDinam(DTableCantFil + CantRegTot, dbDTable.Columns.Count - 1)
        Dim FilaAAgregar As Integer = 0
        Dim TablaUltValor As String = ""
        'Primero inserta los títulos
        For Fil = 0 To 0                'Los nombres de las columnas siempre tienen solo una fila
            'TablaUltValor = ""
            For Col = 0 To dbDTable.Columns.Count - 1
                TablaDinam(Fil, Col) = dbDTable.Columns(Col).Caption.ToString
                'TablaUltValor = TablaUltValor + " | " + TablaDinam(Fil, Col)
            Next Col
        Next Fil
        ColTot = Col - 1        'La cantidad de columnas
        FilaAAgregar = 1        'Se le agrega 1, por el título, siempre es una fila

        'Si los totales van antes que los datos los agrega ahora
        If VarTblRangDatCalc <> "" Then
            For Fil = 0 To CantRegTot - 1
                For Col = 0 To dbDTable.Columns.Count - 1
                    'Se le agrega 1, por el título, siempre es una fila
                    If Left(dbDTable.Columns(Col).Caption.ToString, 4) = "<br>" Then
                        TablaDinam(Fil + FilaAAgregar, Col) = "<br>"
                        TablaUltValor = TablaUltValor + " | <br>"
                    Else
                        TablaDinam(Fil + FilaAAgregar, Col) = TablaDinamTotal(Fil, Col)
                        TablaUltValor = TablaUltValor + " | " + TablaDinamTotal(Fil, Col)
                    End If
                Next Col
            Next Fil
            'Se agregan las filas según los totales
            FilaAAgregar = FilaAAgregar + CantRegTot    'Se le suma las filas que ocupan los totales
        End If

        'Luego inserta los valores
        For Fil = 0 To DTableCantFil - 1   'Los nombres de las columnas siempre tienen solo una fila
            'TablaUltValor = ""
            For Col = 0 To ColTot
                'Se le agrega 1, ya que el cero son los TÍTULOS
                TablaDinam(Fil + FilaAAgregar, Col) = DtRFilasActuales(Fil)(Col).ToString
                'TablaUltValor = TablaUltValor + " | " + TablaDinam(Fil + 1, Col)
            Next Col
        Next Fil

        'Le agrega los Totales ya que van al Final
        FilTot = TablaDinam.GetLength(0) - 1
        'TablaUltValor = ""
        

        '##################################################################################################################################################
        '   TITULOS
        '--------------------------------------------------------------------------------------------------------------------------------------------------
        'Variable para la Fila
        Dim FilVisible As String = "VISIBLE"     'Por defecto todas las filas son visibles.

        '##################################################################################################################################################
        '   FILAS
        '--------------------------------------------------------------------------------------------------------------------------------------------------
        '3.- Tercero recorremos el recordset creando una fila nueva por cada registro 
        For Fil = 0 To FilTot
            Dim TblRow As New TableRow()       'Agrega una nueva variable para una nueva Fila

            For Col = 0 To ColTot
                ' Variables para armar la Tabla
                Dim TblHedCel As New TableHeaderCell()      'Header Cell
                Dim TblDatCel As New TableCell()            'Table Cell

                'Variables para tomar el contenido del formato
                Dim RtadoTblFtoUsu As Integer = 0

                '2.- Segundo debemos poner el título a cada columna
                'Variables que si o si tienen todos los campos
                Dim ColVisible As String = "VISIBLE" : Dim ColVisNivel As Integer = 2       'Por defecto todas las columnas son visibles.
                Dim CpCssClas As String = "UNSORTABLE" : Dim CpCsClNivel As Integer = 0     'Por defecto las columnas no se ordenan.
                Dim CpWidth As String = "AUTOAJUSTABLE" : Dim CpWidthNivel As Integer = 2   'Por defecto no se especifica el ancho.
                Dim CpTipo As String = "LABEL" : Dim CpTipNivel As Integer = 0

                If Fil = 1 And Col = 2 Then
                    Fil = Fil
                End If

                'Aquí hay que verificar si tiene vinculo, o es formula, etc.
                ValCampo = TablaDinam(Fil, Col)          'Aquí toma el valor del campo, puede tener modificaciones de formato.
                'Cuando sea de la segunda fila en adelante, verifica que el valor del campo sea distinto
                If Fil > 0 Then
                    If AgrupCont(1) = "FilColClave" Then
                        'Determina si la fila es distinta, en base a la columna clave, luego ingresa a los campos
                        If TablaDinam(Fil, AgrupCont(2)) = TablaDinam(Fil - 1, AgrupCont(2)) Then
                            ValCampoFila = "Igual"
                            If ValCampo = TablaDinam(Fil - 1, Col) Then
                                ValCampoRtado = "Igual"
                            Else
                                ValCampoRtado = "Distinto"
                            End If
                            'Determina la agrupacion de contenido solo por el contenido de la celda, no con fila / columna clave
                        Else
                            ValCampoFila = "Distinto"
                            ValCampoRtado = "Distinto"
                        End If
                    ElseIf AgrupCont(1) = "CeldaClave" Then
                        'Determina si la celda es distinta
                        'If TablaDinam(Fil, 5) = TablaDinam(Fil - 1, 5) Then
                        '    ValCampoFila = "Igual"
                        If ValCampo = TablaDinam(Fil - 1, Col) Then
                            ValCampoFila = "Igual"
                            ValCampoRtado = "Igual"
                        Else
                            ValCampoFila = "Distinto"
                            ValCampoRtado = "Distinto"
                        End If
                        'Determina la agrupacion de contenido solo por el contenido de la celda, no con fila / columna clave
                        'Else
                        '    ValCampoFila = "Distinto"
                        '    ValCampoRtado = "Distinto"
                        'End If
                    Else
                        'No esta activada la agrupación de contenido
                        ValCampoFila = "Distinto"
                        ValCampoRtado = "Distinto"
                    End If
                Else
                    'El valor de Fil = 0 es el título, no tiene comparación
                    ValCampoFila = "Distinto"
                    ValCampoRtado = "Distinto"
                End If

                Dim TipoFormatoCss As String = ""
                If IsNothing(ValCampo) = True Then
                    ValCampo = ""
                ElseIf Left(ValCampo, 4) = "<br>" Then
                    ValCampo = ""
                    TipoFormatoCss = "<br>"
                End If
                
                RtadoTblFtoUsu = FuncTblFtoUsu(Fil, Col)                    'Devuelve el Formato del usuario en una Tabla para aplicar al Formato .Net
                'Si el formato a aplicar es superior siempre prevalece. 
                'Eje: la Celda es el último formato Nivel 4, la hoja es el general Nivel 0. La hoja puede tener un tamano de letra, pero la celda otro y este es el que va.
                'Aplica el formato establecido, luego establece el nivel de formato que se aplicó. 
                Dim FtoAplCant As Integer = 0

                For FtoAplCant = 0 To RtadoTblFtoUsu
                    Select Case FtoAplicar(FtoAplCant, 5)       'El Valor 5, es el FtoAplizar Nivel
                        Case 0      'Nivel Hoja

                        Case 1      'Nivel Fila
                            'Determina los parámetros a ajustar para el Nivel Fila
                            If FtoAplicar(FtoAplCant, 0) = "FIL" And FtoAplicar(FtoAplCant, 1) = "VISIBILIDAD" Then
                                '1.- Segundo parámetro VISIVILIDAD
                                If FtoAplicar(FtoAplCant, 2) = "OCULTAR" Then
                                    FilVisible = "OCULTAR"          'Oculta la Fila, y sale del análisis
                                    GoTo ProxFila1
                                End If
                            ElseIf FtoAplicar(FtoAplCant, 0) = "FIL" And FtoAplicar(FtoAplCant, 1) = "CssClas" Then
                                '2.- Estilo de la Fila
                                'If FtoAplicar(FtoAplCant, 2) = "OCULTAR" Then
                                '    FilVisible = "OCULTAR"          'Oculta la Fila, y sale del análisis
                                '    GoTo ProxFila1
                                'End If
                            End If
                        Case 2      'Nivel Columna
                            'Determina los parámetros a ajustar para el Nivel Columna
                            If FtoAplicar(FtoAplCant, 0) = "COL" And FtoAplicar(FtoAplCant, 1) = "VISIBILIDAD" Then
                                '1.- Segundo parámetro VISIVILIDAD
                                If FtoAplicar(FtoAplCant, 2) = "OCULTAR" Then
                                    ColVisible = "OCULTAR"          'Oculta la Fila, y sale del análisis
                                    GoTo ProxCol1
                                End If
                            ElseIf FtoAplicar(FtoAplCant, 0) = "COL" And FtoAplicar(FtoAplCant, 1) = "ANCHO" Then
                                '2.- Primer parámetro ANCHO
                                FtoColAncho = FuncFtoColAncho(FtoAplicar(FtoAplCant, 2))
                            ElseIf FtoAplicar(FtoAplCant, 0) = "COL" And FtoAplicar(FtoAplCant, 1) = "ORDEN" Then
                                '3.- Primer parámetro ORDEN
                                FtoColOrden = FuncFtoColOrden(FtoAplicar(FtoAplCant, 2))
                            ElseIf FtoAplicar(FtoAplCant, 0) = "DATO" And FtoAplicar(FtoAplCant, 1) = "CATEGORIA" Then
                                'Si se usa el Texto a Agregar es porque, el campo con el valor es multivaluado, (Ej: dato del vinculo, dato a mostrar).
                                If TextoAAgregar = "" Then      'Verifica esto, ya que el valor del campo puede ser multivaluado (para vinculo, valor que se muestra, etc).
                                    TextoAAgregar = ValCampo
                                End If
                                TextoAAgregar = DatFto(TextoAAgregar, FtoAplicar(FtoAplCant, 2))
                            ElseIf FtoAplicar(FtoAplCant, 0) = "FUENTE" And FtoAplicar(FtoAplCant, 1) = "ALINHORIZ" Then
                                FtoColAlin = FuncFtoColAlin(FtoAplicar(FtoAplCant, 2))
                            ElseIf FtoAplicar(FtoAplCant, 0) = "DATO" And FtoAplicar(FtoAplCant, 1) = "TIPCOMP" Then
                                '0 = FtoTipo, 1 = FtoParametro, 2 = FtoParValor, 3 = FtoParValorAdic, 4 = FtoParRegla, 5 = FtoNivel
                                '1.- Segundo parámetro VISIVILIDAD
                                'Tipo de campo que se incorpora
                                '1.- Primer parametro = tipo de dato, 2.- Segundo parametro = valor del campo, 3.- Tercer parametro = Vinculo, 4.- Cuarto parametro = Parametros, 5.- Quinto parametro = FilaActual, 6.- Sexto parametro = ColumnaActual
                                If ValCampo <> "" Then
                                    DatoTipComp = FuncDatoTipComp(FtoAplicar(FtoAplCant, 2), ValCampo, FtoAplicar(FtoAplCant, 3), VarPar, Fil, Col)
                                End If
                            End If
                        Case 3, 4      'Nivel Rango o Celda
                            'Tipo de campo que se incorpora
                            If FtoAplicar(FtoAplCant, 0) = "DATO" And FtoAplicar(FtoAplCant, 1) = "CATEGORIA" Then
                                'Si se usa el Texto a Agregar es porque, el campo con el valor es multivaluado, (Ej: dato del vinculo, dato a mostrar).
                                If TextoAAgregar = "" Then      'Verifica esto, ya que el valor del campo puede ser multivaluado (para vinculo, valor que se muestra, etc).
                                    TextoAAgregar = ValCampo
                                End If
                                TextoAAgregar = DatFto(TextoAAgregar, FtoAplicar(FtoAplCant, 2))
                                TblDatCel.HorizontalAlign = HorizontalAlign.Right
                            ElseIf FtoAplicar(FtoAplCant, 0) = "FUENTE" And FtoAplicar(FtoAplCant, 1) = "ALINHORIZ" Then
                                FtoColAlin = FuncFtoColAlin(FtoAplicar(FtoAplCant, 2))
                            ElseIf FtoAplicar(FtoAplCant, 0) = "DATO" And FtoAplicar(FtoAplCant, 1) = "TIPCOMP" Then
                                '0 = FtoTipo, 1 = FtoParametro, 2 = FtoParValor, 3 = FtoParValorAdic, 4 = FtoParRegla, 5 = FtoNivel
                                '1.- Segundo parámetro VISIVILIDAD
                                'Tipo de campo que se incorpora
                                '1.- Primer parametro = tipo de dato, 2.- Segundo parametro = valor del campo, 3.- Tercer parametro = Vinculo, 4.- Cuarto parametro = Parametros, 5.- Quinto parametro = FilaActual, 6.- Sexto parametro = ColumnaActual
                                If ValCampo <> "" Then
                                    DatoTipComp = FuncDatoTipComp(FtoAplicar(FtoAplCant, 2), ValCampo, FtoAplicar(FtoAplCant, 3), VarPar, Fil, Col)
                                End If
                            End If
                    End Select
                Next FtoAplCant     'Pasa el formato a .net

                '############################################################################################
                'Incorpora los Valores a las propiedades del componente

                'Dependiendo el tipo de campo especificado es lo que se incorpora, 
                'aquí puede incorporar Label, LinkButton, InputBox, etc, y en función de esto son los parámetros específicos que se completan.
                'Hay que analizar el análisis de la variable TextoAAgregar
                Dim DFil As String = ""
                Dim DCol As String = ""
                If Fil < 10 Then
                    DFil = "00" & Fil
                ElseIf Fil < 100 Then
                    DFil = "0" & Fil
                Else
                    DFil = Fil
                End If
                If Col < 10 Then
                    DCol = "00" & Col
                ElseIf Col < 100 Then
                    DCol = "0" & Col
                Else
                    DCol = Col
                End If

                DatoTipCompRtado = DatoTipComp.Split("‡")
                'Si los valores de las celdas son distintos, ingresa el dato tal cual, de lo contrario pone un label vacio
                If ValCampoRtado = "Distinto" Then
                    If DatoTipCompRtado(0) = "LINKBUTTON" Then               '2.- Determina el tipo de objeto que agrega
                        Dim LinkButt As New LinkButton()
                        Dim VincCompl As String = ""
                        If TextoAAgregar <> "" Then
                            LinkButt.Text = TextoAAgregar                       'Agrega el valor del campo al linkbutton
                        Else
                            LinkButt.Text = DatoTipCompRtado(1)                 'Agrega el valor del campo al linkbutton
                        End If
                        LinkButt.ID = "dlbt" & DFil & DCol                      'Agrega el id al linkbutton para que sean todos distintos
                        'Verifica si al vinculo le carga el RdioBut
                        If RadioButtonNombre <> "" Then
                            VincCompl = Server.HtmlEncode(DatoTipCompRtado(2)) & "&BucRdioBut=" & Server.HtmlEncode(RadioButtonNombre) & "&ProxBuceo=" & Server.HtmlEncode(VarProxBuceo)
                        Else
                            VincCompl = DatoTipCompRtado(2)
                        End If
                        LinkButt.PostBackUrl = VincCompl                       'Agrega el vinculo
                        If Fil = 0 Then
                            TblHedCel.Controls.Add(LinkButt)                    'Agrega el linkbutton a la Celda
                        Else
                            TblDatCel.Controls.Add(LinkButt)                    'Agrega el linkbutton a la Celda
                        End If
                        DatoTipComp = ""                                        'Borra la variable ya utilizada
                        Array.Clear(DatoTipCompRtado, 0, DatoTipCompRtado.Length)       'Ya utilizada, borra el array
                        ValCampo = "" : TextoAAgregar = ""                      'Limpia las variables
                    ElseIf DatoTipCompRtado(0) = "LABEL" Then
                        Dim Labl As New Label()
                        Labl.Text = DatoTipCompRtado(1)                         'Agrega el valor del campo al label
                        If Fil = 0 Then
                            Labl.ID = "Hdlab" & DFil & DCol                     'Agrega el id al label para que sean todos distintos
                            TblHedCel.Controls.Add(Labl)                        'Agrega el label a la Celda
                        Else
                            Labl.ID = "dlab" & DFil & DCol                      'Agrega el id al label para que sean todos distintos
                            TblDatCel.Controls.Add(Labl)                        'Agrega el label a la Celda
                        End If
                        DatoTipComp = ""                                        'Borra la variable ya utilizada
                        Array.Clear(DatoTipCompRtado, 0, DatoTipCompRtado.Length)       'Ya utilizada, borra el array
                        'TblDatCel.Controls.Add(New LiteralControl(ValCampo))            'Agrega el label a la Celda
                        ValCampo = "" : TextoAAgregar = ""      'Limpia las variables
                    Else
                        Dim Labl As New Label()
                        If TextoAAgregar = "" Then                              'Verifica esto, ya que el valor del campo puede ser multivaluado (para vinculo, valor que se muestra, etc).
                            TextoAAgregar = ValCampo
                        End If
                        If ValCampo <> "" Then
                            Labl.Text = TextoAAgregar                           'Agrega el valor del campo al label
                            If Fil = 0 Then
                                Labl.ID = "HdlabE" & DFil & DCol                'Agrega el id al label para que sean todos distintos
                                TblHedCel.Controls.Add(Labl)                    'Agrega el label a la Celda
                            Else
                                Labl.ID = "dlabE" & DFil & DCol                 'Agrega el id al label para que sean todos distintos
                                TblDatCel.Controls.Add(Labl)                    'Agrega el label a la Celda
                            End If
                        End If
                        ValCampo = "" : TextoAAgregar = ""                      'Limpia las variables
                    End If
                Else
                    Dim Labl As New Label()
                    If TextoAAgregar = "" Then                              'Verifica esto, ya que el valor del campo puede ser multivaluado (para vinculo, valor que se muestra, etc).
                        TextoAAgregar = ""
                    End If
                    If ValCampo <> "" Then
                        Labl.Text = TextoAAgregar                           'Agrega el valor del campo al label
                        If Fil = 0 Then
                            Labl.ID = "HdlabE" & DFil & DCol                'Agrega el id al label para que sean todos distintos
                            TblHedCel.Controls.Add(Labl)                    'Agrega el label a la Celda
                        Else
                            Labl.ID = "dlabE" & DFil & DCol                 'Agrega el id al label para que sean todos distintos
                            TblDatCel.Controls.Add(Labl)                    'Agrega el label a la Celda
                        End If
                    End If
                    ValCampo = "" : TextoAAgregar = ""                      'Limpia las variables
                End If

                '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                'FORMATO DE TODA LA CELDA
                'Alineación de la Celda
                If FtoColAlin <> "" Then
                    If Fil = 0 Then
                        TblHedCel.HorizontalAlign = FtoColAlin      'Define la alineación de la celda
                    Else
                        TblDatCel.HorizontalAlign = FtoColAlin      'Define la alineación de la celda
                    End If
                    FtoColAlin = ""                             'Limpia la variable luego de su uso
                End If

                'Ancho de la Celda
                If FtoColAncho = "AUTOAJUSTABLE" Then
                    'Lo hace solo la tabla
                ElseIf FtoColAncho <> "" Then
                    If Fil = 0 Then
                        TblHedCel.Width = FtoColAncho       'Si no es autoajustable, le agrega un valor
                    Else
                        TblDatCel.Width = FtoColAncho       'Si no es autoajustable, le agrega un valor
                    End If
                    FtoColAncho = ""                    'Limpia la variable luego de su uso
                End If

                'Clase de la Celda -- CssClass
                If TipoFormatoCss = "<br>" Then
                    'Esto lo hace para cada celda de la columna y por lo tanto toda la columna es vacia.
                    If Fil = 0 Then
                        TblHedCel.CssClass = "BCR"
                    Else
                        TblDatCel.CssClass = "BCR"
                    End If
                Else
                    If Fil = 0 Then
                        TblHedCel.CssClass = FtoColOrden   'Le agrega la clase a la celda
                    Else
                        TblDatCel.CssClass = FtoColOrden   'Le agrega la clase a la celda
                    End If
                End If

                'Limpia la variable luego de su uso
                FtoColOrden = ""
                'Borra la especificación del formato
                TipoFormatoCss = ""


                '######################################################################################################################
                '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                'Al Final agrega la celda
                If Fil = 0 Then
                    TblRow.Cells.Add(TblHedCel)         'Agrega la Celda a la Fila
                Else
                    TblRow.Cells.Add(TblDatCel)         'Agrega la Celda a la Fila
                End If
                '######################################################################################################################
ProxCol1:
            Next Col

ProxFila1:
            If FilVisible = "VISIBLE" Then              '1.- Determina si se agrega la Fila, La visibilidad es a nivel Fila.
                'Especifica el formato de las Filas
                If Fil > 0 Then                                 'Mayor que cero, por el título
                    If TablaDinam(Fil, 0) = "TOTAL" Then
                        TblRow.CssClass = "sortbottom"   'Especifica el formato de la fila Titulo
                    ElseIf Fil = FilTot And CssFilUlt(0) = "ULTFILA" Then
                        'Determina si el valor de campo de la fila anterior son iguales, mantiene el formato anterior
                        If ValCampoFila = "Distinto" Then
                            If ValCampoFilaFormato = "FILAIMP" Then
                                TblRow.CssClass = CssFilUlt(1) & CssFilPar(1)
                            ElseIf ValCampoFilaFormato = "FILAPAR" Then
                                TblRow.CssClass = CssFilUlt(1) & CssFilImp(1)
                            Else
                                TblRow.CssClass = CssFilUlt(1)
                            End If
                        Else
                            'Las filas tiene el mismo valor, por lo tanto no cambia el formato.
                            If ValCampoFilaFormato = "FILAPAR" Then
                                TblRow.CssClass = CssFilUlt(1) & CssFilPar(1)
                            ElseIf ValCampoFilaFormato = "FILAIMP" Then
                                TblRow.CssClass = CssFilUlt(1) & CssFilImp(1)
                            Else
                                TblRow.CssClass = CssFilUlt(1)
                            End If
                        End If
                    Else
                        'Determina si el valor de campo de la fila anterior son iguales, mantiene el formato anterior
                        If ValCampoFila = "Distinto" Then
                            If ValCampoFilaFormato = "FILAPAR" Then
                                TblRow.CssClass = CssFilImp(1)
                                ValCampoFilaFormato = "FILAIMP"
                            Else
                                TblRow.CssClass = CssFilPar(1)
                                ValCampoFilaFormato = "FILAPAR"
                            End If
                            'If FuncEsPar(Fil) = True And CssFilPar(0) = "FILAPAR" Then
                            '    TblRow.CssClass = CssFilPar(1)
                            '    ValCampoFilaFormato = "FILAPAR"
                            'ElseIf FuncEsPar(Fil) = False And CssFilImp(0) = "FILAIMP" Then
                            '    TblRow.CssClass = CssFilImp(1)
                            '    ValCampoFilaFormato = "FILAIMP"
                            'End If
                        Else
                            'Las filas tiene el mismo valor, por lo tanto no cambia el formato.
                            If ValCampoFilaFormato = "FILAPAR" Then
                                TblRow.CssClass = CssFilPar(2)
                            Else
                                TblRow.CssClass = CssFilImp(2)
                            End If
                            'If ValCampoFilaFormato = "FILAPAR" Then
                            '    TblRow.CssClass = CssFilPar(1)
                            'ElseIf ValCampoFilaFormato = "FILAIMP" Then
                            '    TblRow.CssClass = CssFilImp(1)
                            'End If
                        End If
                    End If

                End If
                '######################################################################################################################
                '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                Tbl.Rows.Add(TblRow)    'Agrega la Fila completa a la Tabla
                '######################################################################################################################
            Else
                'Si no es visible la fila no la incorpora a la tabla
                'Las columnas se omiten cuando se arma la fila en el bucle de columna
            End If
        Next Fil        'Proxima Fila


            '' Aquí llama a la función para transformar el campo multivaluado en una tabla
            'ConvEnTblj = ConvEnTbl(Vinculo)   'La variable trae el resultado de si funciono o no la funcion

            'For Fil = 0 To DtRFilasActuales.Length - 1
            '    Dim r As New TableRow() 'Agrega una nueva Fila
            '    ' Borrar Inicio
            '    For Col = 0 To dbDTable.Columns.Count - 1
            '        Dim Celda As New TableCell()
            '        'Dim LinkButt As New LinkButton()
            '        Dim TextoAAgregar As String = ""
            '        Dim TipoControl As String = ""
            '        Dim TipoFormato As String = ""

            '        'Si la columna define el tipo de Fila, o Se especifica que no se muestra, no la carga
            '        If dbDTable.Columns(Col).Caption.ToString <> "TIPOFILA" And InStr(dbDTable.Columns(Col).Caption.ToString, "†NM", CompareMethod.Text) = 0 Then
            '            'Aquí estamos en cada celda de la tabla que se va a realizar
            '            '################################################################################################################################3
            '            'Ya cargada
            '            If DtRFilasActuales(Fil)(0).ToString <> "NULL" Or DtRFilasActuales(Fil)(Col).ToString <> "" Then
            '                'Especifica el formato de la de fila, si es total o datos
            '                If DtRFilasActuales(Fil)(0).ToString = "TOTAL" Then
            '                    'Si la fila es un Total, tiene un formato específico
            '                    'Celda.CssClass = "sortbottom"   'Especifica el formato de la fila Titulo
            '                    'Celda.CssClass = "tbleceltot"   'Especifica el formato de la fila Titulo
            '                ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then
            '                    'Si la fila es de Datos, tiene un formato específico
            '                    'Celda.CssClass = "TblCelEst"
            '                End If
            '                '################################################################################################################################3

            '                'Ahora debemos recorrer el array para ver si tiene vinculo, formato, etc.
            '                'Aquí se debe verificar:
            '                ' Control a Utilizar
            '                ' Si tiene Vínculo
            '                ' Tipo de Formato del Valor
            '                ' Tipo de fondo de la celda
            '                ' Ver en excel que mas aspectos tiene la celda

            '                ''SOLO CARGA EL LINKBUTON
            '                'For FilArr = 1 To TblaRangoFtoArrFilTot
            '                '    '1.- TIPO DE CONTROL QUE SE DEBE AGREGAR PARA CADA CELDA
            '                '    'Recorre la matriz con la info

            '                '    'Primero verifica si la fila esta incluída
            '                '    If Fil = TblaTxtMultValenArray(FilArr, 0) Or TblaTxtMultValenArray(FilArr, 0) = -1 Then     'FIL
            '                '        'Verifica si la columna esta incluída, si es así pone la especificación
            '                '        If Col = TblaTxtMultValenArray(FilArr, 1) Or TblaTxtMultValenArray(FilArr, 1) = -1 Then    'COL
            '                '            'Verifica el tipo de columna, y en función de eso procede a tipificarla
            '                '            If TblaTxtMultValenArray(FilArr, 2) = "CONTROL" Then    'TIPO
            '                '                If TblaTxtMultValenArray(FilArr, 3) = "LINKBUTTON" Then   'VALOR
            '                '                    TipoControl = "LinkButton"
            '                '                    LinkButt.ID = "vinc" & Fil & Col
            '                '                    'Verifica si el vinculo que viene de la consulta sql tiene codigo y descripción
            '                '                    Dim DatVinc() As String
            '                '                    If DtRFilasActuales(Fil)(Col).ToString = "" Then
            '                '                        ReDim DatVinc(0)
            '                '                        DatVinc(0) = DtRFilasActuales(Fil)(Col).ToString
            '                '                    Else
            '                '                        DatVinc = DtRFilasActuales(Fil)(Col).ToString.Split("†")
            '                '                    End If

            '                '                    If DatVinc.Length = 3 Then  'Tiene 2 valores (0 y 1), tiene codigo
            '                '                        TextoAAgregar = DatVinc(2).ToString()
            '                '                        If VarPar = "" Then
            '                '                            LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
            '                '                            'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
            '                '                        Else
            '                '                            LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
            '                '                            'LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
            '                '                        End If
            '                '                    ElseIf DatVinc.Length = 2 Then  'Tiene 2 valores (0 y 1), tiene codigo
            '                '                        TextoAAgregar = DatVinc(1).ToString()
            '                '                        If VarPar = "" Then
            '                '                            LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
            '                '                            'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
            '                '                        Else
            '                '                            LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
            '                '                        End If
            '                '                    Else
            '                '                        TextoAAgregar = DatVinc(0).ToString()
            '                '                        If VarPar = "" Then
            '                '                            LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(0).ToString()
            '                '                        Else
            '                '                            LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(0).ToString()
            '                '                        End If
            '                '                    End If
            '                '                End If  'ESPECIFICACIONES   'LINKBUTON
            '                '            End If
            '                '        Else
            '                '            'No hace nada, ya que puede ser que en otra fila de array este especificado
            '                '        End If
            '                '    Else
            '                '        'No hace nada, ya que puede ser que en otra fila de array este especificado
            '                '    End If
            '                'Next FilArr

            '                '2.- FORMATO DEL VALOR A AGREGAR
            '                '    Recorre la matriz con la info
            '                For FilArr = 1 To TblaRangoFtoArrFilTot
            '                    'Primero verifica si la fila esta incluída
            '                    If Fil = TblaTxtMultValenArray(FilArr, 0) Or TblaTxtMultValenArray(FilArr, 0) = -1 Then     'FIL
            '                        'Verifica si la columna esta incluída, si es así pone la especificación
            '                        If Col = TblaTxtMultValenArray(FilArr, 1) Or TblaTxtMultValenArray(FilArr, 1) = -1 Then    'COL
            '                            'Celda que tiene un formato específico
            '                            'Verifica el tipo de columna, y en función de eso procede a tipificarla
            '                            If TblaTxtMultValenArray(FilArr, 2) = "FORMATO" Then    '
            '                                If TblaTxtMultValenArray(FilArr, 3) = "MONEDA" Then   'VALOR
            '                                    If IsNumeric(DtRFilasActuales(Fil)(Col)) = True Then
            '                                        Dim MyNum As Double = 0
            '                                        If TextoAAgregar = "" Then
            '                                            MyNum = DtRFilasActuales(Fil)(Col)
            '                                            TextoAAgregar = MyNum.ToString("$#,##0;($#,##0);0")
            '                                            'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
            '                                        Else
            '                                            MyNum = CDbl(TextoAAgregar)
            '                                            TextoAAgregar = MyNum.ToString("$#,##0;($#,##0);0")
            '                                            'TextoAAgregar = String.Format("{0,1:C0}", CDbl(TextoAAgregar))
            '                                        End If
            '                                        'Todos los valores numéricos se alinean a la derecha
            '                                        Celda.HorizontalAlign = HorizontalAlign.Right
            '                                    Else
            '                                        'No hace nada ya que no se puede convertir el dato
            '                                    End If
            '                                ElseIf TblaTxtMultValenArray(FilArr, 3) = "ENTERO" Then   'VALOR
            '                                    If IsNumeric(DtRFilasActuales(Fil)(Col)) = True Then
            '                                        Dim MyNum As Double = 0
            '                                        If TextoAAgregar = "" Then
            '                                            MyNum = DtRFilasActuales(Fil)(Col)
            '                                            TextoAAgregar = MyNum.ToString("0' u';(0' u');0")
            '                                            'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
            '                                        Else
            '                                            MyNum = CDbl(TextoAAgregar)
            '                                            TextoAAgregar = MyNum.ToString("0' u';(0' u');0")
            '                                        End If
            '                                        'Todos los valores numéricos se alinean a la derecha
            '                                        Celda.HorizontalAlign = HorizontalAlign.Right
            '                                    Else
            '                                        'No hace nada ya que no se puede convertir el dato
            '                                    End If
            '                                Else
            '                                    'No hace nada
            '                                End If
            '                            End If
            '                        Else
            '                            'No hace nada, ya que puede ser que en otra fila de array este especificado
            '                        End If
            '                    Else
            '                        'No hace nada, ya que puede ser que en otra fila de array este especificado
            '                    End If
            '                Next
            '                'Cuando termina el array, se deben ver los parámetros especificados, si no hay nada se ponen por defecto, TipoDato Texto, Formato, Fondo Celda, etc
            '                'Luego que recorrió por la tabla de especificaciones, agrega la Celda a la Tabla

            '                'Debe verificar el tipo de Control que se debe agregar, si no se agrega el texto comun
            '                'If DtRFilasActuales(Fil)(Col).ToString = "" Or DtRFilasActuales(Fil)(Col).ToString = "0" Then
            '                '    'NO PONE NADA YA QUE NO TIENE VALOR
            '                'Else
            '                '    If TextoAAgregar <> "" Then 'Si la variable con el dato con formato no tiene valor, pone el dato del DataTable
            '                '        If TextoAAgregar = "0" Then
            '                '            'Si el valor es igual a cero no pone nada
            '                '        Else
            '                '            If TipoControl = "LinkButton" Then
            '                '                LinkButt.Text = TextoAAgregar
            '                '                Celda.Controls.Add(LinkButt)
            '                '            Else
            '                '                Celda.Controls.Add(New LiteralControl(TextoAAgregar))
            '                '            End If
            '                '        End If
            '                '    Else
            '                '        If TipoControl = "LinkButton" Then
            '                '            LinkButt.Text = TextoAAgregar
            '                '            Celda.Controls.Add(LinkButt)
            '                '        Else
            '                '            Celda.Controls.Add(New LiteralControl(DtRFilasActuales(Fil)(Col).ToString))
            '                '        End If
            '                '    End If
            '                'End If
            '            Else
            '                'NO HACE NADA
            '            End If
            '            'Response.Write("<TD><a href=detalle_rg.asp?Fecha="&Var_Fecha&"?Central="&oRS.Fields(I).name&"><div align=center><font size=2><font color=#0000A0>"&trim(oRS.Fields(I))&"</font></font></b></div></a></TD>")
            '            'r.Cells.Add(Celda)
            '        End If
            '    Next Col

            '    Tbl.Rows.Add(r)
            '    'If Fil > 10 Then Exit For
            'Next Fil
        '######################################################################################################################
        '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        'Agrega la Tabla al Panel
        Panel1.Controls.Add(Tbl)
        '######################################################################################################################

        'Agrega el radiobuttom para la busqueda si corresponde
        If VarTblOpcBusqDatosUbic = "Debajo Tabla" Then
            'Verifica si hay radio buttom
            If (RadioButtonOpcion IsNot Nothing AndAlso RadioButtonOpcion.Count > 0) Then

                Panel1.Controls.Add(New LiteralControl("<BR>"))
                'Titulo del RadioButtom
                Panel1.Controls.Add(TitRadioButton)

                'Los RadioButtom, se agrega un buttom por cada opción
                Dim RdioButOpParVal() As String
                Dim RBO As Integer
                For RBO = 0 To RadioButtonOpcion.GetUpperBound(0)
                    '†				            -- Separa cada opción del Radio Button
                    'ID:NombreId			    -- Es el nombre individual del control
                    '¶GroupName:Opb01		    -- Es el nombre que agrupa los distintos Checked
                    '¶Text:ValordelCompo		-- Es el valor que figura en el combo
                    '¶Checked:True o False		-- Determina si esta chequeado por defecto
                    '¶CssClass:ValorEspec		-- Contiene el formato del combo
                    '¶AutoPostBack:True o False	-- Si cuando se hace click recarga la pagina

                    'ID:CLITIPO†Text:Cliente Tipo†Checked:True;‡ID:FACNUM†Text:Factura' AS '<br>Opb01'
                    Dim RdioB As New RadioButton        'Especifica el nuevo objeto RadioButton
                    Dim RBPV As Integer                 'Variable para hacer bucle en el RB Parametros : Valor
                    Dim ParValor() As String
                    RdioButOpParVal = RadioButtonOpcion(RBO).Split("§")          'Separa los distintos parámetros del RB
                    For RBPV = 0 To RdioButOpParVal.GetUpperBound(0)
                        ParValor = RdioButOpParVal(RBPV).Split("¶")
                        Select Case ParValor(0)
                            Case "ID"
                                RdioB.ID = ParValor(1)
                            Case "Text"
                                RdioB.Text = ParValor(1)
                            Case "Checked"
                                If ParValor(1) = "True" Then
                                    RdioB.Checked = True
                                End If
                            Case "GroupName"
                                RdioB.GroupName = ParValor(1)
                        End Select
                    Next RBPV
                    Panel1.Controls.Add(RdioB)      'Agrega el RadioButton
                    'RdioB.Attributes.Add("Par1", "Esto es una Prueba")
                    'Si en los parámetros de la consulta SQL no trae el GroupName, agrega el GroupName como nombre del campo
                    'If RdioB.GroupName = "" Then
                    '    RdioB.GroupName = NomCol        'Nombre al Grupo de Controles
                    'End If

                    'Pone a cero las variables ya utilizadas
                    'RdioB.ID = ""
                    'RdioB.Text = ""
                    'RdioB.GroupName = ""
                    'RdioB.Checked = False
                Next RBO
                'Panel1.Controls.Add(New LiteralControl("<BR>"))
            Else
                'No hay datos del radiobuttom, no carga nada
            End If
        End If

        Panel1.Controls.Add(New LiteralControl("<BR>"))

        'Si llega a esta instancia es que realizo la TABLA OK, lo informa
        HaceTbla = "TblaOK"
        Return HaceTbla

        'Procesa las celdas de la tabla, ya sea para los títulos como para los datos
    End Function

    Friend Function FuncCalcTotaTabla(ByVal DtRFilasActuales() As DataRow, ByVal TotFil As Integer, ByVal TotCol As Integer, Optional ByVal VarTblRangDatCalc As String = "") As String
        '--------------------------------------------------------------------------------------------------------------------------------------------------
        'Calcula Totales de las columnas de los rangos de datos
        '1.- Primero releva los calculos que hay que realizar y a que rango hay que hacecelos
        Dim VDC As Integer = 0
        Dim VDCTot As Integer = 0
        Dim VDCMatriz(,) As String
        Dim MatrizTotales(,,) As String
        Dim CantReg As Integer = 0

        If VarTblRangDatCalc <> "" Then
            'Primero - Separa la cantidad de operaciones
            Dim VarDatCalc() As String
            VarDatCalc = VarTblRangDatCalc.Split("‡")                   'Primero determina la cantidad de calculos hay que realizar
            ReDim VDCMatriz(VarDatCalc.Length * 5, 4)                   'En función a la cantidad de calculos, define la matriz
            'Para la cantidad de filas, multiplica la cantidad de operaciones por 5 valor arbitrario,
            'Para la cantidad de columnas, son Fila Desde, Fila Hasta, Columna Desde, Columna Hasta, Operación.                                                
            Dim NumRegis As Integer : NumRegis = 0

            For VDC = 0 To VarDatCalc.Length - 1                                'Recorre por la cantidad de operaciones a realizar
                'Segundo - Separa el rango de las operaciones, siempre el primer parámetro son los RANGOS y el segundo LAS OPERACIONES
                Dim VarDatRangyOper() As String                                     'Separa el rango a aplicar y el calculo a realizar
                VarDatRangyOper = VarDatCalc(VDC).ToString.Split("†")               'Separa los Rangos de las Operaciones, siempre son 2 valores.

                'Ahora debemos analizar si el rango y/o las operaciones son multivaluadas

                'Ahora debe realizar un Split para separar los distintas operaciones
                Dim VarDatRang() As String                          'Variable para tomar los rangos disponibles
                Dim VarDatRangCant As Integer                       'Cantidad de rangos a aplicar
                Dim VarDatOper() As String                          'Variable para tomar las operaciones a realizar
                Dim VarDatOperCant As Integer                       'Cantidad de operaciones a realizar
                'La primer variable de VarDatCalc(0) siempre son los rangos
                VarDatRang = VarDatRangyOper(0).ToString.Split("§")      'Separa la cantidad de rangos que hay que aplicar

                For VarDatRangCant = 0 To VarDatRang.Length - 1             'Recorre por la cantidad de Rangos
                    'Extraemos el rango
                    'Segundo separa las filas de las columnas
                    Dim ValFildeCol() As String                         'Separa las Filas de las Columnas
                    Dim ValFilas As String = ""                         'Valores de las Filas
                    Dim ValColumnas As String = ""                      'Valores de las columnas
                    Dim ValFilDesdHasta() As String                     'Separa la fila desde y hasta
                    Dim ValColDesdHasta() As String                     'Separa la col desde y hasta

                    'Toma el valor de las filas y columnas
                    ValFildeCol = VarDatRang(VarDatRangCant).ToString.Split(";")
                    ValFilas = ValFildeCol(0)       'Siempre el primer parámetro son las Filas
                    ValColumnas = ValFildeCol(1)    'Siempre el segundo parámetro son las Columnas

                    ValFilDesdHasta = ValFilas.Split(":")       'Las filas tienen 2 valores, desde y hasta
                    ValColDesdHasta = ValColumnas.Split(":")    'Las columnas tienen 2 valores, desde y hasta

                    'Una vez definido analizamos las operaciones que hay que aplicar
                    'Ahora debemos recorrer por la cantidad de operaciones
                    VarDatOper = VarDatRangyOper(1).ToString.Split("§")              'Separa la cantidad de Operaciones que hay que realizar
                    For VarDatOperCant = 0 To VarDatOper.Length - 1             'Recorre por la cantidad de operaciones
                        'Aquí si para un rango hay más de una operación, repite el rango y cambia la operación
                        NumRegis = NumRegis + VarDatOperCant                    'Le agrega un nuevo registro al contador, si tiene mas de un valor lo suma

                        'Aqui ya tiene separado los cuatro valores, ya tenemos el rango a aplicar
                        VDCMatriz(NumRegis, 0) = ValFilDesdHasta(0).ToString                 'Fila Desde
                        VDCMatriz(NumRegis, 1) = ValFilDesdHasta(1).ToString                 'Fila Hasta
                        VDCMatriz(NumRegis, 2) = ValColDesdHasta(0).ToString                 'Columna Desde
                        VDCMatriz(NumRegis, 3) = ValColDesdHasta(1).ToString                 'Columna Hasta
                        VDCMatriz(NumRegis, 4) = VarDatOper(VarDatOperCant).ToString         'Operacion a Realizar
                    Next VarDatOperCant

                    NumRegis = NumRegis + 1                                             'Le agrega un nuevo registro al contador
                Next VarDatRangCant

            Next VDC

            VDCTot = NumRegis - 1

            'Estos son las variables para poner la infomación de la matriz de calculo
            Dim FD As Integer = 0
            Dim FH As Integer = 0
            Dim CD As Integer = 0
            Dim CH As Integer = 0
            Dim Cal As String = ""
            'Matríz de 3 dimensiones, ya que puede acumular de 13 operaciones distintas con los valores de 0 a 12
            ReDim MatrizTotales(VDCTot, TotCol, 12)     'Esta matriz totaliza los valores para cada columna
            '1er dimension = Número de Fila, 2da dimension = Columna a aplicar, 3er dimensión = Operacion a realizar

            'Por cada tipo de Función, pasa por todos los datos y hace el cálculo
            For VDC = 0 To VDCTot
                Dim CantRegParaProm As Integer : CantRegParaProm = 0
                Dim CantRegParaPromNum As Integer : CantRegParaPromNum = 0
                FD = VDCMatriz(VDC, 0)          'Fila Desde
                FH = VDCMatriz(VDC, 1)          'Fila Hasta
                CD = VDCMatriz(VDC, 2)          'Columna Desde
                CH = VDCMatriz(VDC, 3)          'Columna Hasta
                'Debe realizar el calculo para todas las celdas
                For Fil = 0 To TotFil           'Primera fila, comienza en 1 ya que no agrega el Título
                    For Col = 0 To TotCol       'De la fila va por cada columna
                        If (Fil >= FD Or FD = -1) And (Fil <= FH Or FH = -1) And (Col >= CD Or CD = -1) And (Col <= CH Or CH = -1) Then
                            'Quiere decir que el valor de la fila y columna esta sujeto al calculo
                            'La matríz tiene 3 dimensiones, la primera es el número de item, la segunda la columna, 
                            'la tercera es la operación de la columna 
                            'Los valores de la tercera pueden ser: 
                            '       0 = Cantidad de Filas totales
                            '       1 = Suma de todas la Filas
                            '       2 = Cantidad de filas numéricas
                            '       3 = Valor máximo
                            '       4 = Valor mínimo
                            '       5 = PromedioNum
                            '       6 = Promedio

                            'Cuenta la Cantidad de registros que hay, sean o no de número
                            If VDCMatriz(VDC, 4) = "CANTIDAD" Then
                                MatrizTotales(VDC, Col, 0) = Val(MatrizTotales(VDC, Col, 0)) + 1
                            ElseIf VDCMatriz(VDC, 4) = "PROMEDIO" Then
                                CantRegParaProm = CantRegParaProm + 1
                            End If
                            'Verifica si son numero, realiza los calculos
                            If IsNumeric(DtRFilasActuales(Fil)(Col).ToString) = True Then
                                If VDCMatriz(VDC, 4) = "SUMA" Then
                                    'Suma los totales
                                    MatrizTotales(VDC, Col, 1) = Val(MatrizTotales(VDC, Col, 1)) + Val(DtRFilasActuales(Fil)(Col).ToString)
                                ElseIf VDCMatriz(VDC, 4) = "CUENTANUMERO" Then
                                    'Cuenta solo los valores numéricos
                                    MatrizTotales(VDC, Col, 2) = Val(MatrizTotales(VDC, Col, 2)) + 1
                                ElseIf VDCMatriz(VDC, 4) = "MAXIMO" Then
                                    'Obtiene el valor máximo
                                    If Val(DtRFilasActuales(Fil)(Col).ToString) > MatrizTotales(VDC, Col, 3) Then
                                        MatrizTotales(VDC, Col, 3) = Val(DtRFilasActuales(Fil)(Col).ToString)
                                    End If
                                ElseIf VDCMatriz(VDC, 4) = "MINIMO" Then
                                    'Obtiene el valor mínimo
                                    If Val(DtRFilasActuales(Fil)(Col).ToString) < MatrizTotales(VDC, Col, 4) Then
                                        MatrizTotales(VDC, Col, 4) = Val(DtRFilasActuales(Fil)(Col).ToString)
                                    End If
                                ElseIf VDCMatriz(VDC, 4) = "PROMEDIONUM" Then
                                    'Suma los totales, para el promedio
                                    MatrizTotales(VDC, Col, 1) = Val(MatrizTotales(VDC, Col, 1)) + Val(DtRFilasActuales(Fil)(Col).ToString)
                                    'Cuenta solo los valores numéricos
                                    CantRegParaPromNum = CantRegParaPromNum + 1
                                ElseIf VDCMatriz(VDC, 4) = "PROMEDIO" Then
                                    'Suma los totales, para el promedio
                                    MatrizTotales(VDC, Col, 1) = Val(MatrizTotales(VDC, Col, 1)) + Val(DtRFilasActuales(Fil)(Col).ToString)
                                    'La Cantidad de Filas se cuentan siempre
                                End If
                            End If
                        End If
                    Next Col
                Next Fil

                'Calcula el promedio de cada columna
                'ya teniendo el total y la cantidad de registros, puede calcular el promedio
                For Col = 0 To TotCol
                    'Le carga el promedio a la columna.
                    If (Col >= CD Or CD = -1) And (Col <= CH Or CH = -1) Then
                        If VDCMatriz(VDC, 4) = "PROMEDIONUM" Then
                            'Si la cantidad es mayor que cero, calcula el promedio
                            If CantRegParaPromNum > 0 Then
                                MatrizTotales(VDC, Col, 5) = Val(MatrizTotales(VDC, Col, 1)) / CantRegParaPromNum
                            End If
                        ElseIf VDCMatriz(VDC, 4) = "PROMEDIO" Then
                            'Si la cantidad es mayor que cero, calcula el promedio
                            If CantRegParaProm > 0 Then
                                MatrizTotales(VDC, Col, 6) = Val(MatrizTotales(VDC, Col, 1)) / CantRegParaProm
                            End If
                        End If
                    End If
                Next Col
            Next VDC

            'Pasa la matriz tridimensional a bidimensional, consolida valores
            Dim CalculoTotales(12, TotCol)
            Dim Dim3 As Integer = 0
            Dim CantTotAct As Integer = 0
            'Los valores de la primera dimension pueden ser: 
            '       0 = Cantidad de Filas totales
            '       1 = Suma de todas la Filas
            '       2 = Cantidad de filas numéricas
            '       3 = Valor máximo
            '       4 = Valor mínimo
            '       5 = PromedioNum
            '       6 = Promedio
            For VDC = 0 To VDCTot
                For Col = 0 To TotCol
                    For Dim3 = 0 To 12
                        'Verifica que ese valor ya no este incorporado
                        If IsNothing(MatrizTotales(VDC, Col, Dim3)) = False Then
                            If IsNothing(CalculoTotales(Dim3, Col)) = True Then
                                CalculoTotales(Dim3, Col) = MatrizTotales(VDC, Col, Dim3)
                            End If
                        End If
                    Next Dim3
                Next Col
            Next VDC

            'Verifica la cantidad de totales reales, esto lo hace para modificar la Tabla dinamica
            Dim CantTot As Integer = 0
            Dim DimenCarg As Boolean = False
            For Dim3 = 0 To 12
                For Col = 0 To TotCol
                    If IsNothing(CalculoTotales(Dim3, Col)) = False Then
                        If IsNothing(CalculoTotales(Dim3, 1)) = True Then
                            'Agrega los Títulos
                            Select Case Dim3
                                Case 0
                                    CalculoTotales(Dim3, 1) = "CANTIDAD"
                                Case 1
                                    CalculoTotales(Dim3, 1) = "TOTAL"
                                Case 2
                                    CalculoTotales(Dim3, 1) = "CANT.NUM"
                                Case 3
                                    CalculoTotales(Dim3, 1) = "MAXIMO"
                                Case 4
                                    CalculoTotales(Dim3, 1) = "MINIMO"
                                Case 5
                                    CalculoTotales(Dim3, 1) = "PROMEDIONUM"
                                Case 6
                                    CalculoTotales(Dim3, 1) = "PROMEDIO"
                                Case Else
                                    CalculoTotales(Dim3, 1) = "TOTALes"
                            End Select

                        End If

                        If DimenCarg = False Then
                            CantTot = CantTot + 1
                            DimenCarg = True
                        End If
                    End If
                Next Col
                DimenCarg = False
            Next Dim3

            ReDim TablaDinamTotal(CantTot - 1, TotCol)
            CantReg = 0
            For Dim3 = 0 To 12
                For Col = 0 To TotCol
                    If IsNothing(CalculoTotales(Dim3, Col)) = False Then
                        TablaDinamTotal(CantReg, Col) = CalculoTotales(Dim3, Col)
                        If DimenCarg = False Then
                            DimenCarg = True
                        End If
                    End If
                Next Col
                If DimenCarg = True Then
                    CantReg = CantReg + 1
                    DimenCarg = False
                End If
            Next Dim3
            CantReg = CantReg - 1

            'Especifica el Tipo de Fila, determina
            For Fil = 0 To CantReg
                TablaDinamTotal(Fil, 0) = "TOTAL"
            Next Fil
        End If
        FuncCalcTotaTabla = CantReg
    End Function

    Friend Function FuncDatoTipComp(ByVal TipoComp As String, ByVal ValorCampo As String, Optional Vinculo As String = "", Optional VarPar As String = "", Optional TDFil As Integer = 0, Optional TDCol As Integer = 0) As String
        If TipoComp = "LINKBUTTON" Then
            '1.- TipodeControl
            FuncDatoTipComp = "LINKBUTTON"   'Si no es autoajustable, le agrega un valor
            '######################################################################
            'DATO A MOSTRAR
            Dim DatBas() As String
            Dim VinCod As String = ""
            Dim VincMuestra As String = ""
            Dim VincTitulo As String = ""
            Dim ArmVinc As String = ""

            DatBas = ValorCampo.Split("†")
            'Verifica la cantidad de parámetros que tiene el vinculo.
            If DatBas.Length = 3 Then   'Tiene 3 valores, Valor que se muestra, CodVinculo, Titulo que se pasa
                VincMuestra = DatBas(0)
                VinCod = DatBas(1)
                VincTitulo = DatBas(2)
            ElseIf DatBas.Length = 2 Then   'Tiene 2 valores, Valor que se muestra = Titulo que se pasa, CodVinculo
                VincMuestra = DatBas(0)
                VincTitulo = DatBas(0)
                VinCod = DatBas(1)
            Else    'Tiene 1 valor, Valor que semuestra = CodVinculo = Titulo que se pasa
                VincMuestra = DatBas(0)
                VincTitulo = DatBas(0)
                VinCod = DatBas(0)
            End If

            'Si tiene el título en el parámetro, lo extrae y pone el valor
            Dim VBusqIni As Integer = InStr(Vinculo, "&TblTit=", CompareMethod.Text)
            Dim VBusqFin As Integer = Len(Vinculo)
            If InStr(Vinculo, "&TblTit=", CompareMethod.Text) > 0 Then
                'Toma la parte del Titulo del Vínculo y lo agrega dinámicamente
                VincTitulo = Vinculo.Substring(VBusqIni + 7, VBusqFin - VBusqIni - 7)
                VincTitulo = FuncHaceTit(VincTitulo, TDFil, TDCol)        '1.- Valor del Titulo, 2.- Fila Actual, 3.- Columna Actual

                'Deje limpio el vinculo para procesar
                Vinculo = Vinculo.Substring(0, VBusqIni - 1)
            End If

            'Hay que poner los otros parametros
            '2.- TextoAAgregar
            FuncDatoTipComp = FuncDatoTipComp & "‡" & VincMuestra

            '######################################################################
            'ARMADO DEL VINCULO
            Dim DatVinc() As String

            DatVinc = Vinculo.ToString.Split("¦")
            'Primero incorpora el vinculo de la página
            ArmVinc = Server.HtmlEncode(DatVinc(0)) & "?"

            'Segundo incorpora la tabla que tiene la consulta
            If DatVinc(1) <> "" Then
                ArmVinc = ArmVinc & "TblCod=" & Server.HtmlEncode(DatVinc(1))
            End If

            'Tercero vincula la información de los parámetros
            Dim VarParVinc As String = ""
            If DatVinc(2) = "VINCNUEVO" Then
                VarParVinc = VinCod
            Else
                VarParVinc = FuncHaceVinc(VarPar, DatVinc(2).ToString, VinCod, "", TDFil, TDCol)
            End If

            ArmVinc = ArmVinc & "&TblPars=" & Server.HtmlEncode(VarParVinc) & "&TblTit=" & Server.HtmlEncode(VincTitulo)

            '3.- Vinculo
            FuncDatoTipComp = FuncDatoTipComp & "‡" & ArmVinc
        ElseIf TipoComp = "TEXTBOX" Then
            FuncDatoTipComp = "TEXTBOX" & "‡" & ValorCampo
        ElseIf TipoComp = "RADIOBUTTON" Then
            FuncDatoTipComp = "RADIOBUTTON" & "‡" & ValorCampo
        Else
            'El vinculo no es nada ya que no tiene
            FuncDatoTipComp = "LABEL" & "‡" & ValorCampo & "‡" & Vinculo
        End If
    End Function

    Friend Function FuncVarPar(ByVal VarParAcum As String) As String
        'VINCACUM†P5:VDA
        Dim VarPar As String = ""
        Dim VarParOrd() As String
        Dim VarParNum() As String
        Dim VPCant As Integer = 0
        'Si no tiene parámetro, no hace nada
        If VarParAcum <> "" Then
            VarParOrd = VarParAcum.Split("|")
            For VPCant = 0 To VarParOrd.Length - 1
                VarParNum = VarParOrd(VPCant).Split(":")
                Select Case VarParNum(0)
                    Case "P1"
                        VarPar = VarParNum(1)
                    Case "P2"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P3"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P4"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P5"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P6"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P7"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P8"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P9"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P10"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P11"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P12"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case "P13"
                        VarPar = VarPar & "|" & VarParNum(1)
                    Case Else
                        VarPar = VarParAcum
                End Select
            Next VPCant
        End If
        FuncVarPar = VarParAcum
        'FuncVarPar = VarPar
    End Function

    Friend Function FuncHaceTit(ByVal VarTitulo As String, Optional TDFil As Integer = 0, Optional TDCol As Integer = 0) As String
        Dim VarTituloFinal As String = ""              'Es el título armado
        Dim VarTitPar() As String                      'Variable para tomar los parámetros que se deben cambiar

        'Primer parámetro es el titulo fijo
        VarTitPar = VarTitulo.Split("¦")         'Separa el valor fijo del titulo y los datos para obtener el valor variable de la tabla
        VarTituloFinal = VarTitPar(0)

        'Segundo parámetro son los datos variables que se extraen de la tabla
        Dim VarTituloVariable As String = ""     'Acumula el titulo variable
        Dim VarTitParam() As String              'Variable para separa los parámetros:Valor
        Dim VAPCant As Integer = 0               'Cantidad de parámetros adicionales
        Dim VarTitParNum() As String             'Contiene los valores de cada uno de los parámetros
        'P1:FC:0:CA;P2:FC:0:CA

        VarTitParam = VarTitPar(1).Split(";")                   'Separa cada parámetro en Parametro:Valor
        For VAPCant = 0 To VarTitParam.Length - 1               'Recorre los parámetros adicionales
            VarTitParNum = VarTitParam(VAPCant).Split(":")      'Separa cada parámetro en Parametro:Valor
            If VarTitParNum(1) = "FC" Then
                'Si es ID, quiere decir que el vinculo se hace de los valores que hay en la tabla
                'por lo tanto, hay que buscar según la referencia. Los datos se buscan por la combinación de Fila y Columna
                'un parámetro puede tener solo un valor que surja de información de varias columnas y filas, como valores fijos, pero es solo un valor.
                'El resultado debe ser P1:VALOR;P2:VALOR;P3:VALOR, ETC.
                Dim ValVinArm As String = ""
                Dim Fil As Integer = 0
                If VarTitParNum(2) = "FA" Then
                    Fil = TDFil
                Else
                    Fil = VarTitParNum(2)
                End If
                Dim Col As Integer = 0
                If VarTitParNum(3) = "CA" Then
                    Col = TDCol
                Else
                    Col = VarTitParNum(3)
                End If
                ValVinArm = TablaDinam(Fil, Col)          'Aquí toma el valor del campo, puede tener modificaciones de formato.
                If VarTituloVariable = "" Then
                    VarTituloVariable = ValVinArm
                Else
                    VarTituloVariable = VarTituloVariable & " " & ValVinArm
                End If
            End If
        Next VAPCant

        'Forma el título final
        If VarTituloFinal = "" Then     'Si el valor fijo del titulo no tiene valor
            If VarTituloVariable = "" Then  'Si el valor variable del titulo no tiene valor
                VarTituloFinal = ""             'El tituto no tiene valor, variable vacia
            Else
                VarTituloFinal = VarTituloVariable      'Solo tiene valor variable
            End If
        Else
            'El valor fijo del título tiene valor
            If VarTituloVariable = "" Then      'Si el valor variable del titulo no tiene valor
                VarTituloFinal = VarTituloFinal     'Como no tiene valor variable, solo el titulo es valor final
            Else
                VarTituloFinal = VarTituloFinal & " " & VarTituloVariable       'Tienen valor fijo y variable
            End If
        End If

        FuncHaceTit = VarTituloFinal
    End Function

    Friend Function FuncHaceVinc(ByVal VarParAcum As String, Optional VincAdic As String = "", Optional VincDat As String = "", Optional TbloPar As String = "Parametros", Optional TDFil As Integer = 0, Optional TDCol As Integer = 0) As String
        Dim VarPar As String = ""           'Variable para Armar el Vinculo definitivo
        Dim VarParAcumSep() As String       'Variable para tomar los parámetros del VarParAcum
        Dim VarParNum() As String           'Variable para separar los parámetro:Valor
        Dim VPCant As Integer = 0           'Cantidad de parámetros

        Dim VarParArm As String = ""        'Variable para armar el vinculo, desde los datos adic
        Dim VarParCamb As Boolean = False   'Variable que determina si el parámetro fue cambiado
        Dim VincAdicPar() As String         'Variable para tomar los parámetros que se deben cambiar
        Dim VincAdicParNum() As String      'Variable para separa los parámetros:Valor
        Dim VAPCant As Integer = 0          'Cantidad de parámetros adicionales

        '1.- Aquí hay que recorrer la variable con los parámetros acumulados, luego que ingresamos a ese parámetro
        'recorremos la variable de VincAdic para ver si ese parámetro hay que reemplazarlo y por que valor.

        If IsNothing(VarParAcum) = True Or VarParAcum = "NULL" Then
            VarParAcum = ""
        End If

        'Si tiene un parametro acumulado, lo agrega al Parametro que se realizará
        If VarParAcum <> "" Then
            '-- If VarParAcum <> "" And IsNothing(VarParAcum) = True Then, da error, cdo varparacum tiene valor
            VarParAcumSep = VarParAcum.Split("|")
            For VPCant = 0 To VarParAcumSep.Length - 1
                VarParNum = VarParAcumSep(VPCant).Split(":")    'Separa cada parámetro en Parametro:Valor

                VincAdicPar = VincAdic.Split(";")               'Separa los datos del Viculo Nuevo
                VarParCamb = False
                For VAPCant = 0 To VincAdicPar.Length - 1               'Recorre los parámetros adicionales
                    VincAdicParNum = VincAdicPar(VAPCant).Split(":")    'Separa cada parámetro en Parametro:Valor
                    If VarParNum(0) = VincAdicParNum(0) Then
                        If VincAdicParNum(1) = "DA" Then
                            VarParArm = VarParNum(0) & ":" & VincDat
                        ElseIf VincAdicParNum(1) = "FC" Then
                            'Si es ID, quiere decir que el vinculo se hace de los valores que hay en la tabla
                            'por lo tanto, hay que buscar según la referencia. Los datos se buscan por la combinación de Fila y Columna
                            'un parámetro puede tener solo un valor que surja de información de varias columnas y filas, como valores fijos, pero es solo un valor.
                            'El resultado debe ser P1:VALOR;P2:VALOR;P3:VALOR, ETC.
                            Dim ValVinArm As String = ""
                            Dim Fil As Integer = 0
                            If VincAdicParNum(2) = "FA" Then
                                Fil = TDFil
                            Else
                                Fil = VincAdicParNum(2)
                            End If
                            Dim Col As Integer = 0
                            If VincAdicParNum(3) = "CA" Then
                                Col = TDCol
                            Else
                                Col = VincAdicParNum(3)
                            End If
                            ValVinArm = TablaDinam(Fil, Col)          'Aquí toma el valor del campo, puede tener modificaciones de formato.
                            VarParArm = VarParNum(0) & ":" & ValVinArm
                        ElseIf VincAdicParNum(1) = "EL" Then
                            ' SALTEA EL PARÁMETRO, NO LO INCORPORA VarParArm = VarParNum(0) & ":" & VincDat
                        Else
                            VarParArm = VarParNum(0) & ":" & VincAdicParNum(1)
                        End If
                        VarParCamb = True
                        Exit For
                    End If
                Next VAPCant

                If VarParCamb = False Then      'Si el parámetro no es cambiado, deja el parámetro que tenía
                    VarParArm = VarParNum(0) & ":" & VarParNum(1)
                End If
                If VarParArm <> "" Then
                    If VarPar = "" Then
                        VarPar = VarParArm
                    Else
                        VarPar = VarPar & "|" & VarParArm
                    End If
                    VarParArm = ""
                End If
            Next VPCant
            'El resultado de esta función es dar el valor del parámetro que se incorpora VarPar
        End If

        '2.- Ahora hay que verificar si hay que agregar algún nuevo parámetro
        'para ello debemos recorrer la matriz de parámetros a Adicionar, y si es un parámetro nuevo se lo agrega al final
        'solo se verifica TbloPar
        Dim VarParIncorp As Boolean = False         'Determina si el parámetro fue agregado
        Dim VincAdicParN() As String                'Variable para tomar los parámetros que se deben cambiar
        Dim VincAdicParNumero() As String              'Variable para separa los parámetros:Valor
        Dim VarParN() As String           'Variable para separar los parámetro:Valor
        If VincAdic <> "" Then
            VincAdicParN = VincAdic.Split(";")

            'Por cada valor de la variable, debe verificar si lo tiene o debe agregar alguno más
            For VAPCant = 0 To VincAdicParN.Length - 1               'Recorre los parámetros adicionales
                VincAdicParNumero = VincAdicParN(VAPCant).Split(":")    'Separa cada parámetro en Parametro:Valor

                'Ahorra recorremos el VarParIncorp que fue generado anteriormente
                VarParIncorp = True
                VarParAcumSep = VarParAcum.Split("|")
                For VPCant = 0 To VarParAcumSep.Length - 1
                    VarParN = VarParAcumSep(VPCant).Split(":")    'Separa cada parámetro en Parametro:Valor
                    If VarParN(0) = VincAdicParNumero(0) Then        'Si lo encuentra, pone la variable a False y sale del For Next
                        'Para incorporar parámetros debe estar en la variable parámetros y debe ser el valor mayor a cero
                        'ya que el parámetro 0 es el código de la tabla que se abre.
                        VarParIncorp = False     'Si VarParIncorp = False quiere decir que el valor ya está, por ende no lo incorpora
                        Exit For
                    End If
                Next VPCant

                'Si no lo encuentra, quiere decir que lo debe incorporar, pero antes debe
                ' verifica si hay que incorporar el parámetro según sea la variable = Tbl o Parámetros
                If TbloPar = "Parametros" And VincAdicParNumero(0) = "P0" Then
                    'Si la variable es parámetros y el parámetro es P0, NO lo incorpora.
                    VarParIncorp = False
                ElseIf TbloPar = "Tbl" And VincAdicParNumero(0) <> "P0" Then
                    'Si la variable es Tbl y el valor <> a P0, y no lo encontro lo incorpora. 
                    'TbloPar solo puede tener un valor P0
                    VarParIncorp = False
                Else
                    'Si no tiene valor no hace nada
                End If

                'Si el parámetro se debe agregar, ingresa en la función
                If VarParIncorp = True Then
                    If VincAdicParNumero(1) = "DA" Then
                        If VarPar = "" Then
                            VarPar = VincAdicParNumero(0) & ":" & VincDat
                        Else
                            VarPar = VarPar & "|" & VincAdicParNumero(0) & ":" & VincDat
                        End If
                    ElseIf VincAdicParNumero(1) = "FC" Then
                        'Si es ID, quiere decir que el vinculo se hace de los valores que hay en la tabla
                        'por lo tanto, hay que buscar según la referencia. Los datos se buscan por la combinación de Fila y Columna
                        'un parámetro puede tener solo un valor que surja de información de varias columnas y filas, como valores fijos, pero es solo un valor.
                        'El resultado debe ser P1:VALOR;P2:VALOR;P3:VALOR, ETC.
                        Dim ValVinArm2 As String = ""
                        Dim Fil2 As Integer = 0
                        If VincAdicParNumero(2) = "FA" Then
                            Fil2 = TDFil
                        Else
                            Fil2 = VincAdicParNumero(2)
                        End If
                        Dim Col2 As Integer = 0
                        If VincAdicParNumero(3) = "CA" Then
                            Col2 = TDCol
                        Else
                            Col2 = VincAdicParNumero(3)
                        End If
                        ValVinArm2 = TablaDinam(Fil2, Col2)          'Aquí toma el valor del campo, puede tener modificaciones de formato.
                        If VarPar = "" Then
                            VarPar = VincAdicParNumero(0) & ":" & ValVinArm2
                        Else
                            VarPar = VarPar & "|" & VincAdicParNumero(0) & ":" & ValVinArm2
                        End If
                    ElseIf VincAdicParNumero(1) = "EL" Then
                        'NO INCORPORA NADA, YA QUE IMPLICA ELIMINARSE
                    Else
                        If VarPar = "" Then
                            VarPar = VincAdicParNumero(0) & ":" & VincAdicParNumero(1)
                        Else
                            VarPar = VarPar & "|" & VincAdicParNumero(0) & ":" & VincAdicParNumero(1)
                        End If

                    End If
                    VarParIncorp = False
                End If

            Next VAPCant
        End If

        '3.- Ahora hay que ordenar los parámetros.

        VarParArm = VarPar

        FuncHaceVinc = VarParArm
    End Function

    Friend Function FuncModifVinc(ByVal VarParAcum As String, Optional VincAdic As String = "", Optional VincDat As String = "") As String
        Dim VarPar As String = ""           'Variable para Armar el Vinculo definitivo
        Dim VarParAcumSep() As String       'Variable para tomar los parámetros del VarParAcum
        Dim VarParNum() As String           'Variable para separar los parámetro:Valor
        Dim VPCant As Integer = 0           'Cantidad de parámetros

        Dim VarParArm As String = ""        'Variable para armar el vinculo, desde los datos adic
        Dim VarParCamb As Boolean = False   'Variable que determina si el parámetro fue cambiado
        Dim VincAdicPar() As String         'Variable para tomar los parámetros que se deben cambiar
        Dim VincAdicParNum() As String      'Variable para separa los parámetros:Valor
        Dim VAPCant As Integer = 0          'Cantidad de parámetros adicionales
        Dim VarParIncorp As Boolean = False        'Determina si el parámetro fue agregado

        '1.- Aquí hay que recorrer la variable con los parámetros acumulados, luego que ingresamos a ese parámetro
        'recorremos la variable de VincAdic para ver si ese parámetro hay que reemplazarlo y por que valor.

        If VarParAcum <> "" Then
            VarParAcumSep = VarParAcum.Split("|")
            For VPCant = 0 To VarParAcumSep.Length - 1
                VarParNum = VarParAcumSep(VPCant).Split(":")    'Separa cada parámetro en Parametro:Valor

                VincAdicPar = VincAdic.Split(";")               'Separa los datos del Viculo Nuevo
                VarParCamb = False
                For VAPCant = 0 To VincAdicPar.Length - 1               'Recorre los parámetros adicionales
                    VincAdicParNum = VincAdicPar(VAPCant).Split(":")    'Separa cada parámetro en Parametro:Valor
                    If VarParNum(0) = VincAdicParNum(0) Then
                        If VincAdicParNum(1) = "DA" Then
                            VarParArm = VarParNum(0) & ":" & VincDat
                        ElseIf VincAdicParNum(1) = "EL" Then
                            ' SALTEA EL PARÁMETRO, NO LO INCORPORA VarParArm = VarParNum(0) & ":" & VincDat
                        Else
                            VarParArm = VarParNum(0) & ":" & VincAdicParNum(1)
                        End If
                        VarParCamb = True
                        Exit For
                    End If
                Next VAPCant

                If VarParCamb = False Then      'Si el parámetro no es cambiado, deja el parámetro que tenía
                    VarParArm = VarParNum(0) & ":" & VarParNum(1)
                End If
                If VarParArm <> "" Then


                    If VarPar = "" Then
                        VarPar = VarParArm
                    Else
                        VarPar = VarPar & "|" & VarParArm
                    End If
                    VarParArm = ""
                End If
            Next VPCant
        End If

        '2.- Ahora hay que verificar si hay que agregar algún nuevo parámetro
        'para ello debemos recorrer la matriz de parámetros a Adicionar, y si es un parámetro nuevo se lo agrega al final
        If VincAdic <> "" Then
            VincAdicPar = VincAdic.Split(";")

            For VAPCant = 0 To VincAdicPar.Length - 1               'Recorre los parámetros adicionales
                VincAdicParNum = VincAdicPar(VAPCant).Split(":")    'Separa cada parámetro en Parametro:Valor
                'Ahorra recorremos el VarPar que fue generado anteriormente
                VarParIncorp = False
                VarParAcumSep = VarParAcum.Split("|")
                For VPCant = 0 To VarParAcumSep.Length - 1
                    VarParNum = VarParAcumSep(VPCant).Split(":")    'Separa cada parámetro en Parametro:Valor
                    If VarParNum(0) = VincAdicParNum(0) Then
                        VarParIncorp = True
                        Exit For
                    End If
                Next VPCant
                If VarParIncorp = False Then
                    If VincAdicParNum(1) = "DA" Then
                        If VarPar = "" Then
                            VarPar = VincAdicParNum(0) & ":" & VincDat
                        Else
                            VarPar = VarPar & "|" & VincAdicParNum(0) & ":" & VincDat
                        End If
                    ElseIf VincAdicParNum(1) = "EL" Then
                        'NO INCORPORA NADA, YA QUE IMPLICA ELIMINARSE
                    Else
                        If VarPar = "" Then
                            VarPar = VincAdicParNum(0) & ":" & VincAdicParNum(1)
                        Else
                            VarPar = VarPar & "|" & VincAdicParNum(0) & ":" & VincAdicParNum(1)
                        End If

                    End If

                    VarParCamb = True
                End If

            Next VAPCant
        End If

        VarParArm = VarPar

        FuncModifVinc = VarParArm
    End Function

    'Friend Function FuncVarParVinc(ByVal VarParDat As String, ByVal VarParVincOrig As String, ByVal VarVincAdic As String, ByVal VarVincDat As String) As String
    '    'Aquí hay que recorrer la variable con los parámetros acumulados, luego que ingresamos a ese parámetro
    '    ', recorremos la variable de VincAdic para ver si ese parámetro hay que reemplazarlo y por que valor.
    '    Dim VarPar As String = ""
    '    Dim VarParCamb As Boolean = False   'Variable que determina si el parámetro fue cambiado
    '    Dim VincAdicPar() As String         'Variable para tomar los parámetros que se deben cambiar
    '    Dim VincAdicParNum() As String      'Variable para separa los parámetros:Valor
    '    Dim VAPCant As Integer = 0          'Cantidad de parámetros adicionales
    '    VincAdicPar = VarVincAdic.Split(";")

    '    VarParCamb = False
    '    For VAPCant = 0 To VincAdicPar.Length - 1               'Recorre los parámetros adicionales
    '        VincAdicParNum = VincAdicPar(VAPCant).Split(":")    'Separa cada parámetro en Parametro:Valor
    '        If VarParDat = VincAdicParNum(0) Then
    '            If VincAdicParNum(1) = "DA" Then
    '                VarPar = VarParDat & ":" & VarVincDat
    '            Else
    '                VarPar = VarParDat & ":" & VincAdicParNum(1)
    '            End If
    '            VarParCamb = True
    '        End If
    '    Next VAPCant

    '    If VarParCamb = False Then      'Si el parámetro no es cambiado, deja el parámetro que tenía
    '        VarPar = VarParDat & ":" & VarParVincOrig
    '    End If
    '    FuncVarParVinc = VarPar
    'End Function

    Friend Function FuncFtoColAncho(ByVal ValPar1 As String) As String
        If ValPar1 <> "AUTOAJUSTABLE" Then
            FuncFtoColAncho = ValPar1   'Si no es autoajustable, le agrega un valor
        Else
            FuncFtoColAncho = "AUTOAJUSTABLE"
        End If
    End Function

    Friend Function FuncFtoColOrden(ByVal ValPar1 As String) As String
        If ValPar1 = "ORDENABLE" Then
            FuncFtoColOrden = "sortable"   'Si no es autoajustable, le agrega un valor
        ElseIf ValPar1 = "NOORDENABLE" Then
            FuncFtoColOrden = "unsortable"   'Si no es autoajustable, le agrega un valor
        Else
            FuncFtoColOrden = ""
        End If
    End Function

    Friend Function FuncFtoCsStyle(ByVal ValPar1 As String) As String
        FuncFtoCsStyle = ValPar1

    End Function

    Friend Function FuncFtoColAlin(ByVal ValPar1 As String) As String
        If ValPar1 = "IZQUIERDA" Then
            FuncFtoColAlin = HorizontalAlign.Left
        ElseIf ValPar1 = "CENTRO" Then
            FuncFtoColAlin = HorizontalAlign.Center
        ElseIf ValPar1 = "JUSTIFICADA" Then
            FuncFtoColAlin = HorizontalAlign.Justify
        ElseIf ValPar1 = "DERECHA" Then
            FuncFtoColAlin = HorizontalAlign.Right
        Else
            FuncFtoColAlin = ""
        End If
    End Function

    Friend Function FuncTblFtoUsu(ByVal Fil As Integer, ByVal Col As Integer) As Integer
        'Variables para tomar el rango del formato
        Dim FD As Integer = 0
        Dim FH As Integer = 0
        Dim CD As Integer = 0
        Dim CH As Integer = 0
        Dim FtoNivel As Integer = 0
        Dim FilF As Integer = 0

        'Variables para tomar el contenido del formato
        Dim InForm() As String
        Dim InForVal() As String
        Dim CantInForm As Integer = 0
        Dim FtoNivelUltApli As Integer = 0
        Dim FtoTipo As String = ""
        Dim FtoParametro As String = ""
        Dim FtoParValor As String = ""
        Dim FtoParValorAdic As String = ""
        Dim FtoParRegla As String = ""
        'Constantes
        Dim FilVisNivel As Integer = 1

        Dim FAN As Integer = 0
        Dim FANCant As Integer = 0
        Dim FtoAplicarUsado As Boolean = False

        ReDim FtoAplicar(50, 5)              'Matriz con los datos de los parámetros, sus valores y su nivel.

        'Busca el formato de cada campo
        For FilF = 1 To TblaRangoFtoArrFilTot       'Comienza en 1, ya que la fila 0 son los títulos
            'Ya tengo el rango del formato, ahora debo compararlo con el rango que se esta incorporando
            FD = TblaRangoFormatoArray(FilF, 2)
            FH = TblaRangoFormatoArray(FilF, 3)
            CD = TblaRangoFormatoArray(FilF, 4)
            CH = TblaRangoFormatoArray(FilF, 5)
            FtoNivel = TblaRangoFormatoArray(FilF, 6)

            'Para los títulos la Fil = 0 siempre
            Dim RtaComp1 As String = "NO" : Dim RtaComp2 As String = "NO" : Dim RtaComp3 As String = "NO" : Dim RtaComp4 As String = "NO"
            If (Fil >= FD Or FD = -1) Then RtaComp1 = "OK"
            If (Fil <= FH Or FH = -1) Then RtaComp2 = "OK"
            If (Col >= CD Or CD = -1) Then RtaComp3 = "OK"
            If (Col <= CH Or CH = -1) Then RtaComp4 = "OK"

            '-2 = Para inhabilitar las filas o columnas, si se especifica solo una fila (no se pone valor a las columnas por eso va -2) y viceversa
            '-1 = Nivel de Título y nombre de las columnas
            If (Fil >= FD Or FD = -1) And (Fil <= FH Or FH = -1) And (Col >= CD Or CD = -1) And (Col <= CH Or CH = -1) Then
                'Si ingresa aquí, quiere decir que la celda tiene una especificación de formato.
                'Ahora debemos buscar el tipo de formato que hay que incorporarle.
                'Este puede ser a su vez multivaluado, o sea, para una celda puede haber varias especificaciones.
                'Lo optimo es elegir un estilo CssStyle, y que este este predefinido.
                InForm = TblaRangoFormatoArray(FilF, 1).ToString.Split("§")

                'Aquí puedo hacer una función, pasando la InForm, y que devuelva, 
                'Propiedades, Valores, con un select case, según puede tener cada celda.
                'Aquí traducimos la elección del usuario, en valores que .net entienda.

                'Luego de esta función, debería recorrer el bucle, incorporandolos en la tabla
                'Aquí aplicamos estos valores para que el .net los muestre en html.

                'FAN = 0
                'FANCant = 0
                FtoAplicarUsado = False

                For CantInForm = 0 To InForm.Length - 1
                    InForVal = InForm(CantInForm).ToString.Split("¶")

                    'Aquí se le da formato al TblHedCel, que es la celda específica cada columna.
                    FtoTipo = InForVal(0).ToString          '0.- Tipo de Parámetro
                    FtoParametro = InForVal(1).ToString     '1.- Parámetro
                    FtoParValor = InForVal(2).ToString      '2.- Valor Parametro
                    FtoParValorAdic = InForVal(3).ToString      '3.- Datos adicionales Parametro
                    FtoParRegla = InForVal(4).ToString      '4.- Regla condicional que se aplica
                    FtoNivel = FtoNivel                     'Este parámetro viene del Rango

                    'Ya tenemos el formato que se le debe agregar, según el Parámetro / Valor.
                    'Aquí hay que ver el tipo de nivel del formato, puede ser 1- Hoja, 2- Fila o Columna, 3- Celda. Lo que prevalece es nivel Celda.

                    For FAN = 0 To FANCant
                        'Si el tipo de parámetro, el Parámetro es igual al valor incorporado, y el nivel es superior, ingresa y cambia el valor.
                        If FtoAplicar(FAN, 0) = FtoTipo And FtoAplicar(FAN, 1) = FtoParametro Then
                            If FtoNivel >= FilVisNivel Then
                                'Si tiene un nivel superior, agrega el formato
                                FtoAplicar(FAN, 0) = FtoTipo                     'Es el tipo de formato
                                FtoAplicar(FAN, 1) = FtoParametro                'Es el parámetro
                                FtoAplicar(FAN, 2) = FtoParValor                 'Es el valor del parámetro.
                                FtoAplicar(FAN, 3) = FtoParValorAdic             'Es el valor del parámetro adicional.
                                FtoAplicar(FAN, 4) = FtoParRegla                 'Es la regla condicional a aplicar
                                'Como se inhabilita el siguiente nivel, si o si la matríz debe estar ordenada,  1- Hoja, 2- Fila o Columna, 3- Celda.
                                FtoAplicar(FAN, 5) = FtoNivel                    'Es el nivel del dato cargado.
                                'Aquí sale, ya que la fila entera no se incorpora
                                FtoAplicarUsado = True
                            End If
                        End If
                    Next FAN

                    'Si no lo tiene, lo agrega
                    If FtoAplicarUsado = False Then
                        'Si tiene un nivel superior, agrega el formato
                        FtoAplicar(FANCant, 0) = FtoTipo                     'Es el tipo de formato
                        FtoAplicar(FANCant, 1) = FtoParametro                'Es el parámetro
                        FtoAplicar(FANCant, 2) = FtoParValor                 'Es el valor del parámetro.
                        FtoAplicar(FANCant, 3) = FtoParValorAdic             'Es el valor del parámetro adicional.
                        FtoAplicar(FANCant, 4) = FtoParRegla                 'Es la regla condicional a aplicar
                        'Como se inhabilita el siguiente nivel, si o si la matríz debe estar ordenada,  1- Hoja, 2- Fila o Columna, 3- Celda.
                        FtoAplicar(FANCant, 5) = FtoNivel                    'Es el nivel del dato cargado.
                        'Especifica la variable a False, para cuando haya nuevos datos se puedan incorporar
                        FtoAplicarUsado = False
                    End If

                    FANCant = FANCant + 1   'Agrega un valor nuevo
                    ''Especifica la Visibilidad a la Fila, si esta no se incorpora sale del bucle for
                    'If FtoParametro = "FILESTADO" And FtoNivel = FilVisNivel Then   'Si el Parámetro es Estado, y el nivel es superior, ingresa y cambia el valor.
                    '    FtoAplicar(50, 0) = FtoTipo                     'Es el tipo de formato
                    '    FtoAplicar(50, 1) = FtoParametro                'Es el parámetro
                    '    FtoAplicar(50, 2) = FtoParValor                 'Es el valor del parámetro.
                    '    FtoAplicar(50, 3) = FtoParRegla                 'Es la regla condicional a aplicar
                    '    'Como se inhabilita el siguiente nivel, si o si la matríz debe estar ordenada,  1- Hoja, 2- Fila o Columna, 3- Celda.
                    '    FtoAplicar(50, 4) = InForVal(1).ToString        'Es el nivel del dato cargado.
                    '    'Aquí sale, ya que la fila entera no se incorpora
                    '    Exit For
                    'End If

                    ''Especifica la Visibilidad a la Columna
                    'If FtoParametro = "COLESTADO" And FtoNivel = ColVisNivel Then   'Si el Parámetro es Estado, y el nivel es superior, ingresa y cambia el valor.
                    '    ColVisible = InForVal(1).ToString     'Es el valor del parámetro.
                    '    'Como se inhabilita el siguiente nivel, si o si la matríz debe estar ordenada,  1- Hoja, 2- Fila o Columna, 3- Celda.
                    '    ColVisNivel = FtoNivel       'Es el nivel del dato cargado.
                    '    'Aquí sale, ya que la columna no se incorpora
                    '    Exit For
                    'End If

                    ''Especifica la clase de la Columna
                    'If FtoParametro = "Clases" And FtoNivel > CpTipNivel Then
                    '    CpCssClas = InForVal(1).ToString     'Es el valor del parámetro.
                    '    'Como se inhabilita el siguiente nivel, si o si la matríz debe estar ordenada,  1- Hoja, 2- Fila o Columna, 3- Celda.
                    '    CpTipNivel = FtoNivel       'Es el nivel del dato cargado.
                    'End If

                    ''Especifica el ancho de la Columna
                    'If FtoParametro = "COLANCHO" And FtoNivel > CpTipNivel Then
                    '    CpWidth = InForVal(1).ToString     'Es el valor del parámetro.
                    '    'Como se inhabilita el siguiente nivel, si o si la matríz debe estar ordenada,  1- Hoja, 2- Fila o Columna, 3- Celda.
                    '    CpWidthNivel = FtoNivel       'Es el nivel del dato cargado.
                    'End If     'Borrar este comentario
                Next CantInForm
            End If
        Next FilF

        FuncTblFtoUsu = FANCant - 1
        Return FuncTblFtoUsu
    End Function

    Friend Function FuncConvEnTbl(ByVal TextMultValuado As String) As String
        Dim Fil As Integer = 0
        Dim Col As Integer = 0
        Dim DatosEnFilas() As String    'Define la variable donde van los datos en fila
        Dim DatosEnFilasyCol() As String
        Dim FilCant As Integer = 0 'Esto es para saber cuantos datos tiene las filas en realidad
        Dim ColCant As Integer = 0 'Esto es para saber cuantas columnas hay en total

        '1.- Pasa los datos en Filas
        'Asigna los valores con el split, a la variable que tiene las filas
        DatosEnFilas = TextMultValuado.Split("‡")

        '2.- Genera la matriz con la información, para ello redefine la matriz con los datos reales y luego los carga
        FilCant = DatosEnFilas.Length - 1                             'Se le resta 1, ya que el cero se contempla

        '3.- Determina la cantidad de columnas máximas que tiene la matriz multivaluada
        For Fil = 0 To FilCant
            Col = DatosEnFilas(Fil).Split("†").Length
            If Col > ColCant Then
                ColCant = Col
            End If
        Next Fil
        ColCant = ColCant - 1

        '4.- Pasa los datos a la matriz
        ReDim TblaRangoFormatoArray(FilCant, ColCant)   'Le agrega 1 para especificar el Nivel del Rango
        For Fil = 0 To FilCant
            'Paso la primer fila a la variable de la Fila y Columna.
            DatosEnFilasyCol = DatosEnFilas(Fil).Split("†")

            'Este bucle pone la informacion en celdas, va por cada columna cargando los datos
            For Col = 0 To DatosEnFilasyCol.Length - 1
                TblaRangoFormatoArray(Fil, Col) = DatosEnFilasyCol(Col)
            Next Col
        Next Fil

        Dim CompMatriz As String = ""
        Dim NuevaFila As Boolean = False
        For Fil = 0 To FilCant
            If Fil > 0 Then
                CompMatriz = CompMatriz & "<br>"
                NuevaFila = True
            End If
            For Col = 0 To ColCant
                If CompMatriz = "" Then
                    CompMatriz = TblaRangoFormatoArray(Fil, Col)
                Else
                    If NuevaFila = True Then
                        CompMatriz = CompMatriz & TblaRangoFormatoArray(Fil, Col)
                    Else
                        CompMatriz = CompMatriz & "|" & TblaRangoFormatoArray(Fil, Col)
                    End If
                End If
            Next Col
        Next Fil

        FuncConvEnTbl = "OK"
        Return FuncConvEnTbl
    End Function

    Friend Function ConvEnTblDoble(ByVal TextMultValuado As String) As String
        Dim Fil As Integer = 0
        Dim Col As Integer = 0
        Dim DatosEnFilas() As String    'Define la variable donde van los datos en fila
        Dim DatosEnFilasyCol() As String
        Dim FilCantMulti As Integer = 0 'Esto es para saber cuantos datos tiene las filas en realidad

        '1.- Pasa los datos en Filas
        'Asigna los valores con el split, a la variable que tiene las filas
        DatosEnFilas = TextMultValuado.Split("‡")

        '2.- Toma la cantidad de filas que hay, para ello verifica cuantas filas hay multivaluadas
        'esto es para hacer una matriz con la información precisa.
        FilCantMulti = 0
        TblaRangoFtoArrFilTot = DatosEnFilas.Length - 1                     'Cantidad de filas reales
        TblaRangoFtoArrColTot = DatosEnFilas(0).Split("†").Length - 1       'Cantidad de columnas reales
        For Fil = 0 To TblaRangoFtoArrFilTot
            'Tomo la primer columna que es la de los rangos.
            DatosEnFilasyCol = DatosEnFilas(Fil).Split("†")
            'Este bucle cuenta la cantidad de filas reales y multivaluadas
            For Col = 0 To TblaRangoFtoArrColTot
                'Paso cada columna a la matriz. Ya aquí tengo fila y columna
                'TblaTxtMultValenArray(Fil, Col) = DatosEnFilasyCol(Col)
                'Carga la cantidad de filas que quedaran en la tabla real.
                'Esto solo lo realiza de la primer columna, que es el rango. 
                'El motivo es que por cada rango de columna, fila, o celda, luego en el procedimiento hace un bucle para asignar los parámetros.
                If Col = 0 Then
                    If DatosEnFilasyCol(Col).Split("§").Length = 1 Then
                        FilCantMulti = FilCantMulti + 1
                    Else
                        'Si encuentra el signo §, quiere decir que ese formato se aplica a varios rangos.
                        FilCantMulti = FilCantMulti + DatosEnFilasyCol(Col).Split("§").Length
                    End If
                End If
            Next Col
        Next Fil


        '3.- Genera la matriz con la información, para ello redefine la matriz con los datos reales y luego los carga
        FilCantMulti = FilCantMulti - 1         'Se le resta 1, ya que el cero se contempla
        TblaRangoFtoArrColTot = TblaRangoFtoArrColTot + 1   'Le agrega una columna para poner el tipo de rango
        TblaRangoFtoArrColTot = TblaRangoFtoArrColTot + 4       'Le Agrega 4 columnas, una para FD, FH, CD, CH
        ReDim TblaRangoFormatoArray(FilCantMulti, TblaRangoFtoArrColTot)   'Le agrega 1 para especificar el Nivel del Rango
        Dim RangMulti() As String : Dim CantRangMulti As Integer = 0 : Dim CRM As Integer = 0
        FilCantMulti = 0
        For Fil = 0 To TblaRangoFtoArrFilTot
            'Paso la primer fila a la variable de la Fila y Columna.
            DatosEnFilasyCol = DatosEnFilas(Fil).Split("†")

            ' Si es la primer columna verifico que haya rangos multivaluados
            RangMulti = DatosEnFilasyCol(0).Split("§")
            CantRangMulti = DatosEnFilasyCol(0).Split("§").Length - 1
            If CantRangMulti = 0 Then   'No tiene rangos multivaluados
                'Este bucle pone la informacion en celdas, va por cada columna cargando los datos
                For Col = 0 To TblaRangoFtoArrColTot - 5        'Le resta 4, ya que todavía no esta el RangoNivel y el Detalle del FD, FH, CD, CH
                    TblaRangoFormatoArray(FilCantMulti, Col) = DatosEnFilasyCol(Col)
                Next Col
                'Le agrega una fila para que no se superpongan los datos
                FilCantMulti = FilCantMulti + 1     'Agrega una Fila nueva
            Else
                'El rango es multivaluado, debe repetir todas las columnas para cada rango
                'Este bucle pone la informacion en celdas, va por cada columna cargando los datos
                For CRM = 0 To CantRangMulti
                    'Este bucle pone la informacion en celdas, va por cada columna cargando los datos
                    For Col = 0 To TblaRangoFtoArrColTot - 5       'Le resta 4, ya que todavía no esta el RangoNivel y el Detalle del FD, FH, CD, CH
                        'Siempre la primer columna repite el rango correspondiente que sale del valor multivaluado
                        If Col = 0 Then
                            TblaRangoFormatoArray(FilCantMulti, Col) = RangMulti(CRM)
                        Else
                            TblaRangoFormatoArray(FilCantMulti, Col) = DatosEnFilasyCol(Col)
                        End If
                    Next Col
                    'Le agrega una fila para que no se superpongan los datos
                    FilCantMulti = FilCantMulti + 1     'Agrega una Fila nueva
                Next CRM
            End If
        Next Fil

        'Cantidad de Filas TablaRangoFormatoArray
        TblaRangoFtoArrFilTot = FilCantMulti - 1            'Se le resta 1, ya que el cero vale 1.
        TblaRangoFtoArrColTot = TblaRangoFtoArrColTot

        'Ahora debe especificar el Nivel del Rango y Ordenarlo en consecuencia
        'Luego le debe especificar el nivel del rango 1.-Hoja, 2.-Columna 3.-Fila, 4.-Celda
        'Para ello debe extraer el rango en FD, FH, CD, CH
        'Variables para tomar el rango del formato
        Dim RangForm() As String
        Dim RangPrim() As String
        Dim FD As String
        Dim CD As String
        Dim FH As String
        Dim CH As String
        Dim FilF As Integer
        Dim FtoNivel As String

        For FilF = 0 To TblaRangoFtoArrFilTot    'Le suma 1 por los títulos
            'Arma el rango con el primer campo
            RangForm = TblaRangoFormatoArray(FilF, 0).ToString.Split(";")
            RangPrim = RangForm(0).ToString.Split(":") : FD = RangPrim(0) : FH = RangPrim(1)
            RangPrim = RangForm(1).ToString.Split(":") : CD = RangPrim(0) : CH = RangPrim(1)

            'Actualiza cada fila con el dato, de FD, FH, CD, CH
            If FilF = 0 Then    'Títulos
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 4) = "FD"
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 3) = "FH"
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 2) = "CD"
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 1) = "CH"
            Else    'Datos
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 4) = FD
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 3) = FH
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 2) = CD
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot - 1) = CH
            End If

            'Actualiza cada fila con el Nivel del Formato
            If FilF = 0 Then    'Títulos
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot) = "FtoNivel"
            Else    'Datos
                'Ya tengo el rango del formato separado, ahora debo determinar el nivel
                If CInt(FD) = -1 And CInt(FH) = -1 And CInt(CD) = -1 And CInt(CH) = -1 Then
                    FtoNivel = 0        'Nivel Hoja
                ElseIf CInt(CD) = -1 And CInt(CH) = -1 Then
                    FtoNivel = 1        'Elimina la Fila, por eso no tiene encuenta el Nivel Columna
                ElseIf CInt(FD) = -1 And CInt(FH) = -1 Then
                    FtoNivel = 2        'Elimina la Columna, por eso no tiene encuenta el Nivel Fila
                ElseIf (CInt(CD) - CInt(CH)) <> 0 Or (CInt(CD) - CInt(CH)) <> 0 Then
                    FtoNivel = 3        'Rangos, más de una Celda
                Else
                    FtoNivel = 4        'Celdas
                End If
                TblaRangoFormatoArray(FilF, TblaRangoFtoArrColTot) = FtoNivel
            End If
        Next FilF

        'Recorre la matriz para verificar los datos, es solo de comprobación
        Dim Dat As String = ""
        For Fil = 0 To TblaRangoFtoArrFilTot
            Dat = ""
            For Col = 0 To TblaRangoFtoArrColTot
                Dat = Dat & " | " & TblaRangoFormatoArray(Fil, Col)
            Next Col
        Next Fil

        'Array.Sort(TblaRangoFormatoArray)

        'Define las variables
        Dim a(,) As Integer = {{33, 12}, {12, 10}, {13, 5}, {27, 19}}
        Dim tagArray() As Integer = {0, 1, 2, 3}

        Dim myComparer As New RectangularComparer(a)    'Inicializa la Comparación

        Array.Sort(tagArray, myComparer)    'Va a la función a ordenar según la comparación

        Dim Ord As String
        'Recorre la variable para mostrar el orden
        Dim i As Integer
        For i = 0 To tagArray.Length - 1
            Ord = a(tagArray(i), 0) & "-" & a(tagArray(i), 1)
        Next i

        ConvEnTblDoble = "OK"
        Return ConvEnTblDoble
    End Function

    Friend Function DatFto(ByVal DatVal As String, ByVal FtoAplic As String) As String
        Dim EsNum As Boolean = False
        Dim MyNum As Double = 0
        Dim DatMult() As String
        DatMult = DatVal.Split("†")

        If IsNumeric(DatMult(0)) = True Then
            EsNum = True
        End If

        If FtoAplic = "MONEDA" And EsNum = True Then
            MyNum = DatMult(0)
            DatFto = MyNum.ToString("$#,##0;($#,##0);0")
            'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
        ElseIf FtoAplic = "PORCENTAJE" And EsNum = True Then
            MyNum = DatMult(0)
            'Define la variable para especificar el formato, según la cultura
            Dim nfi As NumberFormatInfo = New CultureInfo("hr-HR", False).NumberFormat  '"en-US"
            nfi.PercentDecimalDigits = 0
            'DatFto = MyNum.ToString("0' u';(0' u');0")
            DatFto = MyNum.ToString("P", nfi)
        ElseIf FtoAplic = "ENTERO" And EsNum = True Then
            MyNum = DatMult(0)
            DatFto = MyNum.ToString("0' u';(0' u');0")
        Else
            'No hace nada
            DatFto = DatMult(0)
        End If
        Return DatFto
    End Function

    Friend Function ConvEnTbl(ByVal TextMultValuado As String) As String
        Dim Fil As Integer = 0
        Dim Col As Integer = 0

        'Pasa los datos en Filas
        Dim DatosEnFilas() As String : DatosEnFilas = TextMultValuado.Split("‡") : Dim DatosEnFilasyCol() As String

        'Redefine la matríz en función a los datos que hay en el campo multivaluado
        TblaRangoFtoArrFilTot = DatosEnFilas.Length - 1 : TblaRangoFtoArrColTot = DatosEnFilas(0).Split("†").Length - 1
        ReDim TblaTxtMultValenArray(TblaRangoFtoArrFilTot, TblaRangoFtoArrColTot)

        'Completa el array con la información del campo multivaluado
        For Fil = 0 To TblaRangoFtoArrFilTot
            'Paso la primer fila a la variable de la fila
            DatosEnFilasyCol = DatosEnFilas(Fil).Split("†")
            For Col = 0 To TblaRangoFtoArrColTot
                'Paso cada columna a la matriz. Ya aquí tengo fila y columna
                TblaTxtMultValenArray(Fil, Col) = DatosEnFilasyCol(Col)
            Next
        Next

        ConvEnTbl = "OK"
        Return ConvEnTbl
    End Function

    Friend Function FuncEsPar(ByVal Num As Integer) As Boolean
        'Dim EsNumPar As String
        'EsNumPar = Convert.ToBoolean((Num / 2) = Int(Num / 2))
        Return Convert.ToBoolean((Num / 2) = Int(Num / 2))
    End Function

    Function borrar()

        '    Dim ConvEnTblj As String
        '    Dim Fil As Integer = 0 : Dim TotFil As Integer = 0
        '    Dim Col As Integer = 0 : Dim TotCol As Integer = 0
        '    Dim FilArr As Integer = 0 : Dim ColArr As Integer = 0
        '    TotFil = dbDTable.Rows.Count - 1 : TotCol = dbDTable.Columns.Count - 1

        '    Dim TblFormyVinc(TotFil, TotCol) As String

        '    Dim Tbl As New Table
        '    Tbl.ID = VarTblArmASP
        '    Tbl.CssClass = "sortable"

        '    'Arma la Tabla que vee el usuario

        '    ' 0.- Arma la tabla del campo multivaluado.
        '    ' Organiza el formato y los vínculos de las tablas
        '    ' Aquí llama a la función para transformar el campo multivaluado en una tabla
        '    ConvEnTblj = ConvEnTbl(Vinculo)

        '    ' 1.- Primero debemos poner el título a la Tabla
        '    If TblTitulo <> "" Then
        '        If TblTituloVinculo = "" Then
        '            Tbl.Caption = TblTitulo
        '        Else
        '            Dim TitLinkButt As New LinkButton()
        '            TitLinkButt.Text = TblTitulo.ToString
        '            TitLinkButt.PostBackUrl = TblTituloVinculo & "&TblPars=" & VarPar & "&TblTit=" & TblTitulo.ToString & " - COMPLETO"
        '            TitLinkButt.CssClass = "caption"
        '            Panel1.Controls.Add(TitLinkButt)
        '            'Panel1.Controls.Add(New LiteralControl("<BR>"))
        '        End If
        '        Tbl.CaptionAlign = TableCaptionAlign.Left
        '    Else
        '        'Tbl.Caption = ""
        '    End If

        '    ' 2.- Segundo debemos poner el título a cada columna
        '    Dim Tit As New TableRow()
        '    't.CssClass = "tbletit"
        '    For Col = 0 To dbDTable.Columns.Count - 1
        '        Dim ct As New TableCell()
        '        Dim cth As New TableHeaderCell()
        '        Dim lbl As New Label()
        '        'Si la columna define el tipo de Fila, o Se especifica que no se muestra, no la carga
        '        If dbDTable.Columns(Col).Caption.ToString <> "TIPOFILA" And InStr(dbDTable.Columns(Col).Caption.ToString, "†NM", CompareMethod.Text) = 0 Then
        '            'ct.CssClass = "tbletit"
        '            lbl.Text = dbDTable.Columns(Col).Caption.ToString
        '            cth.Controls.Add(lbl)
        '            Tit.Cells.Add(cth)
        '        End If
        '    Next Col
        '    Tbl.Rows.Add(Tit)


        '    ' 3.- Tercero recorremos el recordset creando una fila nueva por cada registro 
        '    For Fil = 0 To DtRFilasActuales.Length - 1
        '        Dim r As New TableRow() 'Agrega una nueva Fila
        '        ' Borrar Inicio
        '        ' Especifica el formato de la fila
        '        If DtRFilasActuales(Fil)(0).ToString = "TOTAL" Then
        '            'Si la fila es un Total, tiene un formato específico
        '            r.CssClass = "sortbottom"   'Especifica el formato de la fila Titulo
        '            'Celda.CssClass = "tbleceltot"   'Especifica el formato de la fila Titulo
        '        ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then
        '            'Si la fila es de Datos, tiene un formato específico
        '            'r.CssClass = "TblDatEst"
        '        End If


        '        ' Borrar Fin
        '        For Col = 0 To dbDTable.Columns.Count - 1
        '            Dim Celda As New TableCell()
        '            Dim LinkButt As New LinkButton()
        '            Dim TextoAAgregar As String = ""
        '            Dim TipoControl As String = ""
        '            Dim TipoFormato As String = ""

        '            'Si la columna define el tipo de Fila, o Se especifica que no se muestra, no la carga
        '            If dbDTable.Columns(Col).Caption.ToString <> "TIPOFILA" And InStr(dbDTable.Columns(Col).Caption.ToString, "†NM", CompareMethod.Text) = 0 Then
        '                'Aquí estamos en cada celda de la tabla que se va a realizar
        '                If DtRFilasActuales(Fil)(0).ToString <> "NULL" Or DtRFilasActuales(Fil)(Col).ToString <> "" Then
        '                    'Especifica el formato de la celda
        '                    If DtRFilasActuales(Fil)(0).ToString = "TOTAL" Then
        '                        'Si la fila es un Total, tiene un formato específico
        '                        'Celda.CssClass = "sortbottom"   'Especifica el formato de la fila Titulo
        '                        'Celda.CssClass = "tbleceltot"   'Especifica el formato de la fila Titulo
        '                    ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then
        '                        'Si la fila es de Datos, tiene un formato específico
        '                        'Celda.CssClass = "TblCelEst"
        '                    End If



        '                    'If DtRFilasActuales(Fil)(Col).ToString = "NULL" Or DtRFilasActuales(Fil)(Col).ToString = "" Then
        '                    '    'NO HACE NADA
        '                    'Else
        '                    '    Celda.Controls.Add(New LiteralControl(DtRFilasActuales(Fil)(Col).ToString))
        '                    'End If
        '                    'ElseIf DtRFilasActuales(Fil)(0).ToString = "DATOS" Then



        '                    'Ahora debemos recorrer el array para ver si tiene vinculo, formato, etc.
        '                    'Aquí se debe verificar:
        '                    ' Control a Utilizar
        '                    ' Si tiene Vínculo
        '                    ' Tipo de Formato del Valor
        '                    ' Tipo de fondo de la celda
        '                    ' Ver en excel que mas aspectos tiene la celda

        '                    '1.- TIPO DE CONTROL QUE SE DEBE AGREGAR
        '                    '    Recorre la matriz con la info
        '                    For FilArr = 1 To TblaArrFilTot
        '                        'Primero verifica si la fila esta incluída
        '                        If Fil = TblaTxtMultValenArray(FilArr, 0) Or TblaTxtMultValenArray(FilArr, 0) = -1 Then     'FIL
        '                            'Verifica si la columna esta incluída, si es así pone la especificación
        '                            If Col = TblaTxtMultValenArray(FilArr, 1) Or TblaTxtMultValenArray(FilArr, 1) = -1 Then    'COL
        '                                'Verifica el tipo de columna, y en función de eso procede a tipificarla
        '                                If TblaTxtMultValenArray(FilArr, 2) = "CONTROL" Then    'TIPO
        '                                    If TblaTxtMultValenArray(FilArr, 3) = "LINKBUTTON" Then   'VALOR
        '                                        TipoControl = "LinkButton"
        '                                        LinkButt.ID = "vinc" & Fil & Col

        '                                        'Verifica si el vinculo que viene de la consulta sql tiene codigo y descripción
        '                                        Dim DatVinc() As String
        '                                        If DtRFilasActuales(Fil)(Col).ToString = "" Then
        '                                            ReDim DatVinc(0)
        '                                            DatVinc(0) = DtRFilasActuales(Fil)(Col).ToString
        '                                        Else
        '                                            DatVinc = DtRFilasActuales(Fil)(Col).ToString.Split("†")
        '                                        End If

        '                                        If DatVinc.Length = 3 Then  'Tiene 2 valores (0 y 1), tiene codigo
        '                                            TextoAAgregar = DatVinc(2).ToString()
        '                                            If VarPar = "" Then
        '                                                LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
        '                                                'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
        '                                            Else
        '                                                LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
        '                                                'LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
        '                                            End If
        '                                        ElseIf DatVinc.Length = 2 Then  'Tiene 2 valores (0 y 1), tiene codigo
        '                                            TextoAAgregar = DatVinc(1).ToString()
        '                                            If VarPar = "" Then
        '                                                LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
        '                                                'TblRelac = "PVCCGen.aspx?TblCod=" & DtRFilAct(Fil)(1).ToString & "&TblPars="
        '                                            Else
        '                                                LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(1).ToString()
        '                                            End If
        '                                        Else
        '                                            TextoAAgregar = DatVinc(0).ToString()
        '                                            If VarPar = "" Then
        '                                                LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(0).ToString()
        '                                            Else
        '                                                LinkButt.PostBackUrl = TblaTxtMultValenArray(FilArr, 4).ToString & "&TblPars=" & VarPar & "|" & DatVinc(0).ToString() & "&TblTit=" & DatVinc(0).ToString()
        '                                            End If
        '                                        End If
        '                                    End If  'ESPECIFICACIONES
        '                                End If
        '                            Else
        '                                'No hace nada, ya que puede ser que en otra fila de array este especificado
        '                            End If
        '                        Else
        '                            'No hace nada, ya que puede ser que en otra fila de array este especificado
        '                        End If
        '                    Next

        '                    '2.- FORMATO DEL VALOR A AGREGAR
        '                    '    Recorre la matriz con la info
        '                    For FilArr = 1 To TblaArrFilTot
        '                        'Primero verifica si la fila esta incluída
        '                        If Fil = TblaTxtMultValenArray(FilArr, 0) Or TblaTxtMultValenArray(FilArr, 0) = -1 Then     'FIL
        '                            'Verifica si la columna esta incluída, si es así pone la especificación
        '                            If Col = TblaTxtMultValenArray(FilArr, 1) Or TblaTxtMultValenArray(FilArr, 1) = -1 Then    'COL
        '                                'Celda que tiene un formato específico
        '                                'Verifica el tipo de columna, y en función de eso procede a tipificarla
        '                                If TblaTxtMultValenArray(FilArr, 2) = "FORMATO" Then    '
        '                                    If TblaTxtMultValenArray(FilArr, 3) = "MONEDA" Then   'VALOR
        '                                        If IsNumeric(DtRFilasActuales(Fil)(Col)) = True Then
        '                                            Dim MyNum As Double = 0
        '                                            If TextoAAgregar = "" Then
        '                                                MyNum = DtRFilasActuales(Fil)(Col)
        '                                                TextoAAgregar = MyNum.ToString("$#,##0;($#,##0);0")
        '                                                'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
        '                                            Else
        '                                                MyNum = CDbl(TextoAAgregar)
        '                                                TextoAAgregar = MyNum.ToString("$#,##0;($#,##0);0")
        '                                                'TextoAAgregar = String.Format("{0,1:C0}", CDbl(TextoAAgregar))
        '                                            End If
        '                                            'Todos los valores numéricos se alinean a la derecha
        '                                            Celda.HorizontalAlign = HorizontalAlign.Right
        '                                        Else
        '                                            'No hace nada ya que no se puede convertir el dato
        '                                        End If
        '                                    ElseIf TblaTxtMultValenArray(FilArr, 3) = "ENTERO" Then   'VALOR
        '                                        If IsNumeric(DtRFilasActuales(Fil)(Col)) = True Then
        '                                            Dim MyNum As Double = 0
        '                                            If TextoAAgregar = "" Then
        '                                                MyNum = DtRFilasActuales(Fil)(Col)
        '                                                TextoAAgregar = MyNum.ToString("0' u';(0' u');0")
        '                                                'TextoAAgregar = String.Format("{0,1:C0}", DtRFilasActuales(Fil)(Col))
        '                                            Else
        '                                                MyNum = CDbl(TextoAAgregar)
        '                                                TextoAAgregar = MyNum.ToString("0' u';(0' u');0")
        '                                            End If
        '                                            'Todos los valores numéricos se alinean a la derecha
        '                                            Celda.HorizontalAlign = HorizontalAlign.Right
        '                                        Else
        '                                            'No hace nada ya que no se puede convertir el dato
        '                                        End If
        '                                    Else
        '                                        'No hace nada
        '                                    End If
        '                                End If
        '                            Else
        '                                'No hace nada, ya que puede ser que en otra fila de array este especificado
        '                            End If
        '                        Else
        '                            'No hace nada, ya que puede ser que en otra fila de array este especificado
        '                        End If
        '                    Next
        '                    'Cuando termina el array, se deben ver los parámetros especificados, si no hay nada se ponen por defecto, TipoDato Texto, Formato, Fondo Celda, etc
        '                    'Luego que recorrió por la tabla de especificaciones, agrega la Celda a la Tabla


        '                    'Debe verificar el tipo de Control que se debe agregar, si no se agrega el texto comun
        '                    If DtRFilasActuales(Fil)(Col).ToString = "" Or DtRFilasActuales(Fil)(Col).ToString = "0" Then
        '                        'NO PONE NADA YA QUE NO TIENE VALOR
        '                    Else
        '                        If TextoAAgregar <> "" Then 'Si la variable con el dato con formato no tiene valor, pone el dato del DataTable
        '                            If TextoAAgregar = "0" Then
        '                                'Si el valor es igual a cero no pone nada
        '                            Else
        '                                If TipoControl = "LinkButton" Then
        '                                    LinkButt.Text = TextoAAgregar
        '                                    Celda.Controls.Add(LinkButt)
        '                                Else
        '                                    Celda.Controls.Add(New LiteralControl(TextoAAgregar))
        '                                End If
        '                            End If
        '                        Else
        '                            If TipoControl = "LinkButton" Then
        '                                LinkButt.Text = TextoAAgregar
        '                                Celda.Controls.Add(LinkButt)
        '                            Else
        '                                Celda.Controls.Add(New LiteralControl(DtRFilasActuales(Fil)(Col).ToString))
        '                            End If


        '                        End If
        '                    End If
        '                Else
        '                    'NO HACE NADA
        '                End If
        '                'Response.Write("<TD><a href=detalle_rg.asp?Fecha="&Var_Fecha&"?Central="&oRS.Fields(I).name&"><div align=center><font size=2><font color=#0000A0>"&trim(oRS.Fields(I))&"</font></font></b></div></a></TD>")
        '                r.Cells.Add(Celda)
        '            End If
        '        Next Col

        '        Tbl.Rows.Add(r)
        '        'If Fil > 10 Then Exit For
        '    Next Fil
        '    Panel1.Controls.Add(Tbl)
        '    Panel1.Controls.Add(New LiteralControl("<BR>"))

        '    'Si llega a esta instancia es que realizo la TABLA OK, lo informa
        Dim HaceTbla As String
        HaceTbla = "TblaOK"
        Return HaceTbla
    End Function


    Class RectangularComparer
        Implements IComparer
        ' maintain a reference to the 2-dimensional array being sorted
        Private sortArray(,) As Integer
        ' constructor initializes the sortArray reference
        Public Sub New(ByVal theArray(,) As Integer)
            sortArray = theArray
        End Sub


        Public Function Compare(ByVal x As Object, ByVal y As Object) _
        As Integer Implements IComparer.Compare
            ' x and y are integer row numbers into the sortArray
            Dim i1 As Integer = DirectCast(x, Integer)
            Dim i2 As Integer = DirectCast(y, Integer)
            ' Compara los items en el array, el primer parametro es el valor, el segundo es la columna, el 0 = primera, el 1 = segunda, etc.
            Return sortArray(i1, 0).CompareTo(sortArray(i2, 0))
        End Function
    End Class


End Class





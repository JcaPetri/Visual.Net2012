﻿Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Establece la dirección del vinculo registrese
        'RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString("ReturnUrl"))
        LoginUser.FindControl("UserName").Focus()
    End Sub

    Private Sub LoginUser_Authenticate1(sender As Object, e As System.Web.UI.WebControls.AuthenticateEventArgs) Handles LoginUser.Authenticate
        If FormsAuthentication.Authenticate(LoginUser.UserName.ToString, LoginUser.Password.ToString) Then
            'Dim CookieAut As HttpCookie
            'CookieAut = FormsAuthentication.GetAuthCookie(LoginUser.UserName.ToString, False)
            'CookieAut.Expires = DateTime.Now.AddMinutes(2)
            'Response.Cookies.Add(CookieAut)
            'Response.Write("Listo!!")

            FormsAuthentication.SetAuthCookie(LoginUser.UserName.ToString, False)
            Response.Redirect("~/Default.aspx")


        Else
            Response.Write("Lo siento, el nombre de usuario o la contrase;a son incorrectos")
        End If
    End Sub
End Class